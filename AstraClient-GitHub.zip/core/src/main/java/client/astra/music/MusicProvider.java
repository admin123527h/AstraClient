package client.astra.music;

import java.util.Optional;

/** Source of "now playing" data. Implement this for Nocturne/Spotify/etc. */
public interface MusicProvider {
    record Track(String title, String artist, long durationMs, long positionMs, boolean playing) {}

    Optional<Track> current();

    /** A short reason why nothing is shown (login problem, account not allowed), or empty. */
    default String problem() {
        return "";
    }
}
