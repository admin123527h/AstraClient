package client.astra.lyrics;

public record LyricLine(long timeMs, String text) {}
