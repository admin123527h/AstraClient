package client.astra.lyrics;

import java.util.List;

/**
 * Estimates when each word of a line is sung. Lyrics files only carry the start of a whole line, so the line's time is
 * shared between its words by syllables (vowel groups) with a short pause after commas and full stops. Each word
 * starts exactly when the one before it has ended, so a word can never appear before the previous one is done.
 */
public final class WordTiming {
    private WordTiming() {}

    /** Returns {starts, ends} in milliseconds (absolute, like lineStartMs). */
    public static long[][] estimate(List<String> words, long lineStartMs, long lineDurMs) {
        int n = words.size();
        double[] sing = new double[n];
        double[] pause = new double[n];
        double total = 0;
        for (int i = 0; i < n; i++) {
            String w = words.get(i);
            sing[i] = 0.5 + syllables(w) + 0.06 * w.length();
            char last = w.isEmpty() ? ' ' : w.charAt(w.length() - 1);
            if (last == ',' || last == ';' || last == ':') pause[i] = 0.6;
            else if (last == '.' || last == '!' || last == '?') pause[i] = 1.0;
            if (i == n - 1) pause[i] = 0;
            total += sing[i] + pause[i];
        }
        double usable = lineDurMs * 0.94;
        long[] starts = new long[n];
        long[] ends = new long[n];
        double acc = 0;
        for (int i = 0; i < n; i++) {
            starts[i] = lineStartMs + Math.round(usable * acc / total);
            acc += sing[i];
            ends[i] = lineStartMs + Math.round(usable * acc / total);
            acc += pause[i];
        }
        return new long[][] {starts, ends};
    }

    static int syllables(String word) {
        int groups = 0;
        boolean inVowel = false;
        for (char ch : word.toLowerCase().toCharArray()) {
            boolean v = "aeiouyäöüáéíóúàèìòùâêîôû".indexOf(ch) >= 0;
            if (v && !inVowel) groups++;
            inVowel = v;
        }
        return Math.max(1, groups);
    }
}
