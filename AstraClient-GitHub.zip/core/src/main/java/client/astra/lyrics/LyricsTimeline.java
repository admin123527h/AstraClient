package client.astra.lyrics;

import java.util.List;

public final class LyricsTimeline {
    private final List<LyricLine> lines;

    public LyricsTimeline(List<LyricLine> lines) {
        this.lines = List.copyOf(lines);
    }

    /** Index of the line active at positionMs, or -1 before the first line. */
    public int indexAt(long positionMs) {
        int lo = 0, hi = lines.size() - 1, ans = -1;
        while (lo <= hi) {
            int mid = (lo + hi) >>> 1;
            if (lines.get(mid).timeMs() <= positionMs) { ans = mid; lo = mid + 1; } else hi = mid - 1;
        }
        return ans;
    }

    public LyricLine line(int index) {
        return index >= 0 && index < lines.size() ? lines.get(index) : null;
    }

    /** 0..1 progress through the current line, for smooth highlight animation. */
    public float progressAt(long positionMs) {
        int i = indexAt(positionMs);
        if (i < 0) return 0f;
        long start = lines.get(i).timeMs();
        long end = i + 1 < lines.size() ? lines.get(i + 1).timeMs() : start + 4000;
        return Math.min(1f, Math.max(0f, (positionMs - start) / (float) Math.max(1, end - start)));
    }

    public int size() { return lines.size(); }
}
