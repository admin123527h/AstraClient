package client.astra.addons;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import java.io.IOException;
import java.net.URI;
import java.net.URLEncoder;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.security.MessageDigest;
import java.time.Duration;
import java.util.ArrayList;
import java.util.HexFormat;
import java.util.List;
import java.util.function.Consumer;

/**
 * Third-party mods and resource packs that Astra manages for the player. Nothing is shipped inside Astra: every file is
 * downloaded from Modrinth onto the player's computer, checked against Modrinth's SHA-512, together with the mods it
 * needs. The launcher installs the enabled ones before the game starts; the in-game Mods tab turns them on and off.
 */
public final class Addons {
    public enum Kind { MOD, PACK }

    public record Entry(String slug, String name, String description, Kind kind, boolean defaultOn) {}

    public enum State { NOT_INSTALLED, ON, OFF, UNAVAILABLE }

    public static final List<Entry> CATALOG = List.of(
            new Entry("xaeros-minimap", "Xaero's Minimap", "Minimap with waypoints and cave mode.", Kind.MOD, true),
            new Entry("xaeros-world-map", "Xaero's World Map", "Full map of everything you explored.", Kind.MOD, true),
            new Entry("easy-freecam", "Freecam (Elpu7)", "Fly the camera around without moving your player.", Kind.MOD, true),
            new Entry("tree-vein-miner", "Tree Vein Miner", "Chop a whole tree with one swing.", Kind.MOD, true),
            new Entry("ore-vein-miner", "Ore Vein Miner", "Mine a whole ore vein with one swing.", Kind.MOD, true),
            new Entry("mouse-tweaks", "Mouse Tweaks", "Faster item moving in inventories.", Kind.MOD, true),
            new Entry("shulkerboxtooltip", "Shulker Box Tooltip", "See what is inside a shulker box.", Kind.MOD, true),
            new Entry("ukus-armor-hud", "uku's Armor HUD", "Armor and held items on your screen.", Kind.MOD, true),
            new Entry("ukulib", "ukulib", "Library that uku's mods need.", Kind.MOD, true),
            new Entry("essential", "Essential Mod", "Friends, cosmetics and worlds with friends. Has its own account and terms.", Kind.MOD, true),
            new Entry("new-glowing-ores", "New Glowing Ores (resource pack)", "Ore textures that stand out in the dark.", Kind.PACK, true));

    private static final String API = "https://api.modrinth.com/v2";
    private static final String FABRIC_API_PROJECT = "P7dR8mSH";
    private static final long RECHECK_MS = 12L * 60 * 60 * 1000;
    private static final HttpClient HTTP = HttpClient.newBuilder().connectTimeout(Duration.ofSeconds(15))
            .followRedirects(HttpClient.Redirect.ALWAYS).build();

    private final Path gameDir;
    private final String mc;
    private final Path stateFile;
    private JsonObject state;

    public Addons(Path gameDir, String minecraftVersion) {
        this.gameDir = gameDir;
        this.mc = minecraftVersion;
        this.stateFile = gameDir.resolve("astra-addons.json");
        this.state = load();
    }

    // ---- state ----

    private JsonObject load() {
        try {
            if (Files.exists(stateFile)) return JsonParser.parseString(Files.readString(stateFile)).getAsJsonObject();
        } catch (IOException | RuntimeException ignored) {
        }
        return new JsonObject();
    }

    private synchronized void save() {
        try {
            Files.createDirectories(gameDir);
            Files.writeString(stateFile, state.toString());
        } catch (IOException ignored) {
        }
    }

    private JsonObject section(String name) {
        if (!state.has(name)) state.add(name, new JsonObject());
        return state.getAsJsonObject(name);
    }

    public synchronized boolean enabled(Entry e) {
        JsonObject on = section("enabled");
        return on.has(e.slug()) ? on.get(e.slug()).getAsBoolean() : e.defaultOn();
    }

    private Path dir(Kind kind) {
        return gameDir.resolve(kind == Kind.MOD ? "mods" : "resourcepacks");
    }

    /** The file name of the installed jar or zip, or null. */
    public synchronized String file(Entry e) {
        JsonObject inst = section("installed");
        return inst.has(e.slug()) ? inst.getAsJsonObject(e.slug()).get("file").getAsString() : null;
    }

    public synchronized State status(Entry e) {
        String f = file(e);
        if (f != null) {
            Path on = dir(e.kind()).resolve(f);
            if (Files.exists(on)) return State.ON;
            if (e.kind() == Kind.MOD && Files.exists(dir(e.kind()).resolve(f + ".disabled"))) return State.OFF;
        }
        if (section("unavailable").has(e.slug()) && section("unavailable").get(e.slug()).getAsString().equals(mc)) return State.UNAVAILABLE;
        return State.NOT_INSTALLED;
    }

    /** Turns an entry on or off. A mod is switched by renaming its jar, so it takes effect when the game starts. */
    public synchronized void setEnabled(Entry e, boolean on) {
        section("enabled").addProperty(e.slug(), on);
        save();
        applyFiles(e);
    }

    private void applyFiles(Entry e) {
        String f = file(e);
        if (f == null || e.kind() != Kind.MOD) return;
        Path jar = dir(Kind.MOD).resolve(f);
        Path off = dir(Kind.MOD).resolve(f + ".disabled");
        try {
            if (enabled(e) && Files.exists(off) && !Files.exists(jar)) Files.move(off, jar);
            if (!enabled(e) && Files.exists(jar)) Files.move(jar, off, StandardCopyOption.REPLACE_EXISTING);
        } catch (IOException ignored) {
        }
    }

    // ---- installing ----

    /** Installs or updates one entry (and the mods it needs). Returns null on success or a short reason. */
    public String install(Entry e, Consumer<String> log) {
        return install(e, e.slug(), e.kind(), log, 0);
    }

    private String install(Entry e, String slug, Kind kind, Consumer<String> log, int depth) {
        try {
            JsonObject version = newestVersion(slug, kind);
            if (version == null) {
                synchronized (this) {
                    section("unavailable").addProperty(slug, mc);
                    save();
                }
                return "not available for Minecraft " + mc + " yet";
            }
            section("unavailable").remove(slug);
            JsonObject file = null;
            for (JsonElement f : version.getAsJsonArray("files")) {
                JsonObject o = f.getAsJsonObject();
                if (file == null || (o.has("primary") && o.get("primary").getAsBoolean())) file = o;
            }
            if (file == null) return "no file to download";
            // Resource pack names can hold odd characters, so packs are stored under a plain name.
            String name = kind == Kind.PACK ? slug + ".zip" : file.get("filename").getAsString();
            String id = version.get("id").getAsString();
            JsonObject inst = section("installed");
            boolean current = inst.has(slug) && inst.getAsJsonObject(slug).get("version").getAsString().equals(id)
                    && (Files.exists(dir(kind).resolve(name)) || Files.exists(dir(kind).resolve(name + ".disabled")));
            if (!current) {
                log.accept("Downloading " + (e != null ? e.name() : slug) + " " + version.get("version_number").getAsString());
                Path target = dir(kind).resolve(name);
                download(file.get("url").getAsString(), target, file.getAsJsonObject("hashes").get("sha512").getAsString());
                String old = inst.has(slug) ? inst.getAsJsonObject(slug).get("file").getAsString() : null;
                if (old != null && !old.equals(name)) {
                    Files.deleteIfExists(dir(kind).resolve(old));
                    Files.deleteIfExists(dir(kind).resolve(old + ".disabled"));
                }
                JsonObject rec = new JsonObject();
                rec.addProperty("file", name);
                rec.addProperty("version", id);
                inst.add(slug, rec);
            }
            section("checked").addProperty(slug, System.currentTimeMillis());
            save();

            if (kind == Kind.MOD && depth < 3) {
                for (JsonElement d : version.getAsJsonArray("dependencies")) {
                    JsonObject dep = d.getAsJsonObject();
                    if (!"required".equals(dep.get("dependency_type").getAsString()) || dep.get("project_id").isJsonNull()) continue;
                    String projectId = dep.get("project_id").getAsString();
                    if (projectId.equals(FABRIC_API_PROJECT)) continue;
                    String depSlug = projectSlug(projectId);
                    if (depSlug == null) continue;
                    String problem = install(catalogEntry(depSlug), depSlug, Kind.MOD, log, depth + 1);
                    if (problem != null) log.accept("Needed mod " + depSlug + ": " + problem);
                }
            }
            if (e != null) applyFiles(e);
            return null;
        } catch (IOException | InterruptedException | RuntimeException ex) {
            if (ex instanceof InterruptedException) Thread.currentThread().interrupt();
            return ex.getMessage() == null ? ex.toString() : ex.getMessage();
        }
    }

    private static Entry catalogEntry(String slug) {
        for (Entry c : CATALOG) if (c.slug().equals(slug)) return c;
        return null;
    }

    /** Launcher entry point: install what is switched on (rechecking at most every 12 hours), keep the rest off. */
    public void syncAll(Consumer<String> log) {
        for (Entry e : CATALOG) {
            try {
                if (enabled(e)) {
                    long last = section("checked").has(e.slug()) ? section("checked").get(e.slug()).getAsLong() : 0;
                    State s = status(e);
                    boolean due = System.currentTimeMillis() - last > RECHECK_MS;
                    if (s == State.OFF) applyFiles(e);
                    if (s == State.UNAVAILABLE && !due) continue;
                    if (s == State.NOT_INSTALLED || s == State.UNAVAILABLE || due) {
                        String problem = install(e, log);
                        if (problem != null) log.accept(e.name() + ": " + problem);
                    }
                } else {
                    applyFiles(e);
                }
            } catch (RuntimeException ex) {
                log.accept(e.name() + ": " + ex.getMessage());
            }
        }
        syncPackList();
    }

    // ---- resource packs: options.txt ----

    /** Puts the enabled resource pack files into options.txt (and takes the others out), before the game starts. */
    public void syncPackList() {
        Path options = gameDir.resolve("options.txt");
        try {
            List<String> lines = Files.exists(options) ? new ArrayList<>(Files.readAllLines(options, StandardCharsets.UTF_8)) : new ArrayList<>();
            int at = -1;
            JsonArray packs = new JsonArray();
            for (int i = 0; i < lines.size(); i++) {
                if (lines.get(i).startsWith("resourcePacks:")) {
                    at = i;
                    packs = JsonParser.parseString(lines.get(i).substring("resourcePacks:".length())).getAsJsonArray();
                }
            }
            List<String> ids = new ArrayList<>();
            for (JsonElement p : packs) ids.add(p.getAsString());
            if (!ids.contains("vanilla")) ids.add(0, "vanilla");
            boolean changed = false;
            for (Entry e : CATALOG) {
                if (e.kind() != Kind.PACK) continue;
                String f = file(e);
                if (f == null) continue;
                String id = "file/" + f;
                boolean want = enabled(e) && Files.exists(dir(Kind.PACK).resolve(f));
                boolean has = ids.contains(id);
                if (want && !has) { ids.add(id); changed = true; }
                if (!want && has) { ids.remove(id); changed = true; }
            }
            if (!changed && at >= 0) return;
            JsonArray out = new JsonArray();
            ids.forEach(out::add);
            String line = "resourcePacks:" + out;
            if (at >= 0) lines.set(at, line); else lines.add(line);
            Files.createDirectories(gameDir);
            Files.write(options, lines, StandardCharsets.UTF_8);
        } catch (IOException | RuntimeException ignored) {
        }
    }

    // ---- Modrinth ----

    private JsonObject newestVersion(String slug, Kind kind) throws IOException, InterruptedException {
        String url = API + "/project/" + enc(slug) + "/version?game_versions=" + enc("[\"" + mc + "\"]")
                + (kind == Kind.MOD ? "&loaders=" + enc("[\"fabric\"]") : "");
        JsonArray list = JsonParser.parseString(get(url)).getAsJsonArray();
        JsonObject firstAny = null;
        for (JsonElement v : list) {
            JsonObject o = v.getAsJsonObject();
            if (firstAny == null) firstAny = o;
            if ("release".equals(o.get("version_type").getAsString())) return o;
        }
        return firstAny;
    }

    private static String projectSlug(String projectId) throws IOException, InterruptedException {
        JsonObject p = JsonParser.parseString(get(API + "/project/" + enc(projectId))).getAsJsonObject();
        return p.has("slug") ? p.get("slug").getAsString() : null;
    }

    private static String get(String url) throws IOException, InterruptedException {
        HttpResponse<String> res = HTTP.send(HttpRequest.newBuilder(URI.create(url)).timeout(Duration.ofSeconds(25))
                .header("User-Agent", "AstraClient/0.1 (Minecraft client, github.com/admin123527h/astraclient)").GET().build(), HttpResponse.BodyHandlers.ofString());
        if (res.statusCode() / 100 != 2) throw new IOException("Modrinth answered HTTP " + res.statusCode());
        return res.body();
    }

    private static void download(String url, Path target, String sha512) throws IOException, InterruptedException {
        Files.createDirectories(target.getParent());
        Path tmp = target.resolveSibling(target.getFileName() + ".part");
        HttpResponse<Path> res = HTTP.send(HttpRequest.newBuilder(URI.create(url)).timeout(Duration.ofMinutes(3))
                .header("User-Agent", "AstraClient/0.1 (Minecraft client)").GET().build(), HttpResponse.BodyHandlers.ofFile(tmp));
        if (res.statusCode() / 100 != 2) {
            Files.deleteIfExists(tmp);
            throw new IOException("Download failed (HTTP " + res.statusCode() + ")");
        }
        try {
            MessageDigest md = MessageDigest.getInstance("SHA-512");
            String actual = HexFormat.of().formatHex(md.digest(Files.readAllBytes(tmp)));
            if (!actual.equalsIgnoreCase(sha512)) throw new IOException("Checksum mismatch, file not used");
            Files.move(tmp, target, StandardCopyOption.REPLACE_EXISTING);
        } catch (java.security.NoSuchAlgorithmException e) {
            throw new IOException(e);
        } finally {
            Files.deleteIfExists(tmp);
        }
    }

    private static String enc(String s) {
        return URLEncoder.encode(s, StandardCharsets.UTF_8);
    }
}
