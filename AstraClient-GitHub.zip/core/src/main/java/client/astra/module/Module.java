package client.astra.module;

public abstract class Module {
    public enum Category { HUD, VISUAL, UTILITY, MUSIC }

    private final String name;
    private final Category category;
    private boolean enabled;

    protected Module(String name, Category category) {
        this.name = name;
        this.category = category;
    }

    public String name() { return name; }
    public Category category() { return category; }
    public boolean enabled() { return enabled; }

    public void setEnabled(boolean value) {
        if (value == enabled) return;
        enabled = value;
        if (value) onEnable(); else onDisable();
    }

    public void toggle() { setEnabled(!enabled); }

    protected void onEnable() {}
    protected void onDisable() {}
}
