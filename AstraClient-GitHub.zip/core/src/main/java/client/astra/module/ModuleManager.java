package client.astra.module;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

public final class ModuleManager {
    private final List<Module> modules = new ArrayList<>();

    public void register(Module m) {
        if (get(m.name()).isPresent()) throw new IllegalArgumentException("duplicate module: " + m.name());
        modules.add(m);
    }

    public Optional<Module> get(String name) {
        return modules.stream().filter(m -> m.name().equalsIgnoreCase(name)).findFirst();
    }

    public List<Module> byCategory(Module.Category c) {
        return modules.stream().filter(m -> m.category() == c).toList();
    }

    public List<Module> all() { return List.copyOf(modules); }
}
