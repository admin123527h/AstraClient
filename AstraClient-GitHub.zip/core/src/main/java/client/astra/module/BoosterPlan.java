package client.astra.module;

/**
 * What the FPS booster changes at each level, computed from the player's own settings (the baseline).
 * Level 0 is the baseline; every level keeps the changes of the levels below it.
 */
public final class BoosterPlan {
    public static final int MAX_LEVEL = 5;

    public record Settings(int renderDistance, int simulationDistance, double entityDistance, boolean clouds,
                           boolean minimalParticles, int biomeBlend, String skyQuality) {}

    private BoosterPlan() {}

    public static Settings at(int level, Settings base) {
        int rd = base.renderDistance();
        int sim = base.simulationDistance();
        double ed = base.entityDistance();
        boolean clouds = base.clouds();
        boolean minimal = base.minimalParticles();
        int blend = base.biomeBlend();
        String sky = base.skyQuality();
        if (level >= 1) sky = "Low";
        if (level >= 2) {
            clouds = false;
            minimal = true;
        }
        if (level >= 3) {
            ed = Math.min(ed, 0.75);
            blend = Math.min(blend, 1);
        }
        if (level >= 4) rd = Math.min(rd, 10);
        if (level >= 5) {
            rd = Math.min(rd, 6);
            sim = Math.min(sim, 6);
        }
        return new Settings(rd, sim, ed, clouds, minimal, blend, sky);
    }

    /** Preset levels for the quick buttons. */
    public static int levelOf(String preset) {
        return switch (preset) {
            case "Balanced" -> 2;
            case "Fast" -> 4;
            case "Potato" -> 5;
            default -> 0;
        };
    }
}
