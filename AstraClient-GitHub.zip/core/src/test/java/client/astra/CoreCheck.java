package client.astra;

import client.astra.lyrics.*;
import client.astra.module.Module;
import client.astra.module.ModuleManager;
import java.util.List;

public class CoreCheck {
    static void check(boolean ok, String msg) {
        if (!ok) throw new AssertionError(msg);
        System.out.println("ok: " + msg);
    }

    public static void main(String[] args) {
        List<LyricLine> l = LrcParser.parse("[ti:x]\n[00:01.50]Hello\n[00:05.00][00:20.5]Chorus\n[01:00.00]End\n");
        check(l.size() == 4, "parses 4 timed lines, skips metadata");
        check(l.get(0).timeMs() == 1500 && l.get(0).text().equals("Hello"), "first line time/text");
        check(l.get(2).timeMs() == 20500, "multi-tag line expands and sorts");

        LyricsTimeline t = new LyricsTimeline(l);
        check(t.indexAt(0) == -1, "before first line");
        check(t.indexAt(1500) == 0, "at first line");
        check(t.indexAt(19999) == 1, "between lines");
        check(t.indexAt(999999) == 3, "after last line");
        check(Math.abs(t.progressAt(3250) - 0.5f) < 0.01f, "line progress");

        ModuleManager mm = new ModuleManager();
        Module m = new Module("Lyrics", Module.Category.MUSIC) {};
        mm.register(m);
        m.toggle();
        check(mm.get("lyrics").orElseThrow().enabled(), "module registry + toggle");
        try { mm.register(new Module("Lyrics", Module.Category.HUD) {}); check(false, "dup"); }
        catch (IllegalArgumentException e) { check(true, "duplicate module rejected"); }
    }
}
