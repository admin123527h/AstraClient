package client.astra.module;

/** Block outline colours need the 26.3 render API; this build keeps the vanilla outline. */
public final class Outlines {
    private Outlines() {}

    public static boolean supported() { return false; }

    public static void init() {}

    public static boolean hitboxes() { return false; }

    public static void toggleHitboxes() {}
}
