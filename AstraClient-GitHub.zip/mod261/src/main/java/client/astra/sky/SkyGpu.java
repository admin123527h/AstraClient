package client.astra.sky;

/** The shader sky needs the 26.3 render API; this build for older 26.x versions keeps the vanilla sky. */
final class SkyGpu {
    private SkyGpu() {}

    static void init() {}
}
