package client.astra.music;

import java.util.Optional;

/** Fake player used with -Dastra.dev=true so the HUD and lyrics can be tested without Spotify. */
public final class DevMusicProvider implements MusicProvider {
    public static final String LRC = String.join("\n",
            "[00:02.00]Let the music light up the sky",
            "[00:08.00]We keep on dancing till the morning light",
            "[00:14.00]Hold on tight, never let go",
            "[00:20.00]Stars are falling down below",
            "[00:26.00]Sing it loud, sing it clear");

    private final long start = System.currentTimeMillis();

    @Override
    public Optional<Track> current() {
        long pos = (System.currentTimeMillis() - start + 3000) % 30000;
        return Optional.of(new Track("Sky Lights", "Astra", 30000, pos, true));
    }
}
