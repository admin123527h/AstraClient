package client.astra.music;

import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Locale;
import java.util.Optional;
import java.util.concurrent.CompletableFuture;

/**
 * "Now playing" and the transport buttons through the operating system's own media session (the one the keyboard
 * media keys and the Windows volume flyout use). Spotify's desktop app publishes there, so this works with a free
 * Spotify account and needs no login, no Client ID and no Premium. Windows uses a small PowerShell helper, Linux uses
 * playerctl when it is installed.
 */
public final class SystemMedia implements MusicProvider {
    private static final boolean WINDOWS = System.getProperty("os.name", "").toLowerCase(Locale.ROOT).contains("win");
    private static final boolean LINUX = System.getProperty("os.name", "").toLowerCase(Locale.ROOT).contains("linux");

    private volatile boolean present;
    private volatile String title = "";
    private volatile String artist = "";
    private volatile long durationMs;
    private volatile long basePositionMs;
    private volatile long baseTimeMs;
    private volatile boolean playing;
    private volatile String problem = "";
    private volatile Process process;

    public SystemMedia() {
        if (WINDOWS || LINUX) {
            Thread t = new Thread(this::run, "astra-system-media");
            t.setDaemon(true);
            t.start();
        }
    }

    @Override
    public String problem() { return present ? "" : problem; }

    @Override
    public Optional<Track> current() {
        if (!present) return Optional.empty();
        long pos = playing ? basePositionMs + (System.currentTimeMillis() - baseTimeMs) : basePositionMs;
        return Optional.of(new Track(title, artist, durationMs, durationMs > 0 ? Math.min(pos, durationMs) : pos, playing));
    }

    // ---- controls ----

    public CompletableFuture<String> play() { return control("play", 0); }
    public CompletableFuture<String> pause() { return control("pause", 0); }
    public CompletableFuture<String> next() { return control("next", 0); }
    public CompletableFuture<String> previous() { return control("prev", 0); }
    public CompletableFuture<String> seek(long ms) { return control("seek", ms); }

    /** Null on success, else a short reason. */
    private CompletableFuture<String> control(String action, long arg) {
        return CompletableFuture.supplyAsync(() -> {
            if (!present && !action.equals("play")) return "No player found. Start Spotify (or another player) first.";
            try {
                Process p;
                if (WINDOWS) {
                    p = new ProcessBuilder(powershell(), "-NoProfile", "-NonInteractive", "-ExecutionPolicy", "Bypass", "-WindowStyle", "Hidden",
                            "-File", script().toString(), "-Action", action, "-Arg", Long.toString(arg)).redirectErrorStream(true).start();
                } else {
                    String cmd = switch (action) {
                        case "play" -> "play";
                        case "pause" -> "pause";
                        case "next" -> "next";
                        case "prev" -> "previous";
                        default -> "position";
                    };
                    p = action.equals("seek")
                            ? new ProcessBuilder("playerctl", "position", Double.toString(arg / 1000.0)).redirectErrorStream(true).start()
                            : new ProcessBuilder("playerctl", cmd).redirectErrorStream(true).start();
                }
                String out = new String(p.getInputStream().readAllBytes(), StandardCharsets.UTF_8).trim();
                if (!p.waitFor(8, java.util.concurrent.TimeUnit.SECONDS)) {
                    p.destroyForcibly();
                    return "The media session did not answer";
                }
                // Show the next poll result quickly.
                baseTimeMs = System.currentTimeMillis();
                if (action.equals("pause")) { basePositionMs = currentPosition(); playing = false; }
                if (action.equals("play")) { playing = true; }
                return p.exitValue() == 0 && !out.startsWith("FAILED") ? null : (out.isEmpty() ? "The player refused the command" : out);
            } catch (IOException | InterruptedException e) {
                return "Media control unavailable: " + e.getMessage();
            }
        });
    }

    private long currentPosition() {
        return playing ? basePositionMs + (System.currentTimeMillis() - baseTimeMs) : basePositionMs;
    }

    // ---- polling ----

    private void run() {
        while (true) {
            try {
                if (WINDOWS) pollWindows();
                else pollLinux();
            } catch (Exception e) {
                present = false;
                problem = "Media session: " + e.getMessage();
            }
            try {
                Thread.sleep(5000);
            } catch (InterruptedException e) {
                return;
            }
        }
    }

    /** The helper prints one JSON line per second; this reads them until the helper ends. */
    private void pollWindows() throws IOException {
        Process p = new ProcessBuilder(powershell(), "-NoProfile", "-NonInteractive", "-ExecutionPolicy", "Bypass", "-WindowStyle", "Hidden",
                "-File", script().toString(), "-Action", "poll").redirectErrorStream(true).start();
        process = p;
        try (BufferedReader r = new BufferedReader(new InputStreamReader(p.getInputStream(), StandardCharsets.UTF_8))) {
            for (String line; (line = r.readLine()) != null; ) {
                if (!accept(line)) {
                    String t = line.trim();
                    if (!t.isEmpty()) problem = "Media helper: " + (t.length() > 120 ? t.substring(0, 120) : t);
                }
            }
        } finally {
            p.destroy();
            present = false;
        }
    }

    private void pollLinux() throws IOException, InterruptedException {
        while (true) {
            Process p = new ProcessBuilder("playerctl", "metadata", "--format",
                    "{{title}}\t{{artist}}\t{{mpris:length}}\t{{position}}\t{{status}}").redirectErrorStream(true).start();
            String out = new String(p.getInputStream().readAllBytes(), StandardCharsets.UTF_8).trim();
            p.waitFor();
            String[] f = out.split("\t", -1);
            if (p.exitValue() != 0 || f.length < 5) {
                present = false;
                problem = "No media player found (install playerctl and start a player).";
                return;
            }
            JsonObject o = new JsonObject();
            o.addProperty("ok", true);
            o.addProperty("title", f[0]);
            o.addProperty("artist", f[1]);
            o.addProperty("dur", parse(f[2]) / 1000);
            o.addProperty("pos", parse(f[3]) / 1000);
            o.addProperty("playing", f[4].equalsIgnoreCase("playing"));
            accept(o.toString());
            Thread.sleep(1000);
        }
    }

    private static long parse(String s) {
        try {
            return Long.parseLong(s.trim());
        } catch (NumberFormatException e) {
            return 0;
        }
    }

    /** Parses one helper line. Public for the tests. */
    boolean accept(String line) {
        try {
            JsonObject o = JsonParser.parseString(line.trim()).getAsJsonObject();
            if (!o.has("ok") || !o.get("ok").getAsBoolean()) {
                present = false;
                problem = "No media session yet. Start playing a song in Spotify.";
                return true;
            }
            String t = o.has("title") ? o.get("title").getAsString() : "";
            if (t.isBlank()) {
                present = false;
                return true;
            }
            title = t;
            artist = o.has("artist") ? o.get("artist").getAsString() : "";
            durationMs = o.has("dur") ? o.get("dur").getAsLong() : 0;
            basePositionMs = o.has("pos") ? o.get("pos").getAsLong() : 0;
            baseTimeMs = System.currentTimeMillis();
            JsonElement pl = o.get("playing");
            playing = pl != null && (pl.getAsString().equals("true") || pl.getAsString().equals("1"));
            present = true;
            problem = "";
            return true;
        } catch (RuntimeException e) {
            return false;
        }
    }

    // ---- Windows helper script ----

    private static Path script;

    private static String powershell() {
        String root = System.getenv("SystemRoot");
        Path ps = Path.of(root == null ? "C:\\Windows" : root, "System32", "WindowsPowerShell", "v1.0", "powershell.exe");
        return Files.exists(ps) ? ps.toString() : "powershell";
    }

    private static synchronized Path script() throws IOException {
        if (script == null) {
            Path file = Files.createTempFile("astra-media", ".ps1");
            try (var in = SystemMedia.class.getResourceAsStream("/astra-media.ps1")) {
                if (in == null) throw new IOException("astra-media.ps1 is missing from the mod");
                Files.write(file, in.readAllBytes());
            }
            file.toFile().deleteOnExit();
            script = file;
        }
        return script;
    }
}
