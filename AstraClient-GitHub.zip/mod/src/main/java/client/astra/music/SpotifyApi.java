package client.astra.music;

import client.astra.Astra;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import java.net.URI;
import java.net.URLEncoder;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.CompletableFuture;

/** Spotify Web API wrapper: playback control, playlists, liked songs and search. Playback needs Premium. */
public final class SpotifyApi {
    public record Item(String uri, String name, String artist, long durationMs) {}
    public record Playlist(String id, String name, int tracks) {}

    private static final HttpClient HTTP = HttpClient.newHttpClient();
    private final SpotifyAuth auth;

    public SpotifyApi(SpotifyAuth auth) {
        this.auth = auth;
    }

    // ---- playback ----

    public CompletableFuture<String> play() { return command("PUT", "/me/player/play", null); }
    public CompletableFuture<String> pause() { return command("PUT", "/me/player/pause", null); }
    public CompletableFuture<String> next() { return command("POST", "/me/player/next", null); }
    public CompletableFuture<String> previous() { return command("POST", "/me/player/previous", null); }
    public CompletableFuture<String> seek(long ms) { return command("PUT", "/me/player/seek?position_ms=" + ms, null); }
    public CompletableFuture<String> volume(int percent) { return command("PUT", "/me/player/volume?volume_percent=" + percent, null); }

    public CompletableFuture<String> playUris(List<String> uris, int offset) {
        JsonObject body = new JsonObject();
        JsonArray arr = new JsonArray();
        uris.stream().skip(Math.max(0, offset)).limit(100).forEach(arr::add);
        body.add("uris", arr);
        return command("PUT", "/me/player/play", body.toString());
    }

    public CompletableFuture<String> playPlaylist(String playlistId, String trackUri) {
        JsonObject body = new JsonObject();
        body.addProperty("context_uri", "spotify:playlist:" + playlistId);
        if (trackUri != null) {
            JsonObject off = new JsonObject();
            off.addProperty("uri", trackUri);
            body.add("offset", off);
        }
        return command("PUT", "/me/player/play", body.toString());
    }

    /** Returns null on success, otherwise a short message for the UI. */
    private CompletableFuture<String> command(String method, String path, String body) {
        return CompletableFuture.supplyAsync(() -> {
            if (Astra.DEV) return null;
            try {
                HttpResponse<String> r = send(method, path, body);
                int c = r.statusCode();
                if (c >= 200 && c < 300) return null;
                if (c == 403) return "Spotify Premium required";
                if (c == 404) return "No active device - open Spotify";
                if (c == 401) return "Not logged in";
                return "Spotify error " + c;
            } catch (Exception e) {
                return "Spotify unreachable";
            }
        });
    }

    // ---- library ----

    public CompletableFuture<List<Playlist>> playlists() {
        return CompletableFuture.supplyAsync(() -> {
            List<Playlist> out = new ArrayList<>();
            if (Astra.DEV) {
                out.add(new Playlist("dev1", "Night Drive", 24));
                out.add(new Playlist("dev2", "Chill Vibes", 58));
                out.add(new Playlist("dev3", "PvP Focus", 31));
                return out;
            }
            try {
                JsonObject o = get("/me/playlists?limit=50");
                for (JsonElement e : o.getAsJsonArray("items")) {
                    if (e.isJsonNull()) continue;
                    JsonObject p = e.getAsJsonObject();
                    int n = 0;
                    JsonElement t = p.has("tracks") ? p.get("tracks") : p.get("items");
                    if (t != null && t.isJsonObject() && t.getAsJsonObject().has("total")) n = t.getAsJsonObject().get("total").getAsInt();
                    out.add(new Playlist(p.get("id").getAsString(), p.get("name").getAsString(), n));
                }
            } catch (Exception ignored) {
            }
            return out;
        });
    }

    public CompletableFuture<List<Item>> playlistItems(String id) {
        return CompletableFuture.supplyAsync(() -> {
            if (Astra.DEV) return devItems(id);
            for (String suffix : new String[] {"/items", "/tracks"}) {
                try {
                    return parseEntries(get("/playlists/" + id + suffix + "?limit=100"));
                } catch (Exception ignored) {
                }
            }
            return new ArrayList<>();
        });
    }

    public CompletableFuture<List<Item>> liked() {
        return CompletableFuture.supplyAsync(() -> {
            if (Astra.DEV) return devItems("liked");
            try {
                return parseEntries(get("/me/tracks?limit=50"));
            } catch (Exception e) {
                return new ArrayList<>();
            }
        });
    }

    public CompletableFuture<List<Item>> search(String query) {
        return CompletableFuture.supplyAsync(() -> {
            if (Astra.DEV) return devItems("search:" + query);
            try {
                JsonObject o = get("/search?type=track&limit=30&q=" + URLEncoder.encode(query, StandardCharsets.UTF_8));
                List<Item> out = new ArrayList<>();
                for (JsonElement e : o.getAsJsonObject("tracks").getAsJsonArray("items")) {
                    Item it = toItem(e);
                    if (it != null) out.add(it);
                }
                return out;
            } catch (Exception e) {
                return new ArrayList<>();
            }
        });
    }

    // ---- helpers ----

    private static List<Item> devItems(String seed) {
        List<Item> out = new ArrayList<>();
        String[] names = {"Sky Lights", "Midnight Run", "Neon Horizon", "Aurora", "Blood Moon", "Cherry Blossom", "Solar Eclipse", "End Beams"};
        for (int i = 0; i < names.length; i++) {
            out.add(new Item("spotify:track:dev" + seed + i, names[i], "Astra", 180000 + i * 7000L));
        }
        return out;
    }

    private static List<Item> parseEntries(JsonObject page) {
        List<Item> out = new ArrayList<>();
        for (JsonElement e : page.getAsJsonArray("items")) {
            if (e.isJsonNull()) continue;
            JsonObject entry = e.getAsJsonObject();
            JsonElement t = entry.has("track") ? entry.get("track") : entry.get("item");
            Item it = toItem(t);
            if (it != null) out.add(it);
        }
        return out;
    }

    private static Item toItem(JsonElement t) {
        if (t == null || !t.isJsonObject()) return null;
        JsonObject o = t.getAsJsonObject();
        if (!o.has("uri") || o.get("uri").isJsonNull() || o.get("name").isJsonNull()) return null;
        String artist = "";
        if (o.has("artists") && o.getAsJsonArray("artists").size() > 0) {
            artist = o.getAsJsonArray("artists").get(0).getAsJsonObject().get("name").getAsString();
        }
        return new Item(o.get("uri").getAsString(), o.get("name").getAsString(), artist, o.get("duration_ms").getAsLong());
    }

    private JsonObject get(String path) throws Exception {
        HttpResponse<String> r = send("GET", path, null);
        if (r.statusCode() != 200) throw new IllegalStateException("status " + r.statusCode());
        return JsonParser.parseString(r.body()).getAsJsonObject();
    }

    private HttpResponse<String> send(String method, String path, String body) throws Exception {
        String token = auth.accessToken();
        if (token == null) throw new IllegalStateException("not logged in");
        HttpRequest.Builder b = HttpRequest.newBuilder(URI.create("https://api.spotify.com/v1" + path))
                .header("Authorization", "Bearer " + token);
        if (body != null) b.header("Content-Type", "application/json");
        b.method(method, body == null ? HttpRequest.BodyPublishers.noBody() : HttpRequest.BodyPublishers.ofString(body));
        return HTTP.send(b.build(), HttpResponse.BodyHandlers.ofString());
    }
}
