package client.astra.music;

import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.util.Optional;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

public final class SpotifyProvider implements MusicProvider {
    private static final HttpClient HTTP = HttpClient.newHttpClient();

    private final SpotifyAuth auth;
    private final ScheduledExecutorService pool = Executors.newSingleThreadScheduledExecutor(r -> {
        Thread t = new Thread(r, "astra-spotify");
        t.setDaemon(true);
        return t;
    });

    private volatile String id = "";
    private volatile String title = "";
    private volatile String artist = "";
    private volatile String coverUrl = "";
    private volatile long durationMs;
    private volatile long basePositionMs;
    private volatile long baseTimeMs;
    private volatile boolean playing;
    private volatile boolean present;
    private volatile String problem = "";

    public SpotifyProvider(SpotifyAuth auth) {
        this.auth = auth;
        pool.scheduleWithFixedDelay(this::poll, 0, 1500, TimeUnit.MILLISECONDS);
    }

    public SpotifyAuth auth() { return auth; }
    public String trackId() { return id; }

    @Override
    public String problem() { return problem; }
    public String coverUrl() { return coverUrl; }

    @Override
    public Optional<Track> current() {
        if (!present) return Optional.empty();
        long pos = playing ? basePositionMs + (System.currentTimeMillis() - baseTimeMs) : basePositionMs;
        return Optional.of(new Track(title, artist, durationMs, Math.min(pos, durationMs), playing));
    }

    private void poll() {
        try {
            String token = auth.accessToken();
            if (token == null) {
                present = false;
                problem = auth.loggedIn() ? auth.lastError() : "";
                return;
            }
            HttpRequest req = HttpRequest.newBuilder(URI.create("https://api.spotify.com/v1/me/player/currently-playing"))
                    .header("Authorization", "Bearer " + token).GET().build();
            HttpResponse<String> res = HTTP.send(req, HttpResponse.BodyHandlers.ofString());
            int code = res.statusCode();
            if (code == 403) {
                present = false;
                problem = "Spotify says 403: add your account under User Management in the Spotify dashboard.";
                return;
            }
            if (code == 401) { present = false; problem = "Spotify login expired. Connect Spotify again."; return; }
            if (code == 429) { present = false; problem = "Spotify is limiting requests. Wait a moment."; return; }
            if (code != 200 || res.body().isEmpty()) { present = false; problem = ""; return; }
            problem = "";
            JsonObject root = JsonParser.parseString(res.body()).getAsJsonObject();
            JsonElement item = root.get("item");
            if (item == null || item.isJsonNull()) { present = false; return; }
            JsonObject t = item.getAsJsonObject();
            id = t.get("id").getAsString();
            title = t.get("name").getAsString();
            artist = t.getAsJsonArray("artists").get(0).getAsJsonObject().get("name").getAsString();
            durationMs = t.get("duration_ms").getAsLong();
            JsonObject images = t.getAsJsonObject("album");
            if (images != null && images.has("images") && images.getAsJsonArray("images").size() > 0) {
                coverUrl = images.getAsJsonArray("images").get(images.getAsJsonArray("images").size() - 1).getAsJsonObject().get("url").getAsString();
            }
            basePositionMs = root.get("progress_ms").getAsLong();
            baseTimeMs = System.currentTimeMillis();
            playing = root.get("is_playing").getAsBoolean();
            present = true;
        } catch (Exception e) {
            present = false;
        }
    }
}
