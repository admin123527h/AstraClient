package client.astra.music;

import java.util.Optional;

/** Spotify's own data when it is connected and playing, otherwise whatever the system media session reports. */
public final class HybridProvider implements MusicProvider {
    private final SpotifyProvider spotify;
    private final SystemMedia system;

    public HybridProvider(SpotifyProvider spotify, SystemMedia system) {
        this.spotify = spotify;
        this.system = system;
    }

    public boolean spotifyIsSource() { return spotify.current().isPresent(); }

    @Override
    public Optional<Track> current() {
        Optional<Track> s = spotify.current();
        return s.isPresent() ? s : system.current();
    }

    @Override
    public String problem() {
        if (spotify.current().isPresent() || system.current().isPresent()) return "";
        String s = spotify.problem();
        return s.isEmpty() ? system.problem() : s;
    }
}
