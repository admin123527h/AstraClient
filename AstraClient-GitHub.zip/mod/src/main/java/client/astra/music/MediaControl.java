package client.astra.music;

import client.astra.Astra;

import java.util.concurrent.CompletableFuture;

/**
 * The play / pause / skip / seek buttons. When Spotify is connected they go through Spotify (which needs Premium);
 * when that is not possible, or Spotify is not connected, they go through the system media session, which works for
 * everyone. Every method returns null on success or a short message.
 */
public final class MediaControl {
    private MediaControl() {}

    private interface Command {
        CompletableFuture<String> run(SpotifyApi api);
    }

    private static CompletableFuture<String> send(Command viaSpotify, java.util.function.Function<SystemMedia, CompletableFuture<String>> viaSystem) {
        SystemMedia system = Astra.system();
        if (Astra.SPOTIFY_AUTH.loggedIn() && Astra.spotifyIsSource()) {
            return viaSpotify.run(Astra.SPOTIFY_API).thenCompose(error -> error == null ? CompletableFuture.completedFuture((String) null) : viaSystem.apply(system));
        }
        return viaSystem.apply(system);
    }

    public static CompletableFuture<String> play() { return send(SpotifyApi::play, SystemMedia::play); }
    public static CompletableFuture<String> pause() { return send(SpotifyApi::pause, SystemMedia::pause); }
    public static CompletableFuture<String> next() { return send(SpotifyApi::next, SystemMedia::next); }
    public static CompletableFuture<String> previous() { return send(SpotifyApi::previous, SystemMedia::previous); }
    public static CompletableFuture<String> seek(long ms) { return send(api -> api.seek(ms), m -> m.seek(ms)); }
}
