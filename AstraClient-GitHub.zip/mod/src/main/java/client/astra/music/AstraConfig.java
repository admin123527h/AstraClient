package client.astra.music;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.fabricmc.loader.api.FabricLoader;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;

public final class AstraConfig {
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static final Path FILE = FabricLoader.getInstance().getConfigDir().resolve("astra.json");
    private static AstraConfig instance;

    public String spotifyClientId = "";
    public String spotifyRefreshToken = "";
    public int spotifyScopeVersion = 0;
    public boolean lyricsEnabled = true;
    public boolean menuBlur = false;
    public boolean hudFps = true;
    public boolean hudPing = true;
    public boolean hudMusic = true;
    public String lyricsStyle = "Clean";
    public String lyricsFont = "Poppins";
    public int lyricsColor1 = 0xFFFFFF;
    public int lyricsColor2 = 0xC4B5FD;
    public float lyricsGlow = 0f;
    public boolean lyricsWordByWord = true;
    public boolean lyricsReveal = true;
    public boolean skyEnabled = true;
    public String sky = "Northern Lights";
    public String lyricsMode = "Floating";
    public float lyricsSize = 1.0f;
    /** Each word stays in the air where you were looking when it appeared. */
    public boolean lyricsTrail = false;
    /** A line shows this many ms before it is sung (never before the previous line is done). 0 = words appear one by one. */
    public int lyricsLeadMs = 2000;
    public boolean announceSong = true;

    // sky and performance
    public String skyQuality = "High";
    public boolean boosterAdaptive = false;
    public int boosterTarget = 60;

    // modules
    public boolean zoomEnabled = true;
    public int zoomPercent = 25;
    public boolean zoomToggle = false;
    public boolean zoomCinematic = true;
    public boolean zoomSlowMouse = true;
    public java.util.Map<String, String> itemSkins = new java.util.HashMap<>();
    public java.util.Map<String, String> itemSkinsApplied = new java.util.HashMap<>();
    public boolean fullbright = false;
    public boolean outlines = false;
    public int outlineColor = 0xA78BFA;

    /** The player's own Spotify Client ID, else the one the launcher passes from the project's update manifest. */
    public String clientId() {
        if (spotifyClientId != null && !spotifyClientId.isBlank()) return spotifyClientId.trim();
        String shared = System.getProperty("astra.spotifyClientId");
        return shared == null ? "" : shared.trim();
    }

    public static synchronized AstraConfig get() {
        if (instance == null) {
            try {
                instance = Files.exists(FILE) ? GSON.fromJson(Files.readString(FILE), AstraConfig.class) : new AstraConfig();
            } catch (IOException | RuntimeException e) {
                instance = new AstraConfig();
            }
            if (instance == null) instance = new AstraConfig();
        }
        return instance;
    }

    public synchronized void save() {
        try {
            Files.writeString(FILE, GSON.toJson(this));
        } catch (IOException ignored) {
        }
    }
}
