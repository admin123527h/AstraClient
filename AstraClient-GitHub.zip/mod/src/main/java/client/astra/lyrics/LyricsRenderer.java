package client.astra.lyrics;

import client.astra.Astra;
import client.astra.hud.Draw;
import client.astra.hud.Fonts;
import client.astra.music.AstraConfig;
import client.astra.music.MusicProvider;
import net.fabricmc.fabric.api.client.rendering.v1.world.WorldRenderContext;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.render.Camera;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.math.Vec3d;
import org.joml.Quaternionf;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

/** Draws the current lyric line as floating 3D text, highlighting the word being sung. */
public final class LyricsRenderer {
    private static final int FULL_BRIGHT = 0xF000F0;
    private static final int MAX_ROW_WIDTH = 150;
    private static final long TEST_MS = 7000;
    private static final LyricsTimeline TEST_TIMELINE = new LyricsTimeline(List.of(
            new LyricLine(0, "Let the music light up the sky"), new LyricLine(TEST_MS - 400, "")));

    private static String placedKey = "";
    private static Vec3d anchor = Vec3d.ZERO;
    private static Quaternionf anchorRotation = new Quaternionf();
    /** Per word: where it was placed when it appeared (trail mode). */
    private static final List<Object[]> trail = new ArrayList<>();
    private static long testStart = -1;

    private LyricsRenderer() {}

    /** Shows a sample line in the world so a look can be previewed without any music playing. */
    public static void startTest() {
        testStart = System.currentTimeMillis();
        placedKey = "";
    }

    public static void render(WorldRenderContext ctx) {
        AstraConfig cfg = AstraConfig.get();
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.world == null || mc.player == null) return;

        boolean testing = testStart >= 0 && System.currentTimeMillis() - testStart < TEST_MS;
        MusicProvider.Track t;
        LyricsTimeline tl;
        String trackKey;
        if (testing) {
            t = new MusicProvider.Track("Test", "Astra", TEST_MS, System.currentTimeMillis() - testStart, true);
            tl = TEST_TIMELINE;
            trackKey = "test" + testStart;
        } else {
            if (!cfg.lyricsEnabled) return;
            Optional<MusicProvider.Track> opt = Astra.music().current();
            if (opt.isEmpty() || !opt.get().playing()) return;
            t = opt.get();
            tl = Astra.LYRICS.timeline();
            trackKey = t.artist() + "|" + t.title();
        }

        long lead = cfg.lyricsLeadMs;
        int cur = tl.indexAt(t.positionMs());
        int idx = cur;
        if (lead > 0 && tl.line(cur + 1) != null && t.positionMs() >= displayStart(tl, cur + 1, lead)) idx = cur + 1;
        if (idx < 0) return;
        LyricLine line = tl.line(idx);
        if (line.text().isBlank()) return;

        Camera camera = mc.gameRenderer.getCamera();
        Vec3d cam = camera.getCameraPos();
        String key = trackKey + "|" + idx;
        boolean follow = "Follow".equals(cfg.lyricsMode);
        if (!key.equals(placedKey)) {
            placedKey = key;
            float pitch = Math.max(-60f, Math.min(60f, mc.player.getPitch()));
            Vec3d look = Vec3d.fromPolar(pitch, mc.player.getYaw());
            anchor = cam.add(look.multiply(5.0));
            anchorRotation = new Quaternionf(camera.getRotation());
            trail.clear();
        }
        boolean trailMode = cfg.lyricsTrail && !follow;

        long lineStart = line.timeMs();
        LyricLine next = tl.line(idx + 1);
        long lineEnd = next != null ? next.timeMs() : lineStart + 4000;
        long dur = Math.max(800, Math.min(lineEnd - lineStart, 7000));
        long sinceStart = t.positionMs() - lineStart;

        float pop = ease(Math.min(1f, Math.max(0f, (t.positionMs() - displayStart(tl, idx, lead)) / 260f)));
        float fadeOut = Math.min(1f, Math.max(0f, (lineEnd - t.positionMs()) / 320f));
        float alpha = Math.min(pop, fadeOut);
        if (alpha <= 0.02f) return;

        Vec3d pos = follow ? cam.add(Vec3d.fromPolar(camera.getPitch(), camera.getYaw()).multiply(5.0)) : anchor;
        Quaternionf rot = follow ? camera.getRotation() : anchorRotation;
        float drift = Math.max(0, sinceStart) / 1000f * 0.04f;

        TextRenderer font = mc.textRenderer;
        String fontName = cfg.lyricsFont;
        List<List<String>> rows = wrap(font, fontName, line.text());
        int[] widths = new int[rows.size()];
        for (int r = 0; r < rows.size(); r++) widths[r] = Draw.width(font, String.join(" ", rows.get(r)), fontName);

        List<String> flat = new ArrayList<>();
        for (List<String> row : rows) flat.addAll(row);
        long[][] timing = client.astra.lyrics.WordTiming.estimate(flat, lineStart, dur);
        int wordIndex = 0;

        int sung = cfg.lyricsColor1;
        int active = cfg.lyricsColor2;
        int upcoming = Draw.mix(0xFF000000 | sung, 0x5E5878, 0.55f) & 0xFFFFFF;
        float glow = cfg.lyricsGlow;

        MatrixStack m = ctx.matrices();
        m.push();
        float s = 0.05f * cfg.lyricsSize * (0.82f + 0.18f * pop);
        if (!trailMode) {
            m.translate(pos.x - cam.x, pos.y - cam.y + drift, pos.z - cam.z);
            m.multiply(rot);
            m.scale(s, -s, s);
        }

        int spaceW = Draw.width(font, " ", fontName);
        float rowH = 12f;
        float top = -rows.size() * rowH / 2f;
        boolean reveal = cfg.lyricsReveal && lead <= 0;
        long p = t.positionMs();
        for (int r = 0; r < rows.size(); r++) {
            float x = -widths[r] / 2f;
            float y = top + r * rowH;
            for (String word : rows.get(r)) {
                long wStart = timing[0][wordIndex];
                long wEnd = timing[1][wordIndex];
                wordIndex++;
                int ww = Draw.width(font, word, fontName);
                float left = x;
                x += ww + spaceW;

                if (reveal && p < wStart) continue;

                int rgb;
                float lift = 0f;
                if (!cfg.lyricsWordByWord) {
                    rgb = active;
                } else if (p >= wEnd) {
                    rgb = sung;
                } else if (p >= wStart) {
                    rgb = active;
                    lift = -1.5f * (float) Math.sin(Math.PI * (p - wStart) / (double) Math.max(1, wEnd - wStart));
                } else {
                    rgb = upcoming;
                }

                boolean lit = !cfg.lyricsWordByWord || p >= wStart;
                float wp = reveal ? ease(Math.min(1f, Math.max(0f, (p - wStart) / 160f))) : 1f;
                int a = Math.max(4, (int) (255 * alpha * (reveal ? wp : lit ? 1f : (lead > 0 ? 0.55f : 0.7f))));
                var text = Fonts.of(word, fontName).asOrderedText();

                float cx = left + ww / 2f;
                float xn = cx / Math.max(30f, widths[r] / 2f);
                float noise = (((word.hashCode() + r * 31) & 0xFF) / 255f) * 2f - 1f;
                float tilt = xn * 0.045f + noise * 0.05f;
                float scale = reveal ? 0.55f + 0.45f * wp : 1f;
                float cy = y + 4.5f + lift + xn * xn * 2.4f + (reveal ? (1f - wp) * 3f : 0f);

                if (trailMode) {
                    Vec3d ap;
                    Quaternionf ar;
                    if (p >= wStart) {
                        Object[] a0 = trailAnchor(wordIndex - 1, cam, mc, camera);
                        ap = (Vec3d) a0[0];
                        ar = (Quaternionf) a0[1];
                    } else {
                        // not sung yet: shown dimly in front of you, it freezes in the air when its turn comes
                        float pitch2 = Math.max(-60f, Math.min(60f, mc.player.getPitch()));
                        ap = cam.add(Vec3d.fromPolar(pitch2, mc.player.getYaw()).multiply(5.0));
                        ar = camera.getRotation();
                    }
                    m.push();
                    m.translate(ap.x - cam.x, ap.y - cam.y + drift, ap.z - cam.z);
                    m.multiply(ar);
                    m.scale(s, -s, s);
                }
                m.push();
                m.translate(cx, cy, 0f);
                m.multiply(new Quaternionf().rotateZ(tilt));
                m.scale(scale, scale, 1f);
                if (glow > 0.01f && lit) {
                    int ga = Math.max(2, (int) (a * glow * 0.32f));
                    int gcol = (ga << 24) | active;
                    float o = 1.6f;
                    for (float[] d : new float[][] {{-o, 0}, {o, 0}, {0, -o}, {0, o}, {-o, -o}, {o, o}, {-o, o}, {o, -o}}) {
                        ctx.commandQueue().submitText(m, -ww / 2f + d[0], -4.5f + d[1], text, false,
                                TextRenderer.TextLayerType.SEE_THROUGH, FULL_BRIGHT, gcol, 0, 0);
                    }
                }
                ctx.commandQueue().submitText(m, -ww / 2f, -4.5f, text, glow < 0.01f,
                        TextRenderer.TextLayerType.SEE_THROUGH, FULL_BRIGHT, (a << 24) | rgb, 0, 0);
                m.pop();
                if (trailMode) m.pop();
            }
        }
        m.pop();
    }

    /** Where word i is placed: in front of where the player looks at the moment the word first shows, then it stays there. */
    private static Object[] trailAnchor(int i, Vec3d cam, MinecraftClient mc, Camera camera) {
        while (trail.size() <= i) trail.add(null);
        Object[] a = trail.get(i);
        if (a == null) {
            float pitch = Math.max(-60f, Math.min(60f, mc.player.getPitch()));
            Vec3d look = Vec3d.fromPolar(pitch, mc.player.getYaw());
            a = new Object[] {cam.add(look.multiply(5.0)), new Quaternionf(camera.getRotation())};
            trail.set(i, a);
        }
        return a;
    }

    /** When a line starts to show: `lead` ms before it is sung, but not before the previous line has been sung. */
    private static long displayStart(client.astra.lyrics.LyricsTimeline tl, int idx, long lead) {
        long start = tl.line(idx).timeMs();
        if (lead <= 0) return start;
        LyricLine prev = tl.line(idx - 1);
        long prevEnd = Long.MIN_VALUE;
        if (prev != null) {
            long dur = Math.max(800, Math.min(start - prev.timeMs(), 7000));
            prevEnd = prev.timeMs() + (long) (dur * 0.94);
        }
        return Math.max(prevEnd, start - lead);
    }

    private static List<List<String>> wrap(TextRenderer font, String fontName, String text) {
        List<List<String>> rows = new ArrayList<>();
        List<String> row = new ArrayList<>();
        int w = 0;
        int space = Draw.width(font, " ", fontName);
        for (String word : text.trim().split("\\s+")) {
            int ww = Draw.width(font, word, fontName) + space;
            if (!row.isEmpty() && w + ww > MAX_ROW_WIDTH) {
                rows.add(row);
                row = new ArrayList<>();
                w = 0;
            }
            row.add(word);
            w += ww;
        }
        if (!row.isEmpty()) rows.add(row);
        return rows;
    }

    private static float ease(float t) {
        return 1f - (1f - t) * (1f - t) * (1f - t);
    }
}
