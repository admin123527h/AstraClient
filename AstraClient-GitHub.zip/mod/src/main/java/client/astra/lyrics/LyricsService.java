package client.astra.lyrics;

import client.astra.music.MusicProvider;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import java.net.URI;
import java.net.URLEncoder;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;
import java.util.List;
import java.util.concurrent.CompletableFuture;

/** Fetches time-synced lyrics from lrclib.net and caches the one for the current track. */
public final class LyricsService {
    private static final HttpClient HTTP = HttpClient.newHttpClient();

    private volatile String loadedKey = "";
    private volatile LyricsTimeline timeline = new LyricsTimeline(List.of());

    public LyricsTimeline timeline() { return timeline; }

    public void preload(String key, List<LyricLine> lines) {
        loadedKey = key;
        timeline = new LyricsTimeline(lines);
    }

    public void ensure(MusicProvider.Track t) {
        String key = t.artist() + "|" + t.title();
        if (key.equals(loadedKey)) return;
        loadedKey = key;
        timeline = new LyricsTimeline(List.of());
        CompletableFuture.runAsync(() -> {
            try {
                String url = "https://lrclib.net/api/get?track_name=" + enc(t.title()) + "&artist_name=" + enc(t.artist())
                        + "&duration=" + (t.durationMs() / 1000);
                HttpResponse<String> res = HTTP.send(HttpRequest.newBuilder(URI.create(url))
                        .header("User-Agent", "AstraClient/0.1").GET().build(), HttpResponse.BodyHandlers.ofString());
                if (res.statusCode() != 200) return;
                JsonObject o = JsonParser.parseString(res.body()).getAsJsonObject();
                if (!o.has("syncedLyrics") || o.get("syncedLyrics").isJsonNull()) return;
                if (key.equals(loadedKey)) timeline = new LyricsTimeline(LrcParser.parse(o.get("syncedLyrics").getAsString()));
            } catch (Exception ignored) {
            }
        });
    }

    private static String enc(String s) {
        return URLEncoder.encode(s, StandardCharsets.UTF_8);
    }
}
