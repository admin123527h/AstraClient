package client.astra.lyrics;

import client.astra.music.AstraConfig;

import java.util.List;

/** A lyrics look preset: font, two colours and glow. Applying one copies its values into the config. */
public record LyricsStyle(String name, String font, int color1, int color2, float glow) {
    public static final List<LyricsStyle> ALL = List.of(
            new LyricsStyle("Lavender", "Poppins", 0xEDE9FE, 0xA78BFA, 0.25f),
            new LyricsStyle("Dreamy", "Pacifico", 0xFBCFE8, 0xF472B6, 0.35f),
            new LyricsStyle("Fight", "Luckiest", 0xFFFFFF, 0xEF4444, 0f),
            new LyricsStyle("Comic", "Bangers", 0xFFFFFF, 0xFACC15, 0f),
            new LyricsStyle("Script", "Brush", 0xF5F3FF, 0xDDD6FE, 0.2f),
            new LyricsStyle("Fire", "Lilita", 0xFDE68A, 0xF97316, 0.45f),
            new LyricsStyle("Ice", "Poppins", 0xE0F2FE, 0x7DD3FC, 0.3f),
            new LyricsStyle("Royal", "Abril", 0xFDE68A, 0xFBBF24, 0.2f),
            new LyricsStyle("Clean", "Poppins", 0xFFFFFF, 0xC4B5FD, 0f));

    public void apply(AstraConfig cfg) {
        cfg.lyricsStyle = name;
        cfg.lyricsFont = font;
        cfg.lyricsColor1 = color1;
        cfg.lyricsColor2 = color2;
        cfg.lyricsGlow = glow;
        cfg.save();
    }
}
