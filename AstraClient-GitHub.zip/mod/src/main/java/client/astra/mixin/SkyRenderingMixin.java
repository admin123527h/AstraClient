package client.astra.mixin;

import client.astra.sky.AstraSky;
import net.minecraft.client.render.SkyRendering;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(SkyRendering.class)
public abstract class SkyRenderingMixin {
    @Inject(method = "renderTopSky", at = @At("HEAD"), cancellable = true)
    private void astra$sky(CallbackInfo ci) {
        if (AstraSky.active()) {
            if (AstraSky.render()) ci.cancel();
        }
    }

    @Inject(method = "renderGlowingSky", at = @At("HEAD"), cancellable = true)
    private void astra$noGlow(CallbackInfo ci) {
        if (AstraSky.active()) ci.cancel();
    }

    @Inject(method = "renderCelestialBodies", at = @At("HEAD"), cancellable = true)
    private void astra$noBodies(CallbackInfo ci) {
        if (AstraSky.active()) ci.cancel();
    }

    @Inject(method = "renderSkyDark", at = @At("HEAD"), cancellable = true)
    private void astra$noDark(CallbackInfo ci) {
        if (AstraSky.active()) ci.cancel();
    }
}
