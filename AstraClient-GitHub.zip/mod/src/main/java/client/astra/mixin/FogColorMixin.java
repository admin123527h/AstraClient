package client.astra.mixin;

import client.astra.sky.AstraSky;
import net.minecraft.client.render.Camera;
import net.minecraft.client.render.fog.AtmosphericFogModifier;
import net.minecraft.client.world.ClientWorld;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(AtmosphericFogModifier.class)
public abstract class FogColorMixin {
    @Inject(method = "getFogColor", at = @At("RETURN"), cancellable = true)
    private void astra$fog(ClientWorld world, Camera camera, int viewDistance, float skyDarkness, CallbackInfoReturnable<Integer> cir) {
        if (AstraSky.active()) cir.setReturnValue(AstraSky.fogColor());
    }
}
