package client.astra.gui;

import client.astra.Astra;
import client.astra.hud.Draw;
import client.astra.lyrics.LyricsStyle;
import client.astra.music.AstraConfig;
import client.astra.sky.AstraSky;
import net.minecraft.client.gl.RenderPipelines;
import net.minecraft.util.Identifier;
import client.astra.music.MusicProvider;
import client.astra.music.SpotifyAuth;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.option.CloudRenderMode;
import net.minecraft.client.option.GameOptions;
import net.minecraft.particle.ParticlesMode;

import java.util.List;

/** The simple menu pages: Overview, Skies, Styles, HUD, Performance, Settings and Information. */
public final class MenuPages {
    public interface Host {
        void openTab(int tab);

        void clientIdField(DrawContext c, int x, int y, int w);

        void connectSpotify();
    }

    private final Ui ui;
    private final TextRenderer font;
    private final Host host;
    private String status = "";

    public MenuPages(Ui ui, TextRenderer font, Host host) {
        this.ui = ui;
        this.font = font;
        this.host = host;
    }

    public void setStatus(String s) { status = s; }

    /** Draws a page and returns its full content height (used for scrolling). */
    public int render(int tab, DrawContext c, int px, int py, int pw, int ph, int scroll, int mx, int my) {
        switch (tab) {
            case 0 -> overview(c, px, py, pw, mx, my);
            case 1 -> { return skies(c, px, py, pw, ph, scroll, mx, my); }
            case 4 -> styles(c, px, py, pw);
            case 5 -> hud(c, px, py, pw, mx, my);
            case 6 -> performance(c, px, py, pw, mx, my);
            case 7 -> settings(c, px, py, pw, ph, mx, my);
            case 8 -> information(c, px, py, pw);
            default -> { }
        }
        return 0;
    }

    // ---- Overview ----

    private void overview(DrawContext c, int px, int py, int pw, int mx, int my) {
        MinecraftClient mc = MinecraftClient.getInstance();
        AstraConfig cfg = AstraConfig.get();
        int cw = (pw - 6) / 2;
        stat(c, px, py, cw, "FPS", mc.getCurrentFps() + "");
        stat(c, px + cw + 6, py, cw, "Spotify", Astra.SPOTIFY_AUTH.loggedIn() ? "Connected" : "Not connected");
        stat(c, px, py + 44, cw, "Lyrics", cfg.lyricsEnabled ? cfg.lyricsStyle + " - " + cfg.lyricsMode : "Off");
        stat(c, px + cw + 6, py + 44, cw, "Render distance", mc.options.getViewDistance().getValue() + " chunks");

        Draw.panel(c, px, py + 88, pw, 40, Draw.BG_SOFT, Draw.BORDER, 5f);
        ui.label(c, px + 10, py + 95, "NOW PLAYING");
        var track = Astra.music().current();
        if (track.isPresent()) {
            MusicProvider.Track t = track.get();
            Draw.text(c, font, t.title() + " - " + t.artist(), px + 10, py + 108, Draw.TEXT);
        } else {
            Draw.text(c, font, "Nothing playing", px + 10, py + 108, Draw.TEXT_DIM);
        }

        int bw = (pw - 12) / 3;
        ui.button(c, px, py + 138, bw, "Open Spotify", false, () -> host.openTab(3), mx, my);
        ui.button(c, px + bw + 6, py + 138, bw, "Lyrics look", false, () -> host.openTab(2), mx, my);
        ui.button(c, px + (bw + 6) * 2, py + 138, bw, "Settings", false, () -> host.openTab(7), mx, my);
    }

    private void stat(DrawContext c, int x, int y, int w, String label, String value) {
        Draw.panel(c, x, y, w, 38, Draw.BG_SOFT, Draw.BORDER, 5f);
        ui.label(c, x + 10, y + 7, label.toUpperCase());
        Draw.text(c, font, value, x + 10, y + 21, Draw.TEXT);
    }

    // ---- Skies ----

    private int skies(DrawContext c, int px, int vy, int pw, int vh, int scroll, int mx, int my) {
        AstraConfig cfg = AstraConfig.get();
        c.enableScissor(px - 2, vy, px + pw + 2, vy + vh);
        ui.clip(px - 2, vy, pw + 4, vh);
        int top = vy - scroll;
        int y = top;

        ui.toggle(c, px, y, pw, "Sky on", cfg.skyEnabled, () -> { cfg.skyEnabled = !cfg.skyEnabled; cfg.save(); }, mx, my);
        y += 26;

        int cw = (pw - 18) / 4, ch = 64;
        for (int i = 0; i < AstraSky.NAMES.size(); i++) {
            String name = AstraSky.NAMES.get(i);
            int x = px + (i % 4) * (cw + 6), cy = y + (i / 4) * (ch + 6);
            boolean selected = name.equals(cfg.sky);
            boolean hover = mx >= x && mx < x + cw && my >= cy && my < cy + ch && my >= vy && my < vy + vh;
            ui.card(c, x, cy, cw, ch, selected, () -> { cfg.sky = name; cfg.skyEnabled = true; cfg.save(); }, mx, my);
            c.drawTexture(RenderPipelines.GUI_TEXTURED, Identifier.of("astra", "textures/gui/skies/sky_" + String.format("%02d", i) + ".png"),
                    x + 4, cy + 4, 0f, 0f, cw - 8, ch - 24, 256, 122, 256, 122);
            Draw.text(c, font, name, x + 6, cy + ch - 17, Draw.TEXT);
            if (hover) {
                Draw.panel(c, x + 7, cy + 7, 44, 12, 0xAA2A1D4D, Draw.BORDER, 5f);
                Draw.text(c, font, "Preview", x + 12, cy + 9, Draw.TEXT);
            }
            if (selected) {
                Draw.round(c, x + cw - 18, cy + 7, 11, 11, 0xFF8B5CF6);
                int[][] tick = {{2, 5}, {3, 6}, {4, 7}, {5, 6}, {6, 5}, {7, 4}, {8, 3}};
                for (int[] pt : tick) c.fill(x + cw - 18 + pt[0], cy + 7 + pt[1], x + cw - 18 + pt[0] + 1, cy + 7 + pt[1] + 1, 0xFFFFFFFF);
            }
        }
        y += ((AstraSky.NAMES.size() + 3) / 4) * (ch + 6) + 2;
        ui.label(c, px, y, "Click a sky to apply it. It replaces the vanilla sky and clouds.");
        y += 18;

        ui.noClip();
        c.disableScissor();
        return y - top;
    }

    // ---- Styles ----

    private void styles(DrawContext c, int px, int py, int pw) {
        Draw.panel(c, px, py, pw, 44, Draw.BG_SOFT, Draw.BORDER, 5f);
        Draw.text(c, font, "PvP styles are not built yet", px + 10, py + 9, Draw.TEXT);
        ui.label(c, px + 10, py + 25, "Lyrics looks live under Lyrics > Look.");
    }

    // ---- HUD ----

    private void hud(DrawContext c, int px, int py, int pw, int mx, int my) {
        AstraConfig cfg = AstraConfig.get();
        ui.header(c, px, py, "Top bar");
        ui.toggle(c, px, py + 14, pw, "FPS counter", cfg.hudFps, () -> { cfg.hudFps = !cfg.hudFps; cfg.save(); }, mx, my);
        ui.toggle(c, px, py + 38, pw, "Ping", cfg.hudPing, () -> { cfg.hudPing = !cfg.hudPing; cfg.save(); }, mx, my);
        ui.toggle(c, px, py + 62, pw, "Now playing and current lyric", cfg.hudMusic, () -> { cfg.hudMusic = !cfg.hudMusic; cfg.save(); }, mx, my);
        ui.label(c, px, py + 92, "The bar sits at the top centre of the screen while you play.");
    }

    // ---- Performance ----

    private void performance(DrawContext c, int px, int py, int pw, int mx, int my) {
        MinecraftClient mc = MinecraftClient.getInstance();
        GameOptions o = mc.options;
        ui.label(c, px, py, "These change Minecraft's own video settings.");

        int rd = o.getViewDistance().getValue();
        ui.slider(c, px, py + 14, pw, "Render distance", rd + " chunks", rd, 2, 32,
                v -> o.getViewDistance().setValue(Math.round(v)), o::write, mx, my);

        int fps = o.getMaxFps().getValue();
        ui.slider(c, px, py + 38, pw, "Max FPS", fps >= 260 ? "Unlimited" : fps + "", fps, 10, 260,
                v -> o.getMaxFps().setValue(Math.round(v / 10f) * 10), o::write, mx, my);

        double ed = o.getEntityDistanceScaling().getValue();
        ui.slider(c, px, py + 62, pw, "Entity distance", String.format("%.0f%%", ed * 100), (float) ed, 0.5f, 5f,
                v -> o.getEntityDistanceScaling().setValue(Math.round(v * 4) / 4.0), o::write, mx, my);

        boolean clouds = o.getCloudRenderMode().getValue() != CloudRenderMode.OFF;
        ui.toggle(c, px, py + 90, pw, "Clouds", clouds, () -> {
            o.getCloudRenderMode().setValue(clouds ? CloudRenderMode.OFF : CloudRenderMode.FAST);
            o.write();
        }, mx, my);

        boolean particles = o.getParticles().getValue() == ParticlesMode.ALL;
        ui.toggle(c, px, py + 114, pw, "All particles", particles, () -> {
            o.getParticles().setValue(particles ? ParticlesMode.MINIMAL : ParticlesMode.ALL);
            o.write();
        }, mx, my);

        AstraConfig cfg = AstraConfig.get();
        ui.toggle(c, px, py + 162, pw, "Blurred menu background (costs FPS)", cfg.menuBlur, () -> { cfg.menuBlur = !cfg.menuBlur; cfg.save(); }, mx, my);

        boolean vsync = o.getEnableVsync().getValue();
        ui.toggle(c, px, py + 138, pw, "VSync", vsync, () -> {
            o.getEnableVsync().setValue(!vsync);
            o.write();
        }, mx, my);
    }

    // ---- Settings ----

    private void settings(DrawContext c, int px, int py, int pw, int ph, int mx, int my) {
        AstraConfig cfg = AstraConfig.get();
        ui.header(c, px, py, "Lyrics");
        ui.toggle(c, px, py + 14, pw, "Show lyrics in the world", cfg.lyricsEnabled, () -> { cfg.lyricsEnabled = !cfg.lyricsEnabled; cfg.save(); }, mx, my);
        boolean follow = "Follow".equals(cfg.lyricsMode);
        ui.toggle(c, px, py + 38, pw, "Follow my view (off: stay where it appears)", follow,
                () -> { cfg.lyricsMode = follow ? "Floating" : "Follow"; cfg.save(); }, mx, my);
        ui.slider(c, px, py + 62, pw, "Lyrics size", String.format("%.2fx", cfg.lyricsSize), cfg.lyricsSize, 0.5f, 2f,
                v -> cfg.lyricsSize = Math.round(v * 20) / 20f, cfg::save, mx, my);

        ui.slider(c, px, py + 86, pw, "Show the line early (to sing along)", cfg.lyricsLeadMs <= 0 ? "off" : String.format("%.2f s", cfg.lyricsLeadMs / 1000f),
                cfg.lyricsLeadMs, 0, 6000, v -> cfg.lyricsLeadMs = Math.round(v / 250f) * 250, cfg::save, mx, my);

        ui.header(c, px, py + 116, "Spotify");
        ui.label(c, px, py + 130, "Optional: Client ID, only for playlists and search. Lyrics and buttons work without it.");
        host.clientIdField(c, px, py + 142, pw);
        boolean in = Astra.SPOTIFY_AUTH.loggedIn();
        int bw = (pw - 6) / 2;
        ui.button(c, px, py + 166, bw, in ? "Reconnect" : "Connect Spotify", false, host::connectSpotify, mx, my);
        ui.button(c, px + bw + 6, py + 166, bw, "Disconnect", false, () -> {
            cfg.spotifyRefreshToken = "";
            cfg.spotifyScopeVersion = 0;
            cfg.save();
            status = "Disconnected";
        }, mx, my);
        if (!status.isEmpty()) ui.label(c, px, py + 188, status);
        ui.label(c, px, py + 208, "Add this Redirect URI to your Spotify app:");
        ui.button(c, px, py + 222, 70, "Copy", false, () -> {
            MinecraftClient.getInstance().keyboard.setClipboard(SpotifyAuth.REDIRECT);
            status = "Copied the Redirect URI";
        }, mx, my);
        Draw.text(c, font, SpotifyAuth.REDIRECT, px + 78, py + 227, Draw.TEXT);
        ui.label(c, px, py + ph - 14, "Menu key: Right Shift. Rebind it under Options > Controls.");
    }

    // ---- Information ----

    private void information(DrawContext c, int px, int py, int pw) {
        String[][] rows = {
                {"Astra Client", "0.1.0 for Minecraft 1.21.11 (Fabric)"},
                {"Menu", "Right Shift"},
                {"Music keys", "F7 previous, F8 play / pause, F9 next"},
                {"Spotify", "Needs Premium and the Spotify app open as player"},
                {"Lyrics", "Synced lyrics from lrclib.net"},
                {"Font", "Poppins, SIL Open Font License 1.1"},
                {"Settings file", "config/astra.json"}};
        for (int i = 0; i < rows.length; i++) {
            int y = py + i * 26;
            Draw.panel(c, px, y, pw, 22, Draw.BG_SOFT, Draw.BORDER, 5f);
            ui.label(c, px + 10, y + 7, rows[i][0]);
            Draw.text(c, font, rows[i][1], px + 110, y + 7, Draw.TEXT);
        }
    }
}
