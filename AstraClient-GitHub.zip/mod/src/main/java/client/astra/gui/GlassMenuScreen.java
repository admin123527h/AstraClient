package client.astra.gui;

import client.astra.Astra;
import client.astra.hud.Draw;
import client.astra.music.AstraConfig;
import net.minecraft.client.gui.Click;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.TextFieldWidget;
import net.minecraft.text.Text;

import java.util.List;

public class GlassMenuScreen extends Screen {
    private static final List<String> TABS = List.of("Overview", "Skies", "Lyrics", "Spotify", "Styles", "HUD", "Performance", "Settings", "Information");
    private static final List<String> SUBTITLES = List.of(
            "Your client at a glance", "Pick your own animated sky", "Spotify lyrics live in the sky", "Your music, in your game",
            "PvP styles", "Your top bar", "Smoother gameplay", "Tune Astra to your setup", "About this build");
    private static final int LYRICS = 2, SPOTIFY = 3, SIDEBAR = 112;

    private final SpotifyPage spotify = new SpotifyPage();
    private final int[] scroll = new int[TABS.size()];
    private final int[] contentHeight = new int[TABS.size()];
    private int tab;
    private int x, y, w, h;
    private int viewTop, viewHeight;
    private String status = "";
    private TextFieldWidget search;
    private TextFieldWidget clientId;
    private int cidX, cidY, cidW;
    private Ui ui;
    private MenuPages pages;
    private LyricsPage lyrics;
    private String lastQuery = "";
    private int idle;
    private int devFrames;

    public GlassMenuScreen() {
        this(Integer.getInteger("astra.devTab", LYRICS));
    }

    public GlassMenuScreen(int tab) {
        super(Text.literal("Astra"));
        this.tab = tab;
    }

    @Override
    protected void init() {
        w = Math.min(width - 40, 540);
        h = Math.min(height - 30, 310);
        x = (width - w) / 2;
        y = (height - h) / 2;
        viewTop = y + 46;
        viewHeight = h - 54;

        search = new TextFieldWidget(textRenderer, x + SIDEBAR + 20, viewTop + 4, w - SIDEBAR - 40, 10, Text.literal("Search"));
        search.setDrawsBackground(false);
        search.setChangedListener(s -> idle = 0);
        addSelectableChild(search);

        ui = new Ui(textRenderer);
        pages = new MenuPages(ui, textRenderer, new MenuPages.Host() {
            @Override public void openTab(int t) { tab = t; setFocused(null); }
            @Override public void clientIdField(DrawContext c, int fx, int fy, int fw) { drawClientId(c, fx, fy, fw); }
            @Override public void connectSpotify() { GlassMenuScreen.this.connectSpotify(); }
        });
        lyrics = new LyricsPage(ui, textRenderer, this::close, this::connectSpotify, t -> { tab = t; setFocused(null); });

        clientId = new TextFieldWidget(textRenderer, x + SIDEBAR + 20, y + 150, w - SIDEBAR - 40, 10, Text.literal("Client ID"));
        clientId.setDrawsBackground(false);
        clientId.setMaxLength(64);
        clientId.setText(AstraConfig.get().spotifyClientId);
        clientId.setChangedListener(v -> {
            AstraConfig.get().spotifyClientId = v.trim();
            AstraConfig.get().save();
        });
        addSelectableChild(clientId);
    }

    private void drawClientId(DrawContext c, int fx, int fy, int fw) {
        cidX = fx; cidY = fy; cidW = fw;
        Draw.panel(c, fx, fy, fw, 18, Draw.BG_SOFT, clientId.isFocused() ? 0xC0C4B5FD : Draw.BORDER);
        String typed = clientId.getText();
        Draw.text(c, textRenderer, typed.isEmpty() ? "Paste your Client ID here" : typed, fx + 8, fy + 5, typed.isEmpty() ? Draw.TEXT_DIM : Draw.TEXT);
        if (clientId.isFocused() && (System.currentTimeMillis() / 500) % 2 == 0) {
            int cx = fx + 8 + Draw.width(textRenderer, typed) + 1;
            c.fill(cx, fy + 3, cx + 1, fy + 15, Draw.TEXT);
        }
    }

    private void connectSpotify() {
        AstraConfig cfg = AstraConfig.get();
        if (cfg.clientId().isEmpty()) {
            status = "Enter your Client ID in Settings first";
            pages.setStatus(status);
            tab = 7;
            return;
        }
        status = "Opening browser...";
        pages.setStatus(status);
        Astra.SPOTIFY_AUTH.login().thenAccept(error -> {
            status = error == null ? "Spotify connected" : error;
            pages.setStatus(status);
        });
    }

    @Override
    public void tick() {
        if (tab == SPOTIFY && !search.getText().equals(lastQuery) && ++idle > 12) {
            lastQuery = search.getText();
            spotify.showSearch(lastQuery);
        }
    }

    @Override
    public void render(DrawContext c, int mx, int my, float delta) {
        if (Astra.DEV && ++devFrames % 120 == 0) {
            System.out.println("[astra-perf] tab=" + tab + " fills/frame=" + Draw.fills / 120);
            Draw.fills = 0;
        }
        ui.begin();
        c.fill(0, 0, width, height, AstraConfig.get().menuBlur ? 0x400A0714 : 0x66080512);
        Draw.window(c, x, y, w, h, Draw.BG, Draw.BORDER, 7f);
        renderSidebar(c, mx, my);

        int px = x + SIDEBAR + 14;
        int pw = w - SIDEBAR - 28;
        Draw.text(c, textRenderer, TABS.get(tab), px, y + 11, Draw.TEXT);
        Draw.text(c, textRenderer, SUBTITLES.get(tab), px, y + 24, Draw.TEXT_DIM);
        String l1 = "Your game.", l2 = "Our client.";
        int r = x + w - 14;
        c.fill(r - Draw.width(textRenderer, l2) - 6, y + 11, r - Draw.width(textRenderer, l2) - 5, y + 32, Draw.ACCENT_DIM);
        Draw.text(c, textRenderer, l1, r - Draw.width(textRenderer, l1), y + 11, Draw.TEXT_DIM);
        Draw.text(c, textRenderer, l2, r - Draw.width(textRenderer, l2), y + 22, Draw.TEXT_DIM);

        if (tab == LYRICS) {
            contentHeight[tab] = lyrics.render(c, px, viewTop, pw, viewHeight, scroll[tab], mx, my);
        } else if (tab == SPOTIFY) {
            renderSpotify(c, px, pw, mx, my);
        } else {
            contentHeight[tab] = pages.render(tab, c, px, viewTop, pw, viewHeight, scroll[tab], mx, my);
        }
        clampScroll();
        renderScrollbar(c);
    }

    /** Row height of the sidebar: shrinks on small windows (high GUI scale) so all tabs stay visible. */
    private int step() {
        return Math.max(13, Math.min(20, (h - 46 - 10) / TABS.size()));
    }

    private void renderSidebar(DrawContext c, int mx, int my) {
        c.fill(x + SIDEBAR, y + 8, x + SIDEBAR + 1, y + h - 8, Draw.ACCENT_DIM);

        Draw.panel(c, x + 8, y + 8, SIDEBAR - 16, 30, Draw.BG_SOFT, Draw.BORDER, 5f);
        // the Astra logo
        c.drawTexture(net.minecraft.client.gl.RenderPipelines.GUI_TEXTURED, net.minecraft.util.Identifier.of("astra", "textures/gui/logo.png"), x + 12, y + 12, 0f, 0f, 22, 22, 96, 96, 96, 96);
        Draw.text(c, textRenderer, "Astra", x + 38, y + 12, Draw.TEXT);
        Draw.text(c, textRenderer, "Client", x + 38, y + 24, Draw.TEXT_DIM);

        for (int i = 0; i < TABS.size(); i++) {
            int ty = y + 46 + i * step();
            boolean hover = mx >= x + 8 && mx < x + SIDEBAR - 8 && my >= ty && my < ty + step() - 3;
            if (i == tab) Draw.round(c, x + 8, ty, SIDEBAR - 16, step() - 3, Draw.ACCENT_DIM);
            else if (hover) Draw.round(c, x + 8, ty, SIDEBAR - 16, step() - 3, 0x33A78BFA);
            Draw.text(c, textRenderer, TABS.get(i), x + 16, ty + 5, i == tab ? Draw.TEXT : Draw.TEXT_DIM);
        }
        if (step() >= 19) {
            Draw.text(c, textRenderer, "Astra", x + 14, y + h - 22, Draw.TEXT_DIM);
            Draw.text(c, textRenderer, "v0.1.0", x + 14, y + h - 12, Draw.TEXT_DIM);
        }
    }

    private void renderScrollbar(DrawContext c) {
        int content = contentHeight[tab];
        if (content <= viewHeight) return;
        int trackX = x + w - 8, trackH = viewHeight;
        int thumbH = Math.max(18, trackH * viewHeight / content);
        int travel = trackH - thumbH;
        int maxScroll = content - viewHeight;
        int thumbY = viewTop + (maxScroll == 0 ? 0 : travel * scroll[tab] / maxScroll);
        Draw.round(c, trackX, viewTop, 3, trackH, 0x33A78BFA);
        Draw.round(c, trackX, thumbY, 3, thumbH, 0xAAC4B5FD);
    }

    private void clampScroll() {
        int max = Math.max(0, contentHeight[tab] - viewHeight);
        scroll[tab] = Math.max(0, Math.min(max, scroll[tab]));
    }

    private void renderSpotify(DrawContext c, int px, int pw, int mx, int my) {
        spotify.ensureLoaded();
        Draw.panel(c, px, viewTop, pw, 18, Draw.BG_SOFT, search.isFocused() ? 0xC0C4B5FD : Draw.BORDER);
        String typed = search.getText();
        Draw.text(c, textRenderer, typed.isEmpty() ? "Search songs..." : typed, px + 8, viewTop + 5, typed.isEmpty() ? Draw.TEXT_DIM : Draw.TEXT);
        if (search.isFocused() && (System.currentTimeMillis() / 500) % 2 == 0) {
            int cx = px + 8 + Draw.width(textRenderer, typed) + 1;
            c.fill(cx, viewTop + 3, cx + 1, viewTop + 15, Draw.TEXT);
        }
        spotify.render(c, px, viewTop + 24, pw, viewHeight - 24, mx, my);
    }

    @Override
    public boolean mouseClicked(Click click, boolean doubled) {
        double mx = click.x(), my = click.y();
        for (int i = 0; i < TABS.size(); i++) {
            int ty = y + 46 + i * step();
            if (mx >= x + 8 && mx < x + SIDEBAR - 8 && my >= ty && my < ty + step() - 3) { tab = i; setFocused(null); return true; }
        }
        if (tab == 7 && mx >= cidX && mx < cidX + cidW && my >= cidY && my < cidY + 18) {
            setFocused(clientId);
            return super.mouseClicked(click, doubled);
        }
        if (ui.click(mx, my)) return true;
        if (tab == SPOTIFY) {
            if (my >= viewTop && my < viewTop + 18) {
                setFocused(search);
                return super.mouseClicked(click, doubled);
            }
            if (spotify.click(mx, my, true)) return true;
        }
        return super.mouseClicked(click, doubled);
    }

    @Override
    public boolean mouseDragged(Click click, double offsetX, double offsetY) {
        ui.drag(click.x());
        return super.mouseDragged(click, offsetX, offsetY);
    }

    @Override
    public boolean mouseReleased(Click click) {
        ui.release();
        return super.mouseReleased(click);
    }

    @Override
    public boolean mouseScrolled(double mx, double my, double horizontal, double vertical) {
        if (tab == SPOTIFY && spotify.scroll(mx, my, vertical)) return true;
        if (contentHeight[tab] > viewHeight) {
            scroll[tab] -= (int) (vertical * 16);
            clampScroll();
            return true;
        }
        return super.mouseScrolled(mx, my, horizontal, vertical);
    }

    @Override
    protected void applyBlur(DrawContext context) {
        if (AstraConfig.get().menuBlur) super.applyBlur(context);
    }

    @Override
    public boolean shouldPause() {
        return false;
    }
}
