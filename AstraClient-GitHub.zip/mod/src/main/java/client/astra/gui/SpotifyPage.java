package client.astra.gui;

import client.astra.Astra;
import client.astra.hud.Draw;
import client.astra.music.MusicProvider;
import client.astra.music.SpotifyApi;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;

import java.util.ArrayList;
import java.util.List;

/** In-client Spotify browser: playlists, liked songs, search results and a transport bar. */
public final class SpotifyPage {
    private static final int ROW = 14;

    private final TextRenderer font = MinecraftClient.getInstance().textRenderer;
    private List<SpotifyApi.Playlist> playlists = new ArrayList<>();
    private List<SpotifyApi.Item> items = new ArrayList<>();
    private String source = "liked";
    private int sourceScroll;
    private int itemScroll;
    private boolean loadedOnce;
    private String status = "";

    // layout, set by render()
    private int px, py, pw, ph, listH;
    private int barY;

    public String status() { return status; }

    public void ensureLoaded() {
        if (loadedOnce || !(Astra.SPOTIFY_AUTH.loggedIn() || Astra.DEV)) return;
        loadedOnce = true;
        Astra.SPOTIFY_API.playlists().thenAccept(p -> playlists = p);
        openSource("liked");
    }

    private void openSource(String s) {
        source = s;
        itemScroll = 0;
        items = new ArrayList<>();
        var f = s.equals("liked") ? Astra.SPOTIFY_API.liked() : Astra.SPOTIFY_API.playlistItems(s);
        f.thenAccept(l -> { if (source.equals(s)) items = l; });
    }

    public void showSearch(String query) {
        if (query.isBlank()) return;
        source = "search";
        itemScroll = 0;
        Astra.SPOTIFY_API.search(query).thenAccept(l -> { if (source.equals("search")) items = l; });
    }

    public void render(DrawContext c, int x, int y, int w, int h, int mx, int my) {
        px = x; py = y; pw = w; ph = h;
        barY = y + h - 36;
        listH = barY - y - 6;

        if (!Astra.SPOTIFY_AUTH.loggedIn() && !Astra.DEV) {
            Draw.text(c, font, "Connect Spotify in the Lyrics tab first.", x, y + 24, Draw.TEXT_DIM);
            transport(c, mx, my);
            return;
        }

        int sw = 104;
        Draw.panel(c, x, y, sw, listH, Draw.BG_SOFT, Draw.BORDER);
        int rows = listH / ROW;
        drawSource(c, "Liked Songs", "liked", x + 4, y + 3, sw - 8, mx, my);
        for (int i = 0; i < rows - 1; i++) {
            int idx = i + sourceScroll;
            if (idx >= playlists.size()) break;
            SpotifyApi.Playlist p = playlists.get(idx);
            drawSource(c, p.name(), p.id(), x + 4, y + 3 + (i + 1) * ROW, sw - 8, mx, my);
        }

        int ix = x + sw + 6, iw = w - sw - 6;
        Draw.panel(c, ix, y, iw, listH, Draw.BG_SOFT, Draw.BORDER);
        int irows = (listH - 6) / ROW;
        if (items.isEmpty()) Draw.text(c, font, "Nothing here yet", ix + 8, y + 8, Draw.TEXT_DIM);
        for (int i = 0; i < irows; i++) {
            int idx = i + itemScroll;
            if (idx >= items.size()) break;
            SpotifyApi.Item it = items.get(idx);
            int ry = y + 3 + i * ROW;
            boolean hover = mx >= ix + 3 && mx < ix + iw - 3 && my >= ry && my < ry + ROW;
            if (hover) Draw.round(c, ix + 3, ry, iw - 6, ROW, Draw.ACCENT_DIM);
            String dur = (it.durationMs() / 60000) + ":" + String.format("%02d", it.durationMs() / 1000 % 60);
            int durW = Draw.width(font, dur);
            Draw.text(c, font, clip(it.name(), iw - 20 - durW - 70), ix + 8, ry + 3, Draw.TEXT);
            Draw.text(c, font, clip(it.artist(), 66), ix + iw - 120, ry + 3, Draw.TEXT_DIM);
            Draw.text(c, font, dur, ix + iw - 8 - durW, ry + 3, Draw.TEXT_DIM);
        }
        transport(c, mx, my);
    }

    private void drawSource(DrawContext c, String label, String id, int x, int y, int w, int mx, int my) {
        boolean active = source.equals(id);
        boolean hover = mx >= x && mx < x + w && my >= y && my < y + ROW;
        if (active) Draw.round(c, x, y, w, ROW, Draw.ACCENT_DIM);
        else if (hover) Draw.round(c, x, y, w, ROW, 0x33A78BFA);
        Draw.text(c, font, clip(label, w - 8), x + 4, y + 3, active ? Draw.TEXT : Draw.TEXT_DIM);
    }

    /** Now-playing bar with previous / play-pause / next and a seekable progress bar. */
    public void transport(DrawContext c, int mx, int my) {
        int by = py + ph - 32, bw = pw;
        Draw.panel(c, px, by, bw, 32, Draw.BG_SOFT, Draw.BORDER);
        var track = Astra.music().current();
        if (track.isPresent()) {
            MusicProvider.Track t = track.get();
            Draw.text(c, font, clip(t.title(), bw / 2 - 90), px + 8, by + 6, Draw.TEXT);
            Draw.text(c, font, clip(t.artist(), bw / 2 - 90), px + 8, by + 18, Draw.TEXT_DIM);
            int bar = bw - 16;
            c.fill(px + 8, by + 27, px + 8 + bar, by + 29, 0x44A78BFA);
            int filled = t.durationMs() > 0 ? (int) (bar * t.positionMs() / t.durationMs()) : 0;
            c.fill(px + 8, by + 27, px + 8 + filled, by + 29, Draw.ACCENT);
        } else {
            Draw.text(c, font, "Nothing playing", px + 8, by + 12, Draw.TEXT_DIM);
        }
        boolean playing = track.map(MusicProvider.Track::playing).orElse(false);
        int cx = px + bw / 2 + 20;
        btn(c, cx - 44, by + 5, 24, "|<", mx, my, false);
        btn(c, cx - 14, by + 5, 28, playing ? "||" : ">", mx, my, true);
        btn(c, cx + 20, by + 5, 24, ">|", mx, my, false);
        if (!status.isEmpty()) Draw.text(c, font, status, px + bw - 8 - Draw.width(font, status), by + 6, Draw.TEXT_DIM);
    }

    private void btn(DrawContext c, int x, int y, int w, String label, int mx, int my, boolean primary) {
        boolean hover = mx >= x && mx < x + w && my >= y && my < y + 15;
        Draw.panel(c, x, y, w, 15, primary ? Draw.ACCENT_DIM : hover ? 0x44A78BFA : Draw.BG, Draw.BORDER);
        Draw.text(c, font, label, x + (w - Draw.width(font, label)) / 2, y + 4, Draw.TEXT);
    }

    public void layout(int x, int y, int w, int h) {
        px = x; py = y; pw = w; ph = h;
    }

    public boolean click(double mx, double my, boolean lists) {
        // transport
        int by = py + ph - 32, bw = pw, cx = px + bw / 2 + 20;
        if (my >= by + 5 && my < by + 20) {
            if (mx >= cx - 44 && mx < cx - 20) { run(client.astra.music.MediaControl.previous()); return true; }
            if (mx >= cx - 14 && mx < cx + 14) {
                boolean playing = Astra.music().current().map(MusicProvider.Track::playing).orElse(false);
                run(playing ? client.astra.music.MediaControl.pause() : client.astra.music.MediaControl.play());
                return true;
            }
            if (mx >= cx + 20 && mx < cx + 44) { run(client.astra.music.MediaControl.next()); return true; }
        }
        if (my >= by + 24 && my < by + 31 && mx >= px + 8 && mx < px + bw - 8) {
            var t = Astra.music().current();
            if (t.isPresent()) run(client.astra.music.MediaControl.seek((long) (t.get().durationMs() * (mx - px - 8) / (bw - 16))));
            return true;
        }
        if (!lists || (!Astra.SPOTIFY_AUTH.loggedIn() && !Astra.DEV)) return false;

        int sw = 104;
        if (my >= py && my < py + listH) {
            if (mx >= px && mx < px + sw) {
                int row = (int) ((my - py - 3) / ROW);
                if (row == 0) { openSource("liked"); return true; }
                int idx = row - 1 + sourceScroll;
                if (idx >= 0 && idx < playlists.size()) { openSource(playlists.get(idx).id()); return true; }
            } else if (mx >= px + sw + 6) {
                int idx = (int) ((my - py - 3) / ROW) + itemScroll;
                if (idx >= 0 && idx < items.size()) {
                    if (source.equals("liked") || source.equals("search")) {
                        List<String> uris = items.stream().map(SpotifyApi.Item::uri).toList();
                        run(Astra.SPOTIFY_API.playUris(uris, idx));
                    } else {
                        run(Astra.SPOTIFY_API.playPlaylist(source, items.get(idx).uri()));
                    }
                    return true;
                }
            }
        }
        return false;
    }

    public boolean scroll(double mx, double my, double amount) {
        int dir = amount > 0 ? -1 : 1;
        if (mx < px + 104) sourceScroll = Math.max(0, Math.min(Math.max(0, playlists.size() - (listH / ROW - 1)), sourceScroll + dir));
        else itemScroll = Math.max(0, Math.min(Math.max(0, items.size() - (listH - 6) / ROW), itemScroll + dir));
        return true;
    }

    private void run(java.util.concurrent.CompletableFuture<String> f) {
        f.thenAccept(err -> status = err == null ? "" : err);
    }

    private String clip(String s, int maxW) {
        if (Draw.width(font, s) <= maxW) return s;
        while (s.length() > 1 && Draw.width(font, s + "..") > maxW) s = s.substring(0, s.length() - 1);
        return s + "..";
    }
}
