package client.astra.gui;

import client.astra.hud.Draw;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Consumer;
import java.util.function.DoubleConsumer;

/** Immediate-mode glass controls: every control registers a hit area while it is drawn. */
public final class Ui {
    private record Slider(float min, float max, int barX, int barW, Consumer<Float> set, Runnable commit) {}

    private record Hit(int x, int y, int w, int h, Runnable click, Slider slider, DoubleConsumer clickX, int[] clip) {
        boolean contains(double mx, double my) {
            if (clip != null && (mx < clip[0] || mx >= clip[0] + clip[2] || my < clip[1] || my >= clip[1] + clip[3])) return false;
            return mx >= x && mx < x + w && my >= y && my < y + h;
        }
    }

    private final TextRenderer font;
    private final List<Hit> hits = new ArrayList<>();
    private Hit dragging;
    private int[] clip;

    public Ui(TextRenderer font) {
        this.font = font;
    }

    public void begin() {
        hits.clear();
        clip = null;
    }

    /** Controls registered until noClip() only react to clicks inside this rectangle (scroll viewports). */
    public void clip(int x, int y, int w, int h) {
        clip = new int[] {x, y, w, h};
    }

    public void noClip() {
        clip = null;
    }

    public void hit(int x, int y, int w, int h, Runnable click) {
        hits.add(new Hit(x, y, w, h, click, null, null, clip));
    }

    /** Clickable area that also receives the mouse x position. */
    public void hitX(int x, int y, int w, int h, DoubleConsumer clickX) {
        hits.add(new Hit(x, y, w, h, null, null, clickX, clip));
    }

    public boolean click(double mx, double my) {
        for (int i = hits.size() - 1; i >= 0; i--) {
            Hit hit = hits.get(i);
            if (!hit.contains(mx, my)) continue;
            if (hit.slider != null) {
                dragging = hit;
                applySlider(hit, mx);
            } else if (hit.clickX != null) {
                hit.clickX.accept(mx);
            } else {
                hit.click.run();
            }
            return true;
        }
        return false;
    }

    public void drag(double mx) {
        if (dragging != null) applySlider(dragging, mx);
    }

    public void release() {
        if (dragging != null) {
            dragging.slider.commit.run();
            dragging = null;
        }
    }

    private static void applySlider(Hit hit, double mx) {
        Slider s = hit.slider;
        float t = (float) Math.max(0, Math.min(1, (mx - s.barX) / s.barW));
        s.set.accept(s.min + (s.max - s.min) * t);
    }

    // ---- controls ----

    public void header(DrawContext c, int x, int y, String text) {
        Draw.text(c, font, text.toUpperCase(), x, y, Draw.ACCENT);
    }

    public void label(DrawContext c, int x, int y, String text) {
        Draw.text(c, font, text, x, y, Draw.TEXT_DIM);
    }

    public void button(DrawContext c, int x, int y, int w, String label, boolean active, Runnable click, int mx, int my) {
        boolean hover = mx >= x && mx < x + w && my >= y && my < y + 17;
        Draw.panel(c, x, y, w, 17, active ? Draw.ACCENT_DIM : hover ? 0x44A78BFA : Draw.BG_SOFT, Draw.BORDER);
        Draw.text(c, font, label, x + (w - Draw.width(font, label)) / 2, y + 5, Draw.TEXT);
        hit(x, y, w, 17, click);
    }

    /** Row with a label on the left and an on/off switch on the right. */
    public void toggle(DrawContext c, int x, int y, int w, String label, boolean on, Runnable click, int mx, int my) {
        boolean hover = mx >= x && mx < x + w && my >= y && my < y + 20;
        Draw.panel(c, x, y, w, 20, hover ? 0x5A2A1D4D : Draw.BG_SOFT, Draw.BORDER);
        Draw.text(c, font, label, x + 8, y + 6, Draw.TEXT);
        int sx = x + w - 30, sy = y + 5;
        Draw.panel(c, sx, sy, 22, 10, on ? 0xCC8B5CF6 : 0x66403060, Draw.BORDER, 5f);
        int kx = on ? sx + 13 : sx + 1;
        Draw.round(c, kx, sy + 1, 8, 8, on ? 0xFFF5F3FF : 0xFFA79BCB);
        hit(x, y, w, 20, click);
    }

    /** Row with a label, a value readout and a draggable bar. */
    public void slider(DrawContext c, int x, int y, int w, String label, String valueText, float value, float min, float max,
                       Consumer<Float> set, Runnable commit, int mx, int my) {
        Draw.panel(c, x, y, w, 20, Draw.BG_SOFT, Draw.BORDER);
        Draw.text(c, font, label, x + 8, y + 6, Draw.TEXT);
        int barW = Math.max(40, w / 3);
        int barX = x + w - barW - 52;
        Draw.round(c, barX, y + 9, barW, 3, 0x66403060);
        float t = max > min ? Math.max(0, Math.min(1, (value - min) / (max - min))) : 0;
        int fill = Math.max(1, Math.round(barW * t));
        Draw.round(c, barX, y + 9, fill, 3, Draw.ACCENT);
        Draw.round(c, barX + fill - 3, y + 6, 6, 9, 0xFFF5F3FF);
        Draw.text(c, font, valueText, x + w - 8 - Draw.width(font, valueText), y + 6, Draw.TEXT_DIM);
        hits.add(new Hit(barX - 4, y, barW + 8, 20, null, new Slider(min, max, barX, barW, set, commit), null, clip));
    }

    /** Selectable card background; the caller draws the contents. */
    public void card(DrawContext c, int x, int y, int w, int h, boolean active, Runnable click, int mx, int my) {
        boolean hover = mx >= x && mx < x + w && my >= y && my < y + h;
        Draw.panel(c, x, y, w, h, active ? 0x80553C9A : hover ? 0x7A3A2A66 : Draw.BG_SOFT, active ? 0xB0C4B5FD : Draw.BORDER, 5f);
        if (click != null) hit(x, y, w, h, click);
    }
}
