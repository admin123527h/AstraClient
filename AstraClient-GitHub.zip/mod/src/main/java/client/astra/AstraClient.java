package client.astra;

import client.astra.gui.GlassMenuScreen;
import client.astra.hud.HudRenderer;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.hud.VanillaHudElements;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.util.Identifier;
import org.lwjgl.glfw.GLFW;

public class AstraClient implements ClientModInitializer {
    public static final String ID = "astra";

    private static final KeyBinding.Category CATEGORY = KeyBinding.Category.create(Identifier.of(ID, "main"));

    private static KeyBinding key(String name, int code) {
        return KeyBindingHelper.registerKeyBinding(new KeyBinding(name, InputUtil.Type.KEYSYM, code, CATEGORY));
    }

    @Override
    public void onInitializeClient() {
        client.astra.sky.AstraSky.init();
        HudElementRegistry.attachElementAfter(
                VanillaHudElements.MISC_OVERLAYS,
                Identifier.of(ID, "hud"),
                HudRenderer::render);

        net.fabricmc.fabric.api.client.rendering.v1.world.WorldRenderEvents.AFTER_ENTITIES.register(client.astra.lyrics.LyricsRenderer::render);

        KeyBinding menuKey = key("key.astra.menu", GLFW.GLFW_KEY_RIGHT_SHIFT);

        KeyBinding prevKey = key("key.astra.prev", GLFW.GLFW_KEY_F7);
        KeyBinding playKey = key("key.astra.playpause", GLFW.GLFW_KEY_F8);
        KeyBinding nextKey = key("key.astra.next", GLFW.GLFW_KEY_F9);

        int[] devTicks = {0};
        int[] skyTicks = {0};
        ClientTickEvents.END_CLIENT_TICK.register(mc -> {
            while (menuKey.wasPressed()) {
                if (mc.currentScreen == null) mc.setScreen(new GlassMenuScreen());
            }
            while (prevKey.wasPressed()) client.astra.music.MediaControl.previous();
            while (nextKey.wasPressed()) client.astra.music.MediaControl.next();
            while (playKey.wasPressed()) {
                boolean playing = Astra.music().current().map(client.astra.music.MusicProvider.Track::playing).orElse(false);
                if (playing) client.astra.music.MediaControl.pause(); else client.astra.music.MediaControl.play();
            }
            if (Astra.DEV && Boolean.getBoolean("astra.devSpin") && mc.player != null) mc.player.setYaw(mc.player.getYaw() + 0.5f);
            if (Astra.DEV && Boolean.getBoolean("astra.devSkyCycle") && mc.player != null && mc.world != null) {
                mc.player.setPitch(-18f);
                mc.player.setYaw(180f);
                if (++skyTicks[0] % 130 == 1) {
                    client.astra.music.AstraConfig.get().lyricsEnabled = false;
                    client.astra.music.AstraConfig.get().skyEnabled = true;
                    client.astra.music.AstraConfig.get().sky = client.astra.sky.AstraSky.NAMES.get((skyTicks[0] / 130) % 16);
                    System.out.println("[astra-sky] " + client.astra.music.AstraConfig.get().sky);
                }
            }
            if (Astra.DEV) {
                if (mc.world != null && ++devTicks[0] == Integer.getInteger("astra.devMenuTicks", 600)) {
                    mc.setScreen(new GlassMenuScreen());
                }
            }
        });
    }
}
