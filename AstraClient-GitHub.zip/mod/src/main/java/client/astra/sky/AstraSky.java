package client.astra.sky;

import client.astra.music.AstraConfig;
import com.mojang.blaze3d.buffers.GpuBufferSlice;
import com.mojang.blaze3d.pipeline.RenderPipeline;
import com.mojang.blaze3d.systems.RenderPass;
import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.textures.GpuTextureView;
import com.mojang.blaze3d.vertex.VertexFormat;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gl.RenderPipelines;
import net.minecraft.client.render.VertexFormats;
import net.minecraft.util.Identifier;
import org.joml.Matrix4f;
import org.joml.Vector3f;
import org.joml.Vector4f;

import java.util.List;
import java.util.OptionalDouble;
import java.util.OptionalInt;

/** Replaces the vanilla sky with a procedural shader sky: one draw call, all work on the GPU. */
public final class AstraSky {
    public static final List<String> NAMES = List.of(
            "Saturn", "Northern Lights", "Polar Lights", "Nebula", "Galaxy", "End Beams", "Underwater", "Meteor Shower",
            "Star Trails", "Sunset", "Thunderstorm", "Blood Moon", "Comet", "Solar Eclipse", "Neon Horizon", "Cherry Blossom");

    /** Horizon colour of each sky, used as fog colour so distant land fades into the sky. */
    private static final int[] FOG = {
            0x1A1233, 0x140F36, 0x0A2220, 0x1E0B33, 0x0B0B22, 0x130A24, 0x0F5D70, 0x0C0C1E,
            0x0F1128, 0xF08A62, 0x2A2E3A, 0x4D0A0A, 0x0C1224, 0x1A1A38, 0xC02680, 0xF3B7D3};

    private static final long START = System.nanoTime();

    public static final RenderPipeline PIPELINE = RenderPipelines.register(
            RenderPipeline.builder(RenderPipelines.TRANSFORMS_AND_PROJECTION_SNIPPET)
                    .withLocation(Identifier.of("astra", "pipeline/sky"))
                    .withVertexShader(Identifier.of("astra", "core/astra_sky"))
                    .withFragmentShader(Identifier.of("astra", "core/astra_sky"))
                    .withDepthWrite(false)
                    .withCull(false)
                    .withVertexFormat(VertexFormats.EMPTY, VertexFormat.DrawMode.TRIANGLES)
                    .build());

    private AstraSky() {}

    /** Touching the class registers the pipeline before the first frame. */
    public static void init() {}

    public static int activeId() {
        AstraConfig cfg = AstraConfig.get();
        return cfg.skyEnabled ? NAMES.indexOf(cfg.sky) : -1;
    }

    /** 0 high, 1 medium, 2 low: the FPS booster forces low while it is working. */
    public static float quality() {
        if (false) return 2f;
        String q = AstraConfig.get().skyQuality;
        return "Low".equals(q) ? 2f : "Medium".equals(q) ? 1f : 0f;
    }

    private static volatile String failure = "";

    public static String failure() { return failure; }

    public static boolean active() {
        return failure.isEmpty() && activeId() >= 0 && MinecraftClient.getInstance().world != null;
    }

    public static int fogColor() {
        return 0xFF000000 | FOG[activeId()];
    }

    /** Draws the sky; false means it failed and the vanilla sky must draw instead. */
    public static boolean render() {
        try {
            draw();
            return true;
        } catch (Throwable t) {
            failure = t.getClass().getSimpleName() + ": " + t.getMessage();
            System.err.println("[astra] shader sky disabled: " + failure);
            t.printStackTrace();
            return false;
        }
    }

    private static void draw() {
        MinecraftClient mc = MinecraftClient.getInstance();
        float seconds = ((System.nanoTime() - START) / 1_000_000_000L % 100000L) + ((System.nanoTime() - START) % 1_000_000_000L) / 1e9f;
        GpuBufferSlice uniforms = RenderSystem.getDynamicUniforms()
                .write(RenderSystem.getModelViewMatrix(), new Vector4f(activeId(), seconds, quality(), 0f), new Vector3f(), new Matrix4f());
        GpuTextureView color = mc.getFramebuffer().getColorAttachmentView();
        GpuTextureView depth = mc.getFramebuffer().getDepthAttachmentView();
        try (RenderPass pass = RenderSystem.getDevice().createCommandEncoder()
                .createRenderPass(() -> "Astra sky", color, OptionalInt.empty(), depth, OptionalDouble.empty())) {
            pass.setPipeline(PIPELINE);
            RenderSystem.bindDefaultUniforms(pass);
            pass.setUniform("DynamicTransforms", uniforms);
            pass.draw(0, 36);
        }
    }
}
