package client.astra;

import client.astra.lyrics.LrcParser;
import client.astra.lyrics.LyricsService;
import client.astra.module.ModuleManager;
import client.astra.music.DevMusicProvider;
import client.astra.music.MusicProvider;
import client.astra.music.SpotifyApi;
import client.astra.music.SpotifyAuth;
import client.astra.music.HybridProvider;
import client.astra.music.SpotifyProvider;
import client.astra.music.SystemMedia;

public final class Astra {
    public static final boolean DEV = Boolean.getBoolean("astra.dev");
    public static final ModuleManager MODULES = new ModuleManager();
    public static final SpotifyAuth SPOTIFY_AUTH = new SpotifyAuth();
    public static final SpotifyApi SPOTIFY_API = new SpotifyApi(SPOTIFY_AUTH);
    public static final LyricsService LYRICS = new LyricsService();
    private static MusicProvider music;
    private static final SystemMedia SYSTEM = new SystemMedia();

    private Astra() {}

    public static SystemMedia system() { return SYSTEM; }

    public static boolean spotifyIsSource() {
        return music instanceof HybridProvider h && h.spotifyIsSource();
    }

    public static synchronized MusicProvider music() {
        if (music == null) {
            if (DEV) {
                music = new DevMusicProvider();
                LYRICS.preload("Astra|Sky Lights", LrcParser.parse(DevMusicProvider.LRC));
            } else {
                music = new HybridProvider(new SpotifyProvider(SPOTIFY_AUTH), SYSTEM);
            }
        }
        return music;
    }
}
