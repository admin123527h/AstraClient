package client.astra.hud;

import net.minecraft.text.Style;
import net.minecraft.text.StyleSpriteSource;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;

import java.util.List;
import java.util.Map;

public final class Fonts {
    public static final String DEFAULT = "Poppins";
    public static final List<String> NAMES = List.of(
            "Poppins", "Poppins Italic", "Serif", "Abril", "Pacifico", "Brush", "Bangers", "Luckiest", "Lilita", "Minecraft");

    private static final Map<String, String> IDS = Map.of(
            "Poppins", "poppins", "Poppins Italic", "poppins_italic", "Serif", "serif", "Abril", "abril",
            "Pacifico", "pacifico", "Brush", "brush", "Bangers", "bangers", "Luckiest", "luckiest", "Lilita", "lilita");

    public static final Style POPPINS = style(DEFAULT);

    private Fonts() {}

    public static Style style(String name) {
        String id = IDS.get(name);
        if (id == null) return Style.EMPTY;
        return Style.EMPTY.withFont(new StyleSpriteSource.Font(Identifier.of("astra", id)));
    }

    public static Text of(String s) {
        return of(s, DEFAULT);
    }

    public static Text of(String s, String font) {
        return Text.literal(s).setStyle(style(font));
    }
}
