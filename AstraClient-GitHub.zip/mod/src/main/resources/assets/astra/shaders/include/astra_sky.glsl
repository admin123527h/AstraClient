// Astra skies: one function, astraSky(direction, seconds, id), returns the colour of the sky in that direction.
// ids: 0 Saturn, 1 Northern Lights, 2 Polar Lights, 3 Nebula, 4 Galaxy, 5 End Beams, 6 Underwater, 7 Meteor Shower,
//      8 Star Trails, 9 Sunset, 10 Thunderstorm, 11 Blood Moon, 12 Comet, 13 Solar Eclipse, 14 Neon Horizon, 15 Cherry Blossom

// 0 high, 1 medium, 2 low: fewer noise octaves and trail steps (set by the fragment shader from the FPS booster)
int astraQ = 0;

float ah2(vec2 p) { return fract(sin(dot(p, vec2(127.1, 311.7))) * 43758.5453123); }
float ah3(vec3 p) { return fract(sin(dot(p, vec3(127.1, 311.7, 74.7))) * 43758.5453123); }

float anoise(vec2 p) {
    vec2 i = floor(p);
    vec2 f = fract(p);
    f = f * f * (3.0 - 2.0 * f);
    return mix(mix(ah2(i), ah2(i + vec2(1.0, 0.0)), f.x), mix(ah2(i + vec2(0.0, 1.0)), ah2(i + vec2(1.0, 1.0)), f.x), f.y);
}

float afbm(vec2 p) {
    float v = 0.0;
    float a = 0.5;
    int octaves = astraQ == 0 ? 5 : (astraQ == 1 ? 4 : 3);
    for (int i = 0; i < 5; i++) {
        if (i >= octaves) break;
        v += a * anoise(p);
        p = p * 2.03 + vec2(17.3, 9.1);
        a *= 0.5;
    }
    return v;
}

vec3 astars(vec3 d, float density, float t, float size) {
    vec3 p = d * density;
    vec3 id = floor(p);
    vec3 f = fract(p) - 0.5;
    float h = ah3(id);
    vec3 o = vec3(ah3(id + 1.7), ah3(id + 4.1), ah3(id + 9.3)) - 0.5;
    float dist = length(f - o * 0.6);
    float on = step(0.92, h);
    float tw = 0.7 + 0.3 * sin(t * (2.0 + h * 5.0) + h * 40.0);
    float s = on * smoothstep(size, 0.0, dist) * tw * (0.45 + 0.55 * fract(h * 17.0));
    return mix(vec3(0.8, 0.85, 1.0), vec3(1.0, 0.9, 0.8), fract(h * 7.0)) * s;
}

vec3 starField(vec3 d, float t, float strength) {
    return (astars(d, 120.0, t, 0.16) + astars(d, 60.0, t, 0.2) * 0.8 + astars(d, 30.0, t, 0.22) * 0.6) * strength;
}

vec3 vgrad(vec3 d, vec3 horizon, vec3 zenith, float power) {
    float y = clamp(d.y, 0.0, 1.0);
    vec3 up = mix(horizon, zenith, pow(y, power));
    return d.y < 0.0 ? mix(horizon, horizon * 0.5, clamp(-d.y * 3.0, 0.0, 1.0)) : up;
}

mat3 abasis(vec3 c) {
    vec3 up = abs(c.y) > 0.95 ? vec3(1.0, 0.0, 0.0) : vec3(0.0, 1.0, 0.0);
    vec3 u = normalize(cross(up, c));
    vec3 v = cross(c, u);
    return mat3(u, v, c);
}

// ---------------------------------------------------------------- 0 Saturn
vec3 saturnSky(vec3 d, float t) {
    vec3 col = vgrad(d, vec3(0.10, 0.07, 0.19), vec3(0.025, 0.02, 0.06), 0.8);
    col += starField(d, t, 1.2);
    col += vec3(0.12, 0.08, 0.2) * pow(afbm(vec2(atan(d.z, d.x) * 1.5, d.y * 4.0)), 3.0) * 0.8;

    vec3 C = normalize(vec3(-0.5, 0.38, -0.78)) * 9.0;
    float Rp = 1.7;
    vec3 N = normalize(vec3(0.3, 0.62, 0.72));
    vec3 L = normalize(vec3(0.6, 0.45, 0.35));

    float b = dot(d, C);
    float disc = b * b - (dot(C, C) - Rp * Rp);
    float tS = 1e9;
    if (disc > 0.0) tS = b - sqrt(disc);

    float tR = 1e9;
    float ringA = 0.0;
    vec3 ringCol = vec3(0.0);
    float denom = dot(d, N);
    if (abs(denom) > 1e-4) {
        float tp = dot(C, N) / denom;
        if (tp > 0.0) {
            float r = length(d * tp - C) / Rp;
            if (r > 1.4 && r < 2.5) {
                float band = 0.6 + 0.4 * sin(r * 22.0 + 2.5 * sin(r * 6.0));
                float gap = smoothstep(0.0, 0.03, abs(r - 2.02) - 0.05);
                ringA = band * gap * smoothstep(1.4, 1.5, r) * (1.0 - smoothstep(2.25, 2.5, r)) * 0.95;
                ringCol = mix(vec3(0.7, 0.55, 0.38), vec3(0.97, 0.88, 0.68), band);
                tR = tp;
            }
        }
    }

    bool planet = tS < 1e8;
    bool ring = ringA > 0.0;
    if (ring && (!planet || tR > tS)) col = mix(col, ringCol, ringA);
    if (planet) {
        vec3 n = normalize(d * tS - C);
        float lat = dot(n, N);
        float bands = 0.5 + 0.5 * sin(lat * 20.0 + 2.5 * afbm(vec2(lat * 6.0, 0.7)));
        vec3 base = mix(vec3(0.78, 0.6, 0.38), vec3(0.96, 0.86, 0.66), bands);
        float lit = max(dot(n, L), 0.0) * 0.95 + 0.1;
        float shadow = 1.0;
        col = base * lit * shadow;
    } else {
        float ang = acos(clamp(dot(d, normalize(C)), -1.0, 1.0));
        col += vec3(0.9, 0.7, 0.4) * exp(-pow(max(ang - 0.11, 0.0) * 14.0, 1.0)) * 0.08 * step(0.0, dot(d, C));
    }
    if (ring && planet && tR < tS) col = mix(col, ringCol * (0.55 + 0.45 * max(dot(N, L), 0.0)), ringA);

    vec3 M = normalize(vec3(0.55, 0.55, -0.65));
    float md = length(d - M);
    col = mix(col, vec3(0.78, 0.76, 0.8) * (0.7 + 0.3 * afbm(d.xz * 40.0)), smoothstep(0.014, 0.011, md));
    return col;
}

// ---------------------------------------------------------------- 1, 2 aurora
float auroraCurtain(vec3 d, float t, float seed) {
    vec2 p = d.xz * (1.6 / max(d.y + 0.12, 0.08));
    float n = afbm(vec2(p.x * 0.22 + t * 0.03 + seed, p.y * 0.1 - t * 0.02));
    float sheet = smoothstep(0.38, 0.72, n);
    float rays = 0.45 + 0.9 * pow(anoise(vec2(p.x * 2.2 + seed * 7.0, t * 0.15)), 2.0);
    float fade = smoothstep(0.0, 0.18, d.y) * (1.0 - smoothstep(0.5, 0.95, d.y));
    return sheet * rays * fade;
}

vec3 auroraSky(vec3 d, float t, vec3 deep, vec3 low, vec3 cA, vec3 cB, vec3 cC) {
    vec3 col = vgrad(d, low, deep, 0.7);
    col += starField(d, t, 1.0) * (1.0 - smoothstep(0.0, 0.6, auroraCurtain(d, t, 0.0)));
    float a1 = auroraCurtain(d, t, 0.0);
    float a2 = auroraCurtain(d.zyx * vec3(1.0, 1.0, -1.0), t * 1.3, 4.0) * 0.7;
    float h = clamp(d.y * 1.6, 0.0, 1.0);
    vec3 tint = mix(cA, cB, smoothstep(0.0, 0.5, h));
    tint = mix(tint, cC * 0.65, smoothstep(0.45, 1.0, h));
    // Soft shoulder: the curtains glow in colour instead of burning out to white where they are strongest.
    vec3 glow = tint * (a1 + a2) * 1.35;
    glow = glow / (1.0 + glow * 0.85);
    col += glow * 1.25;
    return col;
}

// ---------------------------------------------------------------- 3 Nebula
vec3 nebulaSky(vec3 d, float t) {
    vec3 col = vgrad(d, vec3(0.08, 0.03, 0.14), vec3(0.02, 0.01, 0.06), 0.8);
    vec2 uv = vec2(atan(d.z, d.x) * 1.4, d.y * 3.2);
    float w = afbm(uv * 1.3 + vec2(t * 0.01, 0.0));
    float n = afbm(uv * 1.7 + w * 2.6 + vec2(0.0, t * 0.015));
    float n2 = afbm(uv * 3.1 - w * 1.8);
    vec3 c = mix(vec3(0.35, 0.05, 0.55), vec3(0.95, 0.25, 0.75), n);
    c = mix(c, vec3(0.2, 0.35, 0.95), smoothstep(0.45, 0.85, n2) * 0.7);
    float density = smoothstep(0.3, 0.8, n) * (0.35 + 0.65 * smoothstep(-0.2, 0.7, d.y + 0.2));
    col += c * density * 1.15;
    col += vec3(1.0, 0.85, 1.0) * pow(smoothstep(0.62, 0.9, n), 3.0) * 0.4;
    col += starField(d, t, 1.1);
    return col;
}

// ---------------------------------------------------------------- 4 Galaxy
vec3 galaxySky(vec3 d, float t) {
    vec3 col = vgrad(d, vec3(0.04, 0.04, 0.12), vec3(0.01, 0.01, 0.04), 0.8);
    col += starField(d, t, 1.0);
    vec3 c = normalize(vec3(0.3, 0.52, -0.8));
    mat3 B = abasis(c);
    float facing = dot(d, c);
    if (facing > 0.05) {
        vec3 local = vec3(dot(d, B[0]), dot(d, B[1]), facing);
        vec2 q = local.xy / local.z * 1.7;
        q = mat2(0.94, -0.34, 0.34, 0.94) * q;
        q.y *= 2.1;
        float r = length(q);
        float th = atan(q.y, q.x);
        float arms = 0.5 + 0.5 * cos(2.0 * th - log(r + 0.05) * 5.5 + t * 0.02);
        float disk = exp(-r * 1.15) * (0.35 + 0.9 * arms);
        float core = exp(-r * r * 9.0);
        float dust = afbm(q * 3.0 + t * 0.005);
        vec3 gc = mix(vec3(0.35, 0.3, 0.95), vec3(0.85, 0.55, 1.0), arms);
        col += gc * disk * (0.45 + 0.8 * dust) * 1.2;
        col += vec3(1.0, 0.92, 0.85) * core * 1.1;
        col += starField(d * 1.3, t, 1.0) * disk * 1.5;
    }
    return col;
}

// ---------------------------------------------------------------- 5 End Beams
vec3 endBeamsSky(vec3 d, float t) {
    vec3 col = vgrad(d, vec3(0.07, 0.04, 0.13), vec3(0.015, 0.01, 0.03), 0.8);
    col += starField(d, t, 0.8);
    float c = cos(0.45);
    float s = sin(0.45);
    vec3 e = vec3(d.x * c - d.y * s, d.x * s + d.y * c, d.z);
    vec2 p = e.xz / (abs(e.y) + 0.45);
    float beams = 0.0;
    for (int i = 0; i < 3; i++) {
        float fi = float(i);
        float x = p.x * (4.0 + fi * 2.5) + sin(t * (0.1 + fi * 0.05) + fi * 3.0) * 0.8;
        float line = pow(anoise(vec2(x, fi * 11.0 + floor(t * 0.15))), 7.0);
        beams += line * (0.8 - fi * 0.2);
    }
    float reach = smoothstep(-0.2, 0.55, e.y) * 1.2;
    vec3 bc = mix(vec3(0.55, 0.35, 1.0), vec3(1.0, 0.9, 1.0), clamp(beams * 0.6, 0.0, 1.0));
    col += bc * beams * reach * 1.6;
    return col;
}

// ---------------------------------------------------------------- 6 Underwater
vec3 underwaterSky(vec3 d, float t) {
    vec3 deep = vec3(0.01, 0.2, 0.28);
    vec3 shallow = vec3(0.15, 0.7, 0.8);
    vec3 col = mix(deep, shallow, clamp(d.y * 0.7 + 0.35, 0.0, 1.0));
    vec2 uv = d.xz / (abs(d.y) + 0.35) * 1.4;
    vec2 p = mod(uv * 2.0, 6.2831853) - 250.0;
    vec2 i = p;
    float c = 1.0;
    float inten = 0.005;
    for (int n = 0; n < 4; n++) {
        float tt = t * 0.35 * (1.0 - 3.5 / float(n + 1));
        i = p + vec2(cos(tt - i.x) + sin(tt + i.y), sin(tt - i.y) + cos(tt + i.x));
        c += 1.0 / length(vec2(p.x / (sin(i.x + tt) / inten), p.y / (cos(i.y + tt) / inten)));
    }
    c /= 4.0;
    c = 1.17 - pow(c, 1.4);
    float caustic = pow(abs(c), 8.0);
    float shafts = pow(anoise(vec2(uv.x * 1.6 + t * 0.05, 0.0)), 2.0) * smoothstep(-0.1, 0.8, d.y);
    col += vec3(0.5, 0.95, 1.0) * caustic * 0.55 * smoothstep(-0.3, 0.5, d.y);
    col += vec3(0.4, 0.9, 1.0) * shafts * 0.35;
    return col;
}

// ---------------------------------------------------------------- 7 Meteor Shower
vec3 meteorSky(vec3 d, float t) {
    vec3 col = vgrad(d, vec3(0.05, 0.05, 0.12), vec3(0.012, 0.012, 0.04), 0.8);
    col += starField(d, t, 1.1);
    vec2 uv = vec2(atan(d.z, d.x), d.y) * vec2(1.0, 1.0);
    for (int i = 0; i < 8; i++) {
        float fi = float(i);
        float period = 2.2 + fi * 0.9;
        float ph = fract((t + fi * 2.7) / period);
        float seed = floor((t + fi * 2.7) / period) + fi * 13.0;
        vec2 start = vec2((ah2(vec2(seed, 1.0)) * 2.0 - 1.0) * 3.0, 0.35 + ah2(vec2(seed, 2.0)) * 0.7);
        vec2 dir = normalize(vec2(-0.8, -0.55));
        float len = 0.9;
        vec2 head = start + dir * ph * 2.4;
        vec2 rel = uv - head;
        float along = dot(rel, -dir);
        float across = length(rel + dir * along);
        float tail = smoothstep(0.0, len, along) * (1.0 - smoothstep(len * 0.9, len, along));
        float body = exp(-across * 90.0) * (along > 0.0 ? exp(-along * 5.0) : 0.0);
        float headGlow = exp(-length(rel) * 60.0);
        float fade = sin(ph * 3.14159);
        col += (vec3(0.9, 0.95, 1.0) * body + vec3(1.0, 0.9, 0.8) * headGlow) * fade * 2.0;
    }
    return col;
}

// ---------------------------------------------------------------- 8 Star Trails
vec3 starTrailSky(vec3 d, float t) {
    vec3 col = vgrad(d, vec3(0.06, 0.07, 0.16), vec3(0.012, 0.015, 0.045), 0.8);
    vec3 pole = normalize(vec3(0.25, 0.7, -0.66));
    vec3 u = normalize(cross(pole, vec3(0.0, 1.0, 0.0)));
    vec3 v = cross(pole, u);
    float pu = dot(d, u);
    float pv = dot(d, v);
    float pp = dot(d, pole);
    vec3 tint = vec3(0.0);
    int steps = astraQ == 0 ? 64 : (astraQ == 1 ? 32 : 16);
    for (int i = 0; i < 64; i++) {
        if (i >= steps) break;
        float a = (float(i) / float(steps)) * 0.5 - t * 0.008;
        float ca = cos(a);
        float sa = sin(a);
        vec3 r = pole * pp + u * (pu * ca - pv * sa) + v * (pu * sa + pv * ca);
        vec3 s = astars(r, 70.0, 0.0, 0.34) + astars(r, 36.0, 0.0, 0.36) * 0.8;
        tint += s * (0.25 + 0.75 * float(i) / float(steps)) * (64.0 / float(steps));
    }
    col += tint * 0.32;
    col += vec3(0.5, 0.55, 0.9) * exp(-pow(acos(clamp(pp, -1.0, 1.0)) * 18.0, 2.0)) * 0.6;
    return col;
}

// ---------------------------------------------------------------- 9 Sunset
vec3 sunsetSky(vec3 d, float t) {
    float y = clamp(d.y, -0.2, 1.0);
    vec3 col = mix(vec3(1.0, 0.55, 0.38), vec3(0.95, 0.42, 0.62), smoothstep(0.0, 0.18, y));
    col = mix(col, vec3(0.55, 0.28, 0.65), smoothstep(0.12, 0.5, y));
    col = mix(col, vec3(0.17, 0.12, 0.38), smoothstep(0.45, 1.0, y));
    vec3 S = normalize(vec3(0.0, 0.07, -1.0));
    float sd = acos(clamp(dot(d, S), -1.0, 1.0));
    col += vec3(1.0, 0.75, 0.45) * exp(-sd * 3.2) * 0.85;
    col = mix(col, vec3(1.0, 0.95, 0.75), smoothstep(0.075, 0.07, sd));
    float az = atan(d.z, d.x);
    float cl = afbm(vec2(az * 2.4 + t * 0.012, d.y * 11.0));
    float cloud = smoothstep(0.5, 0.78, cl) * smoothstep(0.02, 0.1, d.y) * (1.0 - smoothstep(0.35, 0.65, d.y));
    col = mix(col, mix(vec3(1.0, 0.55, 0.5), vec3(0.62, 0.3, 0.55), smoothstep(0.05, 0.35, d.y)), cloud * 0.8);
    col += starField(d, t, 1.0) * smoothstep(0.35, 0.9, d.y) * 0.8;
    if (d.y < 0.0) col = mix(col, vec3(0.8, 0.4, 0.35), clamp(-d.y * 3.0, 0.0, 0.6));
    return col;
}

// ---------------------------------------------------------------- 10 Thunderstorm
vec3 thunderSky(vec3 d, float t) {
    float cycle = floor(t / 6.0);
    float ph = fract(t / 6.0);
    float seed = ah2(vec2(cycle, 3.0));
    float flash = (smoothstep(0.0, 0.01, ph) * (1.0 - smoothstep(0.02, 0.09, ph))
                 + 0.7 * smoothstep(0.14, 0.15, ph) * (1.0 - smoothstep(0.15, 0.2, ph))) * step(0.25, seed);
    vec2 uv = vec2(atan(d.z, d.x) * 1.6, d.y * 2.6);
    float c1 = afbm(uv * 1.4 + vec2(t * 0.012, 0.0));
    float c2 = afbm(uv * 3.0 - vec2(t * 0.02, 0.0));
    float clouds = smoothstep(0.25, 0.8, c1 * 0.7 + c2 * 0.5);
    vec3 dark = mix(vec3(0.06, 0.07, 0.1), vec3(0.2, 0.22, 0.28), clouds);
    vec3 col = mix(vec3(0.16, 0.18, 0.24), dark, smoothstep(-0.05, 0.4, d.y));
    col += vec3(0.65, 0.72, 1.0) * flash * (0.25 + 0.8 * clouds) * 0.9;
    float bx = (ah2(vec2(cycle, 9.0)) * 2.0 - 1.0) * 2.2;
    float az = atan(d.z, d.x);
    float x = az - bx;
    float jag = (anoise(vec2(d.y * 18.0, cycle)) - 0.5) * 0.35 + (anoise(vec2(d.y * 50.0, cycle + 7.0)) - 0.5) * 0.12;
    float bolt = exp(-abs(x + jag) * 90.0) * smoothstep(-0.05, 0.1, d.y) * (1.0 - smoothstep(0.55, 0.85, d.y));
    col += vec3(0.85, 0.9, 1.0) * bolt * flash * 2.2;
    return col;
}

// ---------------------------------------------------------------- 11 Blood Moon
vec3 bloodMoonSky(vec3 d, float t) {
    vec3 col = vgrad(d, vec3(0.32, 0.05, 0.05), vec3(0.07, 0.01, 0.02), 0.7);
    vec3 M = normalize(vec3(0.15, 0.42, -0.9));
    float md = acos(clamp(dot(d, M), -1.0, 1.0));
    col += vec3(0.8, 0.12, 0.08) * exp(-md * 3.6) * 0.65;
    col += starField(d, t, 0.9) * vec3(1.0, 0.7, 0.6);
    float R = 0.16;
    if (md < R) {
        mat3 B = abasis(M);
        vec2 q = vec2(dot(d, B[0]), dot(d, B[1])) / R;
        float crater = afbm(q * 4.2 + 3.0);
        float maria = smoothstep(0.42, 0.62, afbm(q * 1.6 + 8.0));
        vec3 mc = mix(vec3(0.95, 0.4, 0.25), vec3(0.52, 0.12, 0.08), maria * 0.8);
        mc *= 0.7 + 0.5 * crater;
        float limb = sqrt(max(1.0 - dot(q, q), 0.0));
        col = mc * (0.55 + 0.6 * limb);
    }
    col += vec3(1.0, 0.25, 0.1) * exp(-pow(max(md - R, 0.0) * 18.0, 1.0)) * 0.35 * step(R, md);
    return col;
}

// ---------------------------------------------------------------- 12 Comet
vec3 cometSky(vec3 d, float t) {
    vec3 col = vgrad(d, vec3(0.05, 0.07, 0.15), vec3(0.01, 0.015, 0.045), 0.8);
    col += starField(d, t, 1.1);
    vec3 H = normalize(vec3(-0.45 + sin(t * 0.01) * 0.02, 0.38, -0.8));
    vec3 tailDir = normalize(vec3(0.75, 0.25, -0.15));
    float hd = acos(clamp(dot(d, H), -1.0, 1.0));
    col += vec3(0.85, 0.95, 1.0) * exp(-hd * 40.0) * 1.8;
    col += vec3(0.4, 0.75, 1.0) * exp(-hd * 9.0) * 0.5;
    vec3 rel = d - H;
    float along = dot(rel, tailDir);
    float across = length(rel - tailDir * along);
    if (along > 0.0) {
        float widen = 0.02 + along * 0.17;
        float body = exp(-pow(across / widen, 2.0)) * exp(-along * 2.2);
        float streak = 0.6 + 0.6 * afbm(vec2(along * 40.0 - t * 0.05, across * 120.0));
        col += mix(vec3(0.5, 0.85, 1.0), vec3(0.8, 0.9, 1.0), exp(-along * 5.0)) * body * streak * 1.4;
        float dust = exp(-pow((across - along * 0.12) / (widen * 1.8), 2.0)) * exp(-along * 2.6);
        col += vec3(1.0, 0.8, 0.55) * dust * 0.35;
    }
    return col;
}

// ---------------------------------------------------------------- 13 Solar Eclipse
vec3 eclipseSky(vec3 d, float t) {
    vec3 col = vgrad(d, vec3(0.13, 0.12, 0.25), vec3(0.015, 0.02, 0.07), 0.55);
    col += starField(d, t, 1.0) * smoothstep(0.1, 0.5, d.y);
    vec3 S = normalize(vec3(-0.15, 0.55, -0.82));
    float sd = acos(clamp(dot(d, S), -1.0, 1.0));
    mat3 B = abasis(S);
    float ang = atan(dot(d, B[1]), dot(d, B[0]));
    float R = 0.065;
    float streaks = 0.55 + 0.7 * afbm(vec2(ang * 5.0, sd * 12.0 - t * 0.02)) + 0.35 * anoise(vec2(ang * 18.0, 1.0));
    float corona = exp(-(sd - R) * 9.0) * streaks;
    col += vec3(0.9, 0.93, 1.0) * corona * step(R * 0.98, sd) * 1.15;
    col += vec3(0.7, 0.75, 1.0) * exp(-sd * 3.5) * 0.22;
    float ring = exp(-pow((sd - R) * 130.0, 2.0));
    col += vec3(1.0, 0.96, 0.9) * ring * 1.4;
    col = mix(col, vec3(0.0), smoothstep(R * 1.01, R * 0.97, sd));
    return col;
}

// ---------------------------------------------------------------- 14 Neon Horizon
vec3 neonSky(vec3 d, float t) {
    float y = clamp(d.y, -0.15, 1.0);
    vec3 col = mix(vec3(1.0, 0.25, 0.65), vec3(0.65, 0.12, 0.7), smoothstep(0.0, 0.2, y));
    col = mix(col, vec3(0.2, 0.06, 0.45), smoothstep(0.15, 0.6, y));
    col = mix(col, vec3(0.06, 0.02, 0.18), smoothstep(0.5, 1.0, y));
    vec3 S = normalize(vec3(0.0, 0.1, -1.0));
    mat3 B = abasis(S);
    vec2 q = vec2(dot(d, B[0]), dot(d, B[1])) / max(dot(d, S), 0.05);
    float r = length(q - vec2(0.0, 0.0));
    float R = 0.22;
    float stripes = smoothstep(0.0, 0.015, sin(q.y * 70.0 - t * 0.4) * 0.5 + 0.5 - (0.55 - clamp(q.y / R + 0.7, 0.0, 1.0) * 0.6));
    vec3 sunCol = mix(vec3(1.0, 0.85, 0.25), vec3(1.0, 0.3, 0.55), clamp(0.5 - q.y / R * 0.5, 0.0, 1.0));
    float sunMask = smoothstep(R, R - 0.012, r) * step(0.0, dot(d, S)) * (q.y < -0.04 ? stripes : 1.0);
    col += vec3(1.0, 0.4, 0.7) * exp(-r * 3.0) * 0.55 * step(0.0, dot(d, S));
    col = mix(col, sunCol, sunMask);
    col += starField(d, t, 1.0) * smoothstep(0.35, 0.9, d.y) * 0.9;
    if (d.y < 0.0) col = mix(col, vec3(0.55, 0.1, 0.5), clamp(-d.y * 3.0, 0.0, 0.7));
    return col;
}

// ---------------------------------------------------------------- 15 Cherry Blossom
vec3 cherrySky(vec3 d, float t) {
    float y = clamp(d.y, -0.2, 1.0);
    vec3 col = mix(vec3(1.0, 0.82, 0.9), vec3(0.95, 0.62, 0.85), smoothstep(0.0, 0.3, y));
    col = mix(col, vec3(0.62, 0.45, 0.88), smoothstep(0.25, 1.0, y));
    float az = atan(d.z, d.x);
    float cl = afbm(vec2(az * 2.0 + t * 0.01, d.y * 7.0));
    float cloud = smoothstep(0.52, 0.8, cl) * smoothstep(0.0, 0.1, d.y) * (1.0 - smoothstep(0.4, 0.75, d.y));
    col = mix(col, vec3(1.0, 0.92, 0.97), cloud * 0.65);
    vec2 uv = vec2(az * 6.0, d.y * 6.0);
    float petals = 0.0;
    for (int i = 0; i < 3; i++) {
        float fi = float(i);
        vec2 p = uv * (1.0 + fi * 0.6) + vec2(t * 0.1 * (1.0 + fi * 0.3), -t * 0.18);
        vec2 id = floor(p * 3.0);
        vec2 f = fract(p * 3.0) - 0.5;
        float h = ah2(id + fi * 19.0);
        vec2 o = vec2(ah2(id + 3.0), ah2(id + 8.0)) - 0.5;
        float dd = length((f - o * 0.5) * vec2(1.0, 1.7));
        petals += step(0.8, h) * smoothstep(0.1, 0.04, dd);
    }
    col = mix(col, vec3(1.0, 0.72, 0.84), clamp(petals, 0.0, 1.0) * 0.8 * smoothstep(0.0, 0.2, d.y));
    col += starField(d, t, 0.25) * smoothstep(0.55, 1.0, d.y);
    if (d.y < 0.0) col = mix(col, vec3(0.95, 0.65, 0.78), clamp(-d.y * 3.0, 0.0, 0.5));
    return col;
}

vec3 astraSky(vec3 d, float t, int id) {
    d = normalize(d);
    if (id == 0) return saturnSky(d, t);
    if (id == 1) return auroraSky(d, t, vec3(0.02, 0.015, 0.09), vec3(0.07, 0.05, 0.2), vec3(0.45, 0.2, 0.95), vec3(0.85, 0.35, 0.95), vec3(0.95, 0.85, 1.0));
    if (id == 2) return auroraSky(d, t, vec3(0.01, 0.04, 0.07), vec3(0.03, 0.12, 0.14), vec3(0.1, 0.9, 0.55), vec3(0.2, 0.85, 0.75), vec3(0.55, 0.45, 0.95));
    if (id == 3) return nebulaSky(d, t);
    if (id == 4) return galaxySky(d, t);
    if (id == 5) return endBeamsSky(d, t);
    if (id == 6) return underwaterSky(d, t);
    if (id == 7) return meteorSky(d, t);
    if (id == 8) return starTrailSky(d, t);
    if (id == 9) return sunsetSky(d, t);
    if (id == 10) return thunderSky(d, t);
    if (id == 11) return bloodMoonSky(d, t);
    if (id == 12) return cometSky(d, t);
    if (id == 13) return eclipseSky(d, t);
    if (id == 14) return neonSky(d, t);
    return cherrySky(d, t);
}
