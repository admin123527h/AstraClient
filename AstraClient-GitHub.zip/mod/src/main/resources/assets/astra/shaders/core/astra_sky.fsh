#version 330

#moj_import <minecraft:dynamictransforms.glsl>
#moj_import <astra:astra_sky.glsl>

in vec3 vDir;

out vec4 fragColor;

void main() {
    astraQ = int(ColorModulator.z + 0.5);
    vec3 c = clamp(astraSky(vDir, ColorModulator.y, int(ColorModulator.x + 0.5)), 0.0, 1.0);
    // Interleaved gradient noise, one 8-bit step wide: hides the banding smooth gradients show on real displays.
    float dither = fract(52.9829189 * fract(dot(gl_FragCoord.xy, vec2(0.06711056, 0.00583715))));
    fragColor = vec4(c + (dither - 0.5) / 255.0, 1.0);
}
