param([string]$Action = "poll", [long]$Arg = 0)

# Reads and controls the Windows media session (what the media keys talk to). Works with Spotify Free.
[Console]::OutputEncoding = [System.Text.Encoding]::UTF8
$ErrorActionPreference = 'Stop'
try {
    Add-Type -AssemblyName System.Runtime.WindowsRuntime
    $null = [Windows.Media.Control.GlobalSystemMediaTransportControlsSessionManager, Windows.Media.Control, ContentType = WindowsRuntime]
    $asTask = ([System.WindowsRuntimeSystemExtensions].GetMethods() | Where-Object {
        $_.Name -eq 'AsTask' -and $_.GetParameters().Count -eq 1 -and $_.GetParameters()[0].ParameterType.Name -eq 'IAsyncOperation`1' })[0]
    function Await($op, $type) {
        $task = $asTask.MakeGenericMethod($type).Invoke($null, @($op))
        $task.Wait(-1) | Out-Null
        $task.Result
    }
    $mgrType = [Windows.Media.Control.GlobalSystemMediaTransportControlsSessionManager]
    $mgr = Await ($mgrType::RequestAsync()) $mgrType
} catch {
    Write-Output ('{"ok":false,"error":"' + ($_.Exception.Message -replace '["\\\r\n]', ' ') + '"}')
    exit 2
}

function Pick-Session {
    $chosen = $null
    foreach ($x in $mgr.GetSessions()) {
        if ($x.SourceAppUserModelId -match 'Spotify') { $chosen = $x; break }
    }
    if (-not $chosen) { $chosen = $mgr.GetCurrentSession() }
    return $chosen
}

if ($Action -ne 'poll') {
    $s = Pick-Session
    if (-not $s) { Write-Output 'FAILED no session'; exit 1 }
    $op = switch ($Action) {
        'play'  { $s.TryPlayAsync() }
        'pause' { $s.TryPauseAsync() }
        'next'  { $s.TrySkipNextAsync() }
        'prev'  { $s.TrySkipPreviousAsync() }
        'seek'  { $s.TryChangePlaybackPositionAsync([long]($Arg * 10000)) }
    }
    $ok = Await $op ([bool])
    if (-not $ok) { Write-Output 'FAILED the player refused'; exit 1 }
    exit 0
}

while ($true) {
    $line = '{"ok":false}'
    try {
        $s = Pick-Session
        if ($s) {
            $props = Await ($s.TryGetMediaPropertiesAsync()) ([Windows.Media.Control.GlobalSystemMediaTransportControlsSessionMediaProperties])
            $tl = $s.GetTimelineProperties()
            $info = $s.GetPlaybackInfo()
            $playing = ($info.PlaybackStatus.ToString() -eq 'Playing')
            $pos = $tl.Position.TotalMilliseconds - $tl.StartTime.TotalMilliseconds
            if ($playing) { $pos += ([DateTimeOffset]::UtcNow - $tl.LastUpdatedTime).TotalMilliseconds }
            $dur = $tl.EndTime.TotalMilliseconds - $tl.StartTime.TotalMilliseconds
            $obj = [ordered]@{ ok = $true; title = [string]$props.Title; artist = [string]$props.Artist; pos = [long][math]::Max(0, $pos); dur = [long][math]::Max(0, $dur); playing = $playing }
            $line = $obj | ConvertTo-Json -Compress
        }
    } catch {
        $line = '{"ok":false}'
    }
    [Console]::Out.WriteLine($line)
    [Console]::Out.Flush()
    Start-Sleep -Milliseconds 1000
}
