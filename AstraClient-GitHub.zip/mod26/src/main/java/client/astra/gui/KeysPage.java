package client.astra.gui;

import client.astra.hud.Draw;
import client.astra.module.KeyNames;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.screens.options.controls.KeyBindsScreen;
import net.minecraft.network.chat.Component;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/** The Keys tab: every key binding that comes from Astra or from a mod, with the key it is on right now. */
public final class KeysPage {
    private final Ui ui;
    private final Font font;

    public KeysPage(Ui ui, Font font) {
        this.ui = ui;
        this.font = font;
    }

    /** The vanilla debug keys only work together with F3, so they never clash with a normal key. */
    private static boolean isDebugCombo(KeyMapping k) {
        return k.getCategory().equals(KeyMapping.Category.DEBUG);
    }

    public int render(GuiGraphicsExtractor c, int px, int vy, int pw, int vh, int scroll, int mx, int my) {
        Minecraft mc = Minecraft.getInstance();
        c.enableScissor(px - 2, vy, px + pw + 2, vy + vh);
        ui.clip(px - 2, vy, pw + 4, vh);
        int top = vy - scroll;
        int y = top;

        ui.button(c, px, y, pw, "Change keys (opens Minecraft's controls)", false,
                () -> mc.gui.setScreen(new KeyBindsScreen(mc.gui.screen(), mc.options)), mx, my);
        y += 22;
        ui.label(c, px, y, "This list follows your changes: whatever you set in the controls shows here at once.");
        y += 18;

        // modded keys, grouped by their category; Astra's own come first
        Map<KeyMapping.Category, List<KeyMapping>> groups = new LinkedHashMap<>();
        List<KeyMapping> all = new ArrayList<>(List.of(mc.options.keyMappings));
        for (KeyMapping k : all) {
            if (k.getCategory().id().getNamespace().equals("minecraft")) continue;
            groups.computeIfAbsent(k.getCategory(), x -> new ArrayList<>()).add(k);
        }
        List<KeyMapping.Category> order = new ArrayList<>(groups.keySet());
        order.sort((a, b) -> {
            boolean aa = a.id().getNamespace().equals("astra"), bb = b.id().getNamespace().equals("astra");
            if (aa != bb) return aa ? -1 : 1;
            return a.label().getString().compareToIgnoreCase(b.label().getString());
        });

        for (KeyMapping.Category cat : order) {
            ui.header(c, px, y, cat.label().getString());
            y += 14;
            for (KeyMapping k : groups.get(cat)) {
                String clashWith = null;
                for (KeyMapping other : all) {
                    if (other != k && !k.isUnbound() && k.same(other) && !isDebugCombo(other) && !isDebugCombo(k)) {
                        clashWith = Component.translatable(other.getName()).getString();
                        break;
                    }
                }
                boolean clash = clashWith != null;
                Draw.panel(c, px, y, pw, 20, Draw.BG_SOFT, clash ? 0xAAF87171 : Draw.BORDER);
                Draw.text(c, font, Component.translatable(k.getName()).getString(), px + 8, y + 6, Draw.TEXT);
                String key = KeyNames.of(k);
                int kw = Draw.width(font, key) + 14;
                Draw.panel(c, px + pw - kw - 6, y + 3, kw, 14, 0x66403060, Draw.BORDER, 5f);
                Draw.text(c, font, key, px + pw - kw + 1, y + 6, k.isUnbound() ? Draw.TEXT_DIM : Draw.TEXT);
                if (clash) {
                    String note = "same key as: " + clashWith;
                    int room = pw - kw - 14 - 16 - Draw.width(font, Component.translatable(k.getName()).getString());
                    while (note.length() > 12 && Draw.width(font, note) > room) note = note.substring(0, note.length() - 2);
                    Draw.text(c, font, note, px + pw - kw - 6 - 8 - Draw.width(font, note), y + 6, 0xFFF87171);
                }
                y += 23;
            }
            y += 6;
        }
        if (order.isEmpty()) {
            ui.label(c, px, y, "No mod keys found.");
            y += 18;
        }

        ui.noClip();
        c.disableScissor();
        return y - top;
    }
}
