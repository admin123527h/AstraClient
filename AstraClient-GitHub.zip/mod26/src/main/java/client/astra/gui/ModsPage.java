package client.astra.gui;

import client.astra.addons.Addons;
import client.astra.hud.Draw;
import client.astra.module.AddonStore;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphicsExtractor;

/** The Mods tab: third-party mods and resource packs, downloaded from Modrinth, switched on and off here. */
public final class ModsPage {
    private final Ui ui;
    private final Font font;

    public ModsPage(Ui ui, Font font) {
        this.ui = ui;
        this.font = font;
    }

    public int render(GuiGraphicsExtractor c, int px, int vy, int pw, int vh, int scroll, int mx, int my) {
        Addons addons = AddonStore.get();
        c.enableScissor(px - 2, vy, px + pw + 2, vy + vh);
        ui.clip(px - 2, vy, pw + 4, vh);
        int top = vy - scroll;
        int y = top;

        int half = (pw - 6) / 2;
        ui.button(c, px, y, half, "Download / update everything that is on", false, AddonStore::installAll, mx, my);
        ui.button(c, px + half + 6, y, half, AddonStore.restartNeeded() ? "Restart the game to apply mod changes" : "Mods apply when the game starts", AddonStore.restartNeeded(), () -> { }, mx, my);
        y += 24;
        ui.label(c, px, y, "Files come from Modrinth and are checked before they are used. Packs apply right away.");
        y += 18;

        ui.header(c, px, y, "Open a folder to add or remove files yourself");
        y += 14;
        String[][] folders = {{"Game folder", ""}, {"Mods", "mods"}, {"Resource packs", "resourcepacks"}, {"Saves", "saves"}, {"Config", "config"}, {"Screenshots", "screenshots"}};
        int third = (pw - 12) / 3;
        for (int i = 0; i < folders.length; i++) {
            String sub = folders[i][1];
            ui.button(c, px + (i % 3) * (third + 6), y + (i / 3) * 22, third, folders[i][0], false, () -> client.astra.module.Folders.open(sub), mx, my);
        }
        y += 50;

        for (Addons.Entry e : Addons.CATALOG) {
            Addons.State state = addons.status(e);
            boolean on = addons.enabled(e);
            Draw.panel(c, px, y, pw, 32, Draw.BG_SOFT, Draw.BORDER);
            Draw.text(c, font, e.name(), px + 8, y + 5, Draw.TEXT);
            String info = AddonStore.busy(e) || !AddonStore.message(e).isEmpty() ? AddonStore.message(e) : switch (state) {
                case ON -> on ? "Installed" : "Installed, off";
                case OFF -> "Installed, off";
                case UNAVAILABLE -> "Not available for this Minecraft version yet";
                case NOT_INSTALLED -> "Not downloaded yet";
            };
            String line = e.description() + "  -  " + info;
            int max = pw - 56 - (state == Addons.State.NOT_INSTALLED && !AddonStore.busy(e) ? 76 : 0);
            while (line.length() > 8 && Draw.width(font, line) > max) line = line.substring(0, line.length() - 2);
            Draw.text(c, font, line, px + 8, y + 18, Draw.TEXT_DIM);

            int sx = px + pw - 36, sy = y + 11;
            Draw.panel(c, sx, sy, 24, 11, on ? 0xCC8B5CF6 : 0x66403060, Draw.BORDER, 5f);
            Draw.round(c, on ? sx + 14 : sx + 2, sy + 1, 9, 9, on ? 0xFFF5F3FF : 0xFFA79BCB);
            ui.hit(sx - 4, y, 40, 32, () -> AddonStore.toggle(e));
            if (state == Addons.State.NOT_INSTALLED && !AddonStore.busy(e)) {
                ui.button(c, px + pw - 36 - 70, y + 7, 64, "Download", false, () -> AddonStore.install(e), mx, my);
            }
            y += 36;
        }

        ui.noClip();
        c.disableScissor();
        return y - top;
    }
}
