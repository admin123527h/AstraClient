package client.astra.gui;

import client.astra.hud.Draw;
import client.astra.module.ItemSkins;
import client.astra.music.AstraConfig;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.renderer.RenderPipelines;
import net.minecraft.resources.Identifier;

/** The Items tab: pick a palette for totems, shields, tools and armor, then apply (one resource reload). */
public final class ItemsPage {
    private final Ui ui;
    private final Font font;

    public ItemsPage(Ui ui, Font font) {
        this.ui = ui;
        this.font = font;
    }

    public int render(GuiGraphicsExtractor c, int px, int vy, int pw, int vh, int scroll, int mx, int my) {
        AstraConfig cfg = AstraConfig.get();
        Minecraft mc = Minecraft.getInstance();
        c.enableScissor(px - 2, vy, px + pw + 2, vy + vh);
        ui.clip(px - 2, vy, pw + 4, vh);
        int top = vy - scroll;
        int y = top;

        boolean pending = ItemSkins.pending();
        int half = (pw - 6) / 2;
        ui.button(c, px, y, half, pending ? "Apply item looks (reloads resources)" : "Apply item looks", pending, () -> ItemSkins.apply(mc), mx, my);
        ui.button(c, px + half + 6, y, half, "Back to normal", false, () -> ItemSkins.reset(mc), mx, my);
        y += 22;
        String status = ItemSkins.status();
        ui.label(c, px, y, status.isEmpty() ? "Pick a design for each group, then apply. Applying takes a few seconds." : status);
        y += 18;

        int cols = 5;
        int cw = (pw - (cols - 1) * 6) / cols;
        int ch = 58;
        for (ItemSkins.Category cat : ItemSkins.CATEGORIES) {
            ui.header(c, px, y, cat.label());
            y += 14;
            String selected = ItemSkins.selected(cat);
            for (int i = 0; i < ItemSkins.PRESETS.size(); i++) {
                ItemSkins.Preset preset = ItemSkins.PRESETS.get(i);
                int x = px + (i % cols) * (cw + 6);
                int cy = y + (i / cols) * (ch + 6);
                boolean on = preset.name().equals(selected);
                ui.card(c, x, cy, cw, ch, on, () -> { cfg.itemSkins.put(cat.id(), preset.name()); cfg.save(); }, mx, my);
                Identifier tex = ItemSkins.preview(cat, preset);
                if (tex != null) {
                    int scale = Math.max(1, Math.min(34 / cat.cropW(), 34 / cat.cropH()));
                    int w = cat.cropW() * scale, h = cat.cropH() * scale;
                    c.blit(RenderPipelines.GUI_TEXTURED, tex, x + (cw - w) / 2, cy + 3 + (34 - h) / 2, 0f, 0f, w, h, cat.cropW(), cat.cropH(), cat.cropW(), cat.cropH());
                }
                String name = preset.name();
                Draw.text(c, font, name, x + (cw - Draw.width(font, name)) / 2, cy + ch - 15, Draw.TEXT);
            }
            y += ((ItemSkins.PRESETS.size() + cols - 1) / cols) * (ch + 6) + 4;
        }
        ui.label(c, px, y, "Made from your own game files on this computer. Nothing is downloaded.");
        y += 18;

        ui.noClip();
        c.disableScissor();
        return y - top;
    }
}
