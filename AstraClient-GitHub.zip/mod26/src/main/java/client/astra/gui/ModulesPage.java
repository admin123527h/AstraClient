package client.astra.gui;

import client.astra.hud.Draw;
import client.astra.module.Outlines;
import client.astra.music.AstraConfig;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphicsExtractor;

/** The Modules tab: Astra's own view tools (zoom, fullbright, block outline). Other mods live in the Mods tab. */
public final class ModulesPage {
    private final Ui ui;
    private final Font font;

    public ModulesPage(Ui ui, Font font) {
        this.ui = ui;
        this.font = font;
    }

    public int render(GuiGraphicsExtractor c, int px, int vy, int pw, int vh, int scroll, int mx, int my) {
        AstraConfig cfg = AstraConfig.get();
        c.enableScissor(px - 2, vy, px + pw + 2, vy + vh);
        ui.clip(px - 2, vy, pw + 4, vh);
        int top = vy - scroll;
        int y = top;

        ui.header(c, px, y, "Zoom");
        y += 14;
        ui.toggle(c, px, y, pw, "Zoom (" + client.astra.module.Modules.zoomKeyName() + ", scroll wheel changes the level)", cfg.zoomEnabled, () -> { cfg.zoomEnabled = !cfg.zoomEnabled; cfg.save(); }, mx, my);
        y += 24;
        ui.slider(c, px, y, pw, "Zoom level", String.format("%.1fx", 100f / cfg.zoomPercent), cfg.zoomPercent, 2, 90,
                v -> cfg.zoomPercent = Math.round(v), cfg::save, mx, my);
        y += 24;
        ui.toggle(c, px, y, pw, "Toggle mode (off: hold the key)", cfg.zoomToggle, () -> { cfg.zoomToggle = !cfg.zoomToggle; cfg.save(); }, mx, my);
        y += 24;
        ui.toggle(c, px, y, pw, "Cinematic camera while zooming", cfg.zoomCinematic, () -> { cfg.zoomCinematic = !cfg.zoomCinematic; cfg.save(); }, mx, my);
        y += 24;
        ui.toggle(c, px, y, pw, "Slower mouse while zooming", cfg.zoomSlowMouse, () -> { cfg.zoomSlowMouse = !cfg.zoomSlowMouse; cfg.save(); }, mx, my);
        y += 30;

        ui.header(c, px, y, "Light");
        y += 14;
        ui.toggle(c, px, y, pw, "Fullbright (" + client.astra.module.Modules.fullbrightKeyName() + ")", cfg.fullbright, () -> { cfg.fullbright = !cfg.fullbright; cfg.save(); }, mx, my);
        y += 30;

        if (Outlines.supported()) {
            ui.header(c, px, y, "Outlines");
            y += 14;
            ui.toggle(c, px, y, pw, "Block outline in my colour", cfg.outlines, () -> { cfg.outlines = !cfg.outlines; cfg.save(); }, mx, my);
            y += 24;
            int[] palette = {0xA78BFA, 0x34D399, 0xFBBF24, 0xF87171, 0x60A5FA, 0xF472B6, 0xFFFFFF, 0x2DD4BF};
            int sw = (pw - 7 * 4) / 8;
            for (int i = 0; i < palette.length; i++) {
                int col = palette[i];
                int sx = px + i * (sw + 4);
                Draw.panel(c, sx, y, sw, 16, 0xFF000000 | col, cfg.outlineColor == col ? 0xFFFFFFFF : Draw.BORDER, 4f);
                ui.hit(sx, y, sw, 16, () -> { cfg.outlineColor = col; cfg.outlines = true; cfg.save(); });
            }
            y += 22;
            ui.toggle(c, px, y, pw, "Show entity hitboxes (like F3 + B)", Outlines.hitboxes(), Outlines::toggleHitboxes, mx, my);
            y += 28;
        }

        ui.label(c, px, y, "Minimap, world map, freecam and the vein miners are in the Mods tab.");
        y += 18;

        ui.noClip();
        c.disableScissor();
        return y - top;
    }
}
