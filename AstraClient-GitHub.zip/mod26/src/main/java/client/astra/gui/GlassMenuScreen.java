package client.astra.gui;

import client.astra.Astra;
import client.astra.hud.Draw;
import client.astra.music.AstraConfig;
import net.minecraft.client.input.MouseButtonEvent;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.network.chat.Component;

import java.util.List;

public class GlassMenuScreen extends Screen {
    private static final List<String> TABS = List.of("Overview", "Skies", "Lyrics", "Spotify", "Styles", "HUD", "Performance", "Modules", "Items", "Mods", "Keys", "Settings", "Information");
    private static final List<String> SUBTITLES = List.of(
            "Your client at a glance", "Pick your own animated sky", "Spotify lyrics live in the sky", "Your music, in your game",
            "PvP styles", "Your top bar", "Smoother gameplay", "Zoom, minimap, freecam and more", "Totems, shields, tools and armor", "Map, freecam, vein miner and more", "Every key of Astra and your mods", "Tune Astra to your setup", "About this build");
    private static final int LYRICS = 2, SPOTIFY = 3, SIDEBAR = 112;

    private final SpotifyPage spotify = new SpotifyPage();
    private final int[] scroll = new int[TABS.size()];
    private final int[] contentHeight = new int[TABS.size()];
    private int tab;
    private int x, y, w, h;
    private int viewTop, viewHeight;
    private String status = "";
    private EditBox search;
    private EditBox clientId;
    private int cidX, cidY, cidW;
    private Ui ui;
    private MenuPages pages;
    private LyricsPage lyrics;
    private String lastQuery = "";
    private int idle;
    private int devFrames;

    public GlassMenuScreen() {
        this(Integer.getInteger("astra.devTab", LYRICS));
    }

    public GlassMenuScreen(int tab) {
        super(Component.literal("Astra"));
        this.tab = tab;
    }

    @Override
    protected void init() {
        w = Math.min(width - 40, 540);
        h = Math.min(height - 30, 310);
        x = (width - w) / 2;
        y = (height - h) / 2;
        viewTop = y + 46;
        viewHeight = h - 54;

        search = new EditBox(font, x + SIDEBAR + 20, viewTop + 4, w - SIDEBAR - 40, 10, Component.literal("Search"));
        search.setBordered(false);
        search.setResponder(s -> idle = 0);
        addWidget(search);

        ui = new Ui(font);
        pages = new MenuPages(ui, font, new MenuPages.Host() {
            @Override public void openTab(int t) { tab = t; setFocused(null); }
            @Override public void clientIdField(GuiGraphicsExtractor c, int fx, int fy, int fw) { drawClientId(c, fx, fy, fw); }
            @Override public void connectSpotify() { GlassMenuScreen.this.connectSpotify(); }
        });
        lyrics = new LyricsPage(ui, font, this::onClose, this::connectSpotify, t -> { tab = t; setFocused(null); });

        clientId = new EditBox(font, x + SIDEBAR + 20, y + 150, w - SIDEBAR - 40, 10, Component.literal("Client ID"));
        clientId.setBordered(false);
        clientId.setMaxLength(64);
        clientId.setValue(AstraConfig.get().spotifyClientId);
        clientId.setResponder(v -> {
            AstraConfig.get().spotifyClientId = v.trim();
            AstraConfig.get().save();
        });
        addWidget(clientId);
    }

    private void drawClientId(GuiGraphicsExtractor c, int fx, int fy, int fw) {
        cidX = fx; cidY = fy; cidW = fw;
        Draw.panel(c, fx, fy, fw, 18, Draw.BG_SOFT, clientId.isFocused() ? 0xC0C4B5FD : Draw.BORDER);
        String typed = clientId.getValue();
        Draw.text(c, font, typed.isEmpty() ? "Paste your Client ID here" : typed, fx + 8, fy + 5, typed.isEmpty() ? Draw.TEXT_DIM : Draw.TEXT);
        if (clientId.isFocused() && (System.currentTimeMillis() / 500) % 2 == 0) {
            int cx = fx + 8 + Draw.width(font, typed) + 1;
            c.fill(cx, fy + 3, cx + 1, fy + 15, Draw.TEXT);
        }
    }

    private void connectSpotify() {
        AstraConfig cfg = AstraConfig.get();
        if (cfg.clientId().isEmpty()) {
            status = "Enter your Client ID in Settings first";
            pages.setStatus(status);
            tab = 11;
            return;
        }
        status = "Opening browser...";
        pages.setStatus(status);
        Astra.SPOTIFY_AUTH.login().thenAccept(error -> {
            status = error == null ? "Spotify connected" : error;
            pages.setStatus(status);
        });
    }

    @Override
    public void tick() {
        if (tab == SPOTIFY && !search.getValue().equals(lastQuery) && ++idle > 12) {
            lastQuery = search.getValue();
            spotify.showSearch(lastQuery);
        }
    }

    @Override
    public void extractRenderState(GuiGraphicsExtractor c, int mx, int my, float delta) {
        if (Astra.DEV && ++devFrames % 120 == 0) {
            System.out.println("[astra-perf] tab=" + tab + " fills/frame=" + Draw.fills / 120);
            Draw.fills = 0;
        }
        ui.begin();
        c.fill(0, 0, width, height, AstraConfig.get().menuBlur ? 0x400A0714 : 0x66080512);
        Draw.window(c, x, y, w, h, Draw.BG, Draw.BORDER, 7f);
        renderSidebar(c, mx, my);

        int px = x + SIDEBAR + 14;
        int pw = w - SIDEBAR - 28;
        Draw.text(c, font, TABS.get(tab), px, y + 11, Draw.TEXT);
        Draw.text(c, font, SUBTITLES.get(tab), px, y + 24, Draw.TEXT_DIM);
        String l1 = "Your game.", l2 = "Our client.";
        int r = x + w - 14;
        c.fill(r - Draw.width(font, l2) - 6, y + 11, r - Draw.width(font, l2) - 5, y + 32, Draw.ACCENT_DIM);
        Draw.text(c, font, l1, r - Draw.width(font, l1), y + 11, Draw.TEXT_DIM);
        Draw.text(c, font, l2, r - Draw.width(font, l2), y + 22, Draw.TEXT_DIM);

        if (tab == LYRICS) {
            contentHeight[tab] = lyrics.render(c, px, viewTop, pw, viewHeight, scroll[tab], mx, my);
        } else if (tab == SPOTIFY) {
            renderSpotify(c, px, pw, mx, my);
        } else {
            contentHeight[tab] = pages.render(tab, c, px, viewTop, pw, viewHeight, scroll[tab], mx, my);
        }
        clampScroll();
        renderScrollbar(c);
    }

    /** Row height of the sidebar: shrinks on small windows (high GUI scale) so all tabs stay visible. */
    private int step() {
        return Math.max(13, Math.min(20, (h - 46 - 10) / TABS.size()));
    }

    private void renderSidebar(GuiGraphicsExtractor c, int mx, int my) {
        c.fill(x + SIDEBAR, y + 8, x + SIDEBAR + 1, y + h - 8, Draw.ACCENT_DIM);

        Draw.panel(c, x + 8, y + 8, SIDEBAR - 16, 30, Draw.BG_SOFT, Draw.BORDER, 5f);
        // the Astra logo
        c.blit(net.minecraft.client.renderer.RenderPipelines.GUI_TEXTURED, net.minecraft.resources.Identifier.fromNamespaceAndPath("astra", "textures/gui/logo.png"), x + 12, y + 12, 0f, 0f, 22, 22, 96, 96, 96, 96);
        Draw.text(c, font, "Astra", x + 38, y + 12, Draw.TEXT);
        Draw.text(c, font, "Client", x + 38, y + 24, Draw.TEXT_DIM);

        for (int i = 0; i < TABS.size(); i++) {
            int ty = y + 46 + i * step();
            boolean hover = mx >= x + 8 && mx < x + SIDEBAR - 8 && my >= ty && my < ty + step() - 3;
            if (i == tab) Draw.round(c, x + 8, ty, SIDEBAR - 16, step() - 3, Draw.ACCENT_DIM);
            else if (hover) Draw.round(c, x + 8, ty, SIDEBAR - 16, step() - 3, 0x33A78BFA);
            Draw.text(c, font, TABS.get(i), x + 16, ty + 5, i == tab ? Draw.TEXT : Draw.TEXT_DIM);
        }
        if (46 + TABS.size() * step() + 26 < h) {
            Draw.text(c, font, "Astra", x + 14, y + h - 22, Draw.TEXT_DIM);
            Draw.text(c, font, "v0.1.0", x + 14, y + h - 12, Draw.TEXT_DIM);
        }
    }

    private void renderScrollbar(GuiGraphicsExtractor c) {
        int content = contentHeight[tab];
        if (content <= viewHeight) return;
        int trackX = x + w - 8, trackH = viewHeight;
        int thumbH = Math.max(18, trackH * viewHeight / content);
        int travel = trackH - thumbH;
        int maxScroll = content - viewHeight;
        int thumbY = viewTop + (maxScroll == 0 ? 0 : travel * scroll[tab] / maxScroll);
        Draw.round(c, trackX, viewTop, 3, trackH, 0x33A78BFA);
        Draw.round(c, trackX, thumbY, 3, thumbH, 0xAAC4B5FD);
    }

    private void clampScroll() {
        int max = Math.max(0, contentHeight[tab] - viewHeight);
        scroll[tab] = Math.max(0, Math.min(max, scroll[tab]));
    }

    private void renderSpotify(GuiGraphicsExtractor c, int px, int pw, int mx, int my) {
        spotify.ensureLoaded();
        Draw.panel(c, px, viewTop, pw, 18, Draw.BG_SOFT, search.isFocused() ? 0xC0C4B5FD : Draw.BORDER);
        String typed = search.getValue();
        Draw.text(c, font, typed.isEmpty() ? "Search songs..." : typed, px + 8, viewTop + 5, typed.isEmpty() ? Draw.TEXT_DIM : Draw.TEXT);
        if (search.isFocused() && (System.currentTimeMillis() / 500) % 2 == 0) {
            int cx = px + 8 + Draw.width(font, typed) + 1;
            c.fill(cx, viewTop + 3, cx + 1, viewTop + 15, Draw.TEXT);
        }
        spotify.render(c, px, viewTop + 24, pw, viewHeight - 24, mx, my);
    }

    @Override
    public boolean mouseClicked(MouseButtonEvent click, boolean doubled) {
        double mx = click.x(), my = click.y();
        for (int i = 0; i < TABS.size(); i++) {
            int ty = y + 46 + i * step();
            if (mx >= x + 8 && mx < x + SIDEBAR - 8 && my >= ty && my < ty + step() - 3) { tab = i; setFocused(null); return true; }
        }
        if (tab == 11 && mx >= cidX && mx < cidX + cidW && my >= cidY && my < cidY + 18) {
            setFocused(clientId);
            return super.mouseClicked(click, doubled);
        }
        if (ui.click(mx, my)) return true;
        if (tab == SPOTIFY) {
            if (my >= viewTop && my < viewTop + 18) {
                setFocused(search);
                return super.mouseClicked(click, doubled);
            }
            if (spotify.click(mx, my, true)) return true;
        }
        return super.mouseClicked(click, doubled);
    }

    @Override
    public boolean mouseDragged(MouseButtonEvent click, double offsetX, double offsetY) {
        ui.drag(click.x());
        return super.mouseDragged(click, offsetX, offsetY);
    }

    @Override
    public boolean mouseReleased(MouseButtonEvent click) {
        ui.release();
        return super.mouseReleased(click);
    }

    @Override
    public boolean mouseScrolled(double mx, double my, double horizontal, double vertical) {
        if (tab == SPOTIFY && spotify.scroll(mx, my, vertical)) return true;
        if (contentHeight[tab] > viewHeight) {
            scroll[tab] -= (int) (vertical * 16);
            clampScroll();
            return true;
        }
        return super.mouseScrolled(mx, my, horizontal, vertical);
    }

    @Override
    protected void extractBlurredBackground(GuiGraphicsExtractor graphics) {
        if (AstraConfig.get().menuBlur) super.extractBlurredBackground(graphics);
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }
}
