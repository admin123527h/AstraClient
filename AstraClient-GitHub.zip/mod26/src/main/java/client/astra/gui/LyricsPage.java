package client.astra.gui;

import client.astra.Astra;
import client.astra.hud.Draw;
import client.astra.hud.Fonts;
import client.astra.lyrics.LyricsRenderer;
import client.astra.lyrics.LyricsStyle;
import client.astra.music.AstraConfig;
import client.astra.music.MusicProvider;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphicsExtractor;

import java.util.function.IntConsumer;

/** Lyrics page: now playing, look presets, fonts, colours, glow and size. Scrolls vertically. */
public final class LyricsPage {
    private static final int[] PALETTE = {
            0xFFFFFF, 0xDDD6FE, 0xC4B5FD, 0xA78BFA, 0xF472B6, 0xEF4444, 0xF97316, 0xFACC15,
            0xA3E635, 0x4ADE80, 0x2DD4BF, 0x22D3EE, 0x60A5FA, 0x93C5FD, 0x9CA3AF};

    private final Ui ui;
    private final Font font;
    private final Runnable closeMenu;
    private final Runnable connect;
    private final IntConsumer openTab;

    public LyricsPage(Ui ui, Font font, Runnable closeMenu, Runnable connect, IntConsumer openTab) {
        this.ui = ui;
        this.font = font;
        this.closeMenu = closeMenu;
        this.connect = connect;
        this.openTab = openTab;
    }

    /** Draws the page inside the viewport and returns the full content height for scrolling. */
    public int render(GuiGraphicsExtractor c, int px, int vy, int pw, int vh, int scroll, int mx, int my) {
        AstraConfig cfg = AstraConfig.get();
        c.enableScissor(px - 2, vy, px + pw + 2, vy + vh);
        ui.clip(px - 2, vy, pw + 4, vh);

        int top = vy - scroll;
        int y = top;

        y = nowPlaying(c, px, y, pw, mx, my) + 8;

        ui.toggle(c, px, y, pw, "Show the current line in the top bar", cfg.hudMusic, () -> { cfg.hudMusic = !cfg.hudMusic; cfg.save(); }, mx, my);
        y += 24;
        ui.toggle(c, px, y, pw, "Show the song title when a new song starts", cfg.announceSong, () -> { cfg.announceSong = !cfg.announceSong; cfg.save(); }, mx, my);
        y += 24;

        Draw.panel(c, px, y, pw, 20, Draw.BG_SOFT, Draw.BORDER);
        Draw.text(c, font, "Try it in the sky", px + 8, y + 6, Draw.TEXT);
        ui.button(c, px + pw - 58, y + 2, 52, "Test", true, () -> { LyricsRenderer.startTest(); closeMenu.run(); }, mx, my);
        y += 24;
        ui.label(c, px, y, "Music keys: " + client.astra.module.KeyNames.of(client.astra.AstraClient.PREV) + " previous, " + client.astra.module.KeyNames.of(client.astra.AstraClient.PLAY) + " play / pause, " + client.astra.module.KeyNames.of(client.astra.AstraClient.NEXT) + " next");
        y += 16;

        ui.header(c, px, y, "Where");
        y += 13;
        boolean follow = "Follow".equals(cfg.lyricsMode);
        ui.toggle(c, px, y, pw, "Follow my view (off: stay where it appears)", follow,
                () -> { cfg.lyricsMode = follow ? "Floating" : "Follow"; cfg.save(); }, mx, my);
        y += 24;
        ui.toggle(c, px, y, pw, "Each word stays where I looked (words trail behind me)", cfg.lyricsTrail, () -> { cfg.lyricsTrail = !cfg.lyricsTrail; cfg.save(); }, mx, my);
        y += 24;
        ui.slider(c, px, y, pw, "Show the line early (to sing along)", cfg.lyricsLeadMs <= 0 ? "off" : String.format("%.2f s", cfg.lyricsLeadMs / 1000f), cfg.lyricsLeadMs, 0, 6000,
                v -> cfg.lyricsLeadMs = Math.round(v / 250f) * 250, cfg::save, mx, my);
        y += 24;
        ui.toggle(c, px, y, pw, "Show words one by one (when the line is not shown early)", cfg.lyricsReveal, () -> { cfg.lyricsReveal = !cfg.lyricsReveal; cfg.save(); }, mx, my);
        y += 24;
        ui.toggle(c, px, y, pw, "Highlight the sung word", cfg.lyricsWordByWord, () -> { cfg.lyricsWordByWord = !cfg.lyricsWordByWord; cfg.save(); }, mx, my);
        y += 30;

        ui.header(c, px, y, "Look");
        y += 13;
        int cw = (pw - 12) / 3;
        for (int i = 0; i < LyricsStyle.ALL.size(); i++) {
            LyricsStyle s = LyricsStyle.ALL.get(i);
            int cx = px + (i % 3) * (cw + 6), cy = y + (i / 3) * 24;
            ui.card(c, cx, cy, cw, 20, s.name().equals(cfg.lyricsStyle), () -> s.apply(cfg), mx, my);
            int tw = Draw.width(font, s.name(), s.font());
            Draw.text(c, font, s.name(), cx + (cw - tw) / 2, cy + 6, 0xFF000000 | s.color2(), s.font());
        }
        y += 3 * 24 + 6;

        ui.header(c, px, y, "Font");
        y += 13;
        int fw = (pw - 24) / 5;
        for (int i = 0; i < Fonts.NAMES.size(); i++) {
            String name = Fonts.NAMES.get(i);
            int fx = px + (i % 5) * (fw + 6), fy = y + (i / 5) * 24;
            ui.card(c, fx, fy, fw, 20, name.equals(cfg.lyricsFont), () -> { cfg.lyricsFont = name; cfg.save(); }, mx, my);
            int tw = Draw.width(font, name, name);
            Draw.text(c, font, name, fx + Math.max(3, (fw - tw) / 2), fy + 6, Draw.TEXT, name);
        }
        y += 2 * 24 + 6;

        colorRow(c, px, y, pw, "Color 1", cfg.lyricsColor1, v -> cfg.lyricsColor1 = v, mx, my);
        y += 26;
        colorRow(c, px, y, pw, "Color 2", cfg.lyricsColor2, v -> cfg.lyricsColor2 = v, mx, my);
        y += 30;

        ui.slider(c, px, y, pw, "Glow", Math.round(cfg.lyricsGlow * 100) + "%", cfg.lyricsGlow, 0f, 1f,
                v -> cfg.lyricsGlow = Math.round(v * 20) / 20f, cfg::save, mx, my);
        y += 24;
        ui.slider(c, px, y, pw, "Size", String.format("%.2fx", cfg.lyricsSize), cfg.lyricsSize, 0.5f, 2f,
                v -> cfg.lyricsSize = Math.round(v * 20) / 20f, cfg::save, mx, my);
        y += 28;
        ui.button(c, px, y, pw, "Advanced", false, () -> openTab.accept(7), mx, my);
        y += 24;

        ui.noClip();
        c.disableScissor();
        return y - top;
    }

    private int nowPlaying(GuiGraphicsExtractor c, int px, int y, int pw, int mx, int my) {
        AstraConfig cfg = AstraConfig.get();
        Draw.panel(c, px, y, pw, 52, Draw.BG_SOFT, Draw.BORDER, 5f);
        Draw.gradient(c, px + 6, y + 6, 40, 40, 0xFF7C5CE0, 0xFF3B2A7A, 4f);
        for (int i = 0; i < 4; i++) {
            int bh = 6 + ((i * 7 + (int) (System.currentTimeMillis() / 180)) % 5) * 3;
            c.fill(px + 14 + i * 7, y + 34 - bh, px + 18 + i * 7, y + 34, 0xFFF5F3FF);
        }

        boolean ready = Astra.SPOTIFY_AUTH.loggedIn() || Astra.DEV;
        var track = ready ? Astra.music().current() : java.util.Optional.<MusicProvider.Track>empty();
        int tx = px + 54;
        if (!ready) {
            Draw.text(c, font, "Spotify is not connected", tx, y + 8, Draw.TEXT);
            ui.button(c, tx, y + 26, 120, "Connect Spotify", true, connect, mx, my);
            return y + 52;
        }
        if (track.isEmpty()) {
            Draw.text(c, font, "Nothing playing", tx, y + 8, Draw.TEXT);
            String problem = Astra.music().problem();
            if (problem.isEmpty()) Draw.text(c, font, "Start a song in Spotify", tx, y + 22, Draw.TEXT_DIM);
            else Draw.text(c, font, clip(problem, pw - 54 - 10), tx, y + 22, 0xFFFCA5A5);
            return y + 52;
        }

        MusicProvider.Track t = track.get();
        Draw.text(c, font, clip(t.title(), pw - 54 - 100), tx, y + 7, Draw.TEXT);
        Draw.text(c, font, clip(t.artist(), pw - 54 - 100), tx, y + 19, Draw.TEXT_DIM);

        boolean synced = Astra.LYRICS.timeline().size() > 0;
        String tag = synced ? "Lyrics synced" : "No lyrics";
        int tagW = Draw.width(font, tag) + 10;
        Draw.panel(c, tx, y + 31, tagW, 12, synced ? 0x6622C55E : 0x55808080, synced ? 0x9966F08A : Draw.BORDER, 5f);
        Draw.text(c, font, tag, tx + 5, y + 33, synced ? 0xFFBBF7D0 : Draw.TEXT_DIM);
        int sec = (int) (t.positionMs() / 1000), tot = (int) (t.durationMs() / 1000);
        Draw.text(c, font, (sec / 60) + ":" + String.format("%02d", sec % 60) + " / " + (tot / 60) + ":" + String.format("%02d", tot % 60),
                tx + tagW + 8, y + 33, Draw.TEXT_DIM);

        int barX = tx, barW = pw - 54 - 10, barY = y + 46;
        Draw.round(c, barX, barY, barW, 3, 0x66403060);
        int filled = t.durationMs() > 0 ? (int) (barW * t.positionMs() / t.durationMs()) : 0;
        if (filled > 1) Draw.round(c, barX, barY, filled, 3, Draw.ACCENT);
        ui.hitX(barX, barY - 3, barW, 9, hx -> client.astra.music.MediaControl.seek((long) (t.durationMs() * (hx - barX) / barW)));

        int bx = px + pw - 8 - 3 * 28;
        ui.button(c, bx, y + 8, 24, "|<", false, () -> client.astra.music.MediaControl.previous(), mx, my);
        ui.button(c, bx + 28, y + 8, 24, t.playing() ? "||" : ">", true,
                () -> { if (t.playing()) client.astra.music.MediaControl.pause(); else client.astra.music.MediaControl.play(); }, mx, my);
        ui.button(c, bx + 56, y + 8, 24, ">|", false, () -> client.astra.music.MediaControl.next(), mx, my);
        return y + 52;
    }

    private void colorRow(GuiGraphicsExtractor c, int px, int y, int pw, String label, int current, java.util.function.IntConsumer set, int mx, int my) {
        AstraConfig cfg = AstraConfig.get();
        Draw.panel(c, px, y, pw, 22, Draw.BG_SOFT, Draw.BORDER);
        Draw.text(c, font, label, px + 8, y + 7, Draw.TEXT);
        int startX = px + pw - 8 - PALETTE.length * 12 + 2;
        for (int i = 0; i < PALETTE.length; i++) {
            int dx = startX + i * 12;
            int color = PALETTE[i];
            if (color == current) Draw.round(c, dx - 2, y + 5, 12, 12, 0xFFF5F3FF);
            Draw.round(c, dx, y + 7, 8, 8, 0xFF000000 | color);
            ui.hit(dx - 2, y + 4, 12, 14, () -> { set.accept(color); cfg.save(); });
        }
    }

    private String clip(String s, int maxW) {
        if (Draw.width(font, s) <= maxW) return s;
        while (s.length() > 1 && Draw.width(font, s + "..") > maxW) s = s.substring(0, s.length() - 1);
        return s + "..";
    }
}
