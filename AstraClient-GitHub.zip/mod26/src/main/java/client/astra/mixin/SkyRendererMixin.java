package client.astra.mixin;

import client.astra.sky.AstraSky;
import com.mojang.renderpearl.api.buffers.GpuBufferSlice;
import com.mojang.blaze3d.pipeline.RenderTarget;
import net.minecraft.client.renderer.SkyRenderer;
import net.minecraft.client.renderer.state.level.SkyRenderState;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(SkyRenderer.class)
public abstract class SkyRendererMixin {
    @Shadow
    private RenderTarget renderTarget;

    @Inject(method = "render", at = @At("HEAD"), cancellable = true)
    private void astra$sky(GpuBufferSlice skyFog, SkyRenderState state, CallbackInfo ci) {
        if (AstraSky.active()) {
            if (client.astra.sky.SkyGpu.render(this.renderTarget, skyFog)) ci.cancel();
        }
    }
}
