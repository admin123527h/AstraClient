package client.astra.mixin;

import client.astra.module.Zoom;
import net.minecraft.client.MouseHandler;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Scroll wheel changes the zoom level while zooming. The method has the same signature in 26.1, 26.2 and 26.3. */
@Mixin(MouseHandler.class)
public abstract class MouseHandlerMixin {
    @Inject(method = "onScroll", at = @At("HEAD"), cancellable = true)
    private void astra$zoomScroll(long window, double xOffset, double yOffset, CallbackInfo ci) {
        if (Zoom.scroll(yOffset)) ci.cancel();
    }
}
