package client.astra.mixin;

import client.astra.module.Zoom;
import net.minecraft.client.Camera;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/** Zoom: scales the field of view. The method exists unchanged in 26.1, 26.2 and 26.3. */
@Mixin(Camera.class)
public abstract class CameraMixin {
    @Inject(method = "calculateFov", at = @At("RETURN"), cancellable = true)
    private void astra$zoom(float partialTicks, CallbackInfoReturnable<Float> cir) {
        cir.setReturnValue(Zoom.apply(cir.getReturnValue()));
    }
}
