package client.astra.mixin;

import client.astra.sky.AstraSky;
import net.minecraft.client.Camera;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.renderer.fog.environment.AtmosphericFogEnvironment;
import org.joml.Vector3fc;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(AtmosphericFogEnvironment.class)
public abstract class FogColorMixin {
    @Inject(method = "getBaseColor", at = @At("RETURN"), cancellable = true)
    private void astra$fog(ClientLevel level, Camera camera, int renderDistance, float partialTicks, CallbackInfoReturnable<Vector3fc> cir) {
        if (AstraSky.active()) cir.setReturnValue(client.astra.sky.SkyGpu.fogColor());
    }
}
