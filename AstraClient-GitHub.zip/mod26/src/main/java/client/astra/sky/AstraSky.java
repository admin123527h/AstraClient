package client.astra.sky;

import client.astra.music.AstraConfig;
import net.minecraft.client.Minecraft;

import java.util.List;

public final class AstraSky {
    public static final List<String> NAMES = List.of(
            "Saturn", "Northern Lights", "Polar Lights", "Nebula", "Galaxy", "End Beams", "Underwater", "Meteor Shower",
            "Star Trails", "Sunset", "Thunderstorm", "Blood Moon", "Comet", "Solar Eclipse", "Neon Horizon", "Cherry Blossom");

    private static final boolean SUPPORTED = probe();

    private AstraSky() {}

    private static boolean probe() {
        return AstraSky.class.getClassLoader().getResource("com/mojang/renderpearl/api/pipeline/RenderPipeline$Snippet.class") != null;
    }

    /** The shader sky needs the 26.3 render API; older 26.x versions keep the vanilla sky. */
    public static boolean supported() { return SUPPORTED; }

    public static void init() {
        if (SUPPORTED) SkyGpu.init();
    }

    public static int activeId() {
        AstraConfig cfg = AstraConfig.get();
        return cfg.skyEnabled ? NAMES.indexOf(cfg.sky) : -1;
    }

    /** 0 high, 1 medium, 2 low: the FPS booster forces low while it is working. */
    public static float quality() {
        if (client.astra.module.Booster.level() >= 1) return 2f;
        String q = AstraConfig.get().skyQuality;
        return "Low".equals(q) ? 2f : "Medium".equals(q) ? 1f : 0f;
    }

    /** Set when the shader sky failed on this machine; the vanilla sky is used instead and the menu shows why. */
    private static volatile String failure = "";

    public static String failure() { return failure; }

    public static void fail(Throwable t) {
        failure = t.getClass().getSimpleName() + ": " + String.valueOf(t.getMessage());
        System.err.println("[astra] shader sky disabled: " + failure);
        t.printStackTrace();
    }

    public static boolean active() {
        return SUPPORTED && failure.isEmpty() && activeId() >= 0 && Minecraft.getInstance().level != null;
    }
}
