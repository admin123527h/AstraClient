package client.astra.sky;

import com.mojang.renderpearl.api.buffers.GpuBufferSlice;
import com.mojang.blaze3d.pipeline.RenderTarget;
import com.mojang.renderpearl.api.commands.RenderPass;
import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.renderpearl.api.pipeline.ColorTargetState;
import com.mojang.renderpearl.api.pipeline.PrimitiveTopology;
import com.mojang.renderpearl.api.pipeline.RenderPipeline;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.BindGroupLayouts;
import net.minecraft.client.renderer.RenderPipelines;
import net.minecraft.resources.Identifier;
import org.joml.Vector3f;
import org.joml.Vector4f;

import java.util.List;
import java.util.Optional;
import java.util.OptionalDouble;

/** Replaces the vanilla sky with a procedural shader sky: one draw call, all work on the GPU. */
public final class SkyGpu {
    /** Horizon colour of each sky, used as fog colour so distant land fades into the sky. */
    private static final int[] FOG = {
            0x1A1233, 0x140F36, 0x0A2220, 0x1E0B33, 0x0B0B22, 0x130A24, 0x0F5D70, 0x0C0C1E,
            0x0F1128, 0xF08A62, 0x2A2E3A, 0x4D0A0A, 0x0C1224, 0x1A1A38, 0xC02680, 0xF3B7D3};

    private static final long START = System.nanoTime();

    public static final RenderPipeline PIPELINE = RenderPipelines.register(
            RenderPipeline.builder()
                    .withBindGroupLayout(BindGroupLayouts.PROJECTION)
                    .withBindGroupLayout(BindGroupLayouts.DYNAMIC_TRANSFORMS)
                    .withLocation(Identifier.fromNamespaceAndPath("astra", "pipeline/sky"))
                    .withVertexShader(Identifier.fromNamespaceAndPath("astra", "core/astra_sky"))
                    .withFragmentShader(Identifier.fromNamespaceAndPath("astra", "core/astra_sky"))
                    .withCull(false)
                    .withColorTargetState(ColorTargetState.DEFAULT)
                    .withPrimitiveTopology(PrimitiveTopology.TRIANGLES)
                    .build());

    private SkyGpu() {}

    /** Touching the class registers the pipeline before the first frame. */
    public static void init() {}

    public static Vector3f fogColor() {
        int c = FOG[AstraSky.activeId()];
        return new Vector3f((c >> 16 & 255) / 255f, (c >> 8 & 255) / 255f, (c & 255) / 255f);
    }

    /** Draws the sky; false means it failed and the caller must let the vanilla sky draw instead. */
    public static boolean render(RenderTarget target, GpuBufferSlice skyFog) {
        try {
            draw(target, skyFog);
            return true;
        } catch (Throwable t) {
            AstraSky.fail(t);
            return false;
        }
    }

    private static void draw(RenderTarget target, GpuBufferSlice skyFog) {
        RenderSystem.setShaderFog(skyFog);
        long t = System.nanoTime() - START;
        float seconds = (t / 1_000_000_000L % 100000L) + (t % 1_000_000_000L) / 1e9f;
        GpuBufferSlice uniforms = RenderSystem.getDynamicUniforms()
                .writeTransform(RenderSystem.getModelViewMatrixCopy(), new Vector4f(AstraSky.activeId(), seconds, AstraSky.quality(), 0f));
        try (RenderPass pass = RenderSystem.getDevice().createCommandEncoder().createRenderPass(
                () -> "Astra sky", target.getColorTextureView(), Optional.empty(), target.getDepthTextureView(), OptionalDouble.empty())) {
            pass.setPipeline(RenderSystem.getCompiledPipeline(PIPELINE));
            RenderSystem.bindDefaultUniforms(pass);
            pass.setUniform("DynamicTransforms", uniforms);
            pass.draw(36, 1, 0, 0);
        }
    }
}
