package client.astra;

import client.astra.gui.GlassMenuScreen;
import client.astra.hud.HudRenderer;
import client.astra.lyrics.LyricsRenderer;
import client.astra.sky.AstraSky;
import com.mojang.blaze3d.platform.InputConstants;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keymapping.v1.KeyMappingHelper;
import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.hud.VanillaHudElements;
import net.fabricmc.fabric.api.client.rendering.v1.level.LevelRenderEvents;
import net.minecraft.client.KeyMapping;
import net.minecraft.resources.Identifier;

public class AstraClient implements ClientModInitializer {
    public static final String ID = "astra";

    private static final KeyMapping.Category CATEGORY = KeyMapping.Category.register(Identifier.fromNamespaceAndPath(ID, "main"));

    public static KeyMapping MENU, PREV, PLAY, NEXT;

    static KeyMapping key(String name, int code) {
        return KeyMappingHelper.registerKeyMapping(new KeyMapping(name, InputConstants.Type.KEYBOARD, code, CATEGORY));
    }

    @Override
    public void onInitializeClient() {
        AstraSky.init();
        client.astra.module.Modules.init(AstraClient::key);
        HudElementRegistry.attachElementAfter(VanillaHudElements.MISC_OVERLAYS, Identifier.fromNamespaceAndPath(ID, "hud"), HudRenderer::render);
        LevelRenderEvents.COLLECT_SUBMITS.register(LyricsRenderer::render);

        KeyMapping menuKey = MENU = key("key.astra.menu", InputConstants.KEY_RSHIFT);
        KeyMapping prevKey = PREV = key("key.astra.prev", InputConstants.KEY_F6);
        KeyMapping playKey = PLAY = key("key.astra.playpause", InputConstants.KEY_F7);
        KeyMapping nextKey = NEXT = key("key.astra.next", InputConstants.KEY_F9);

        int[] devTicks = {0};
        int[] skyTicks = {0};
        ClientTickEvents.END_CLIENT_TICK.register(mc -> {
            while (menuKey.consumeClick()) {
                if (mc.gui.screen() == null) mc.gui.setScreen(new GlassMenuScreen());
            }
            while (prevKey.consumeClick()) client.astra.music.MediaControl.previous();
            while (nextKey.consumeClick()) client.astra.music.MediaControl.next();
            while (playKey.consumeClick()) {
                boolean playing = Astra.music().current().map(client.astra.music.MusicProvider.Track::playing).orElse(false);
                if (playing) client.astra.music.MediaControl.pause(); else client.astra.music.MediaControl.play();
            }
            if (Astra.DEV && Boolean.getBoolean("astra.devSkyCycle") && mc.player != null && mc.level != null) {
                mc.player.setXRot(-18f);
                mc.player.setYRot(180f);
                if (++skyTicks[0] % 130 == 1) {
                    client.astra.music.AstraConfig.get().lyricsEnabled = false;
                    client.astra.music.AstraConfig.get().skyEnabled = true;
                    client.astra.music.AstraConfig.get().sky = AstraSky.NAMES.get((skyTicks[0] / 130) % 16);
                    System.out.println("[astra-sky] " + client.astra.music.AstraConfig.get().sky);
                }
            }
            if (Astra.DEV && Boolean.getBoolean("astra.devSpin") && mc.player != null) mc.player.setYRot(mc.player.getYRot() + 0.8f);
            if (Astra.DEV && mc.level != null && ++devTicks[0] == Integer.getInteger("astra.devMenuTicks", 600)) {
                mc.gui.setScreen(new GlassMenuScreen());
            }
        });
    }
}
