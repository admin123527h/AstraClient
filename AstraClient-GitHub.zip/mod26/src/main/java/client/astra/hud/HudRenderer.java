package client.astra.hud;

import client.astra.Astra;
import client.astra.lyrics.LyricsTimeline;
import client.astra.music.AstraConfig;
import client.astra.music.MusicProvider;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.multiplayer.PlayerInfo;
import net.minecraft.client.DeltaTracker;

import java.util.Optional;

public final class HudRenderer {
    private HudRenderer() {}

    public static void render(GuiGraphicsExtractor ctx, DeltaTracker tick) {
        Minecraft mc = Minecraft.getInstance();

        announce(ctx, mc);
        AstraConfig cfg = AstraConfig.get();
        String fps = mc.getFps() + " FPS";
        String ping = ping(mc);
        Optional<MusicProvider.Track> track = cfg.hudMusic ? Astra.music().current() : Optional.empty();

        int cx = ctx.guiWidth() / 2;
        int y = 6;
        int musicW = track.isPresent() ? 170 : 0;
        int fpsW = cfg.hudFps ? Draw.width(mc.font, fps) + 14 : 0;
        int pingW = cfg.hudPing ? Draw.width(mc.font, ping) + 14 : 0;
        int gap = 4;
        int[] widths = {fpsW, musicW, pingW};
        int count = 0, total = 0;
        for (int wd : widths) if (wd > 0) { total += wd; count++; }
        if (count == 0) return;
        total += gap * (count - 1);
        int x = cx - total / 2;

        if (fpsW > 0) { pill(ctx, mc, x, y, fpsW, fps); x += fpsW + gap; }
        if (musicW > 0) { musicPill(ctx, mc, x, y, musicW, track.get()); x += musicW + gap; }
        if (pingW > 0) pill(ctx, mc, x, y, pingW, ping);
    }


    private static String toastKey = "";
    private static long toastAt;

    /** A short "now playing" card when the song changes. */
    private static void announce(GuiGraphicsExtractor ctx, Minecraft mc) {
        AstraConfig cfg = AstraConfig.get();
        if (!cfg.announceSong) return;
        Optional<MusicProvider.Track> t = Astra.music().current();
        if (t.isEmpty() || !t.get().playing()) return;
        String key = t.get().artist() + "|" + t.get().title();
        long now = System.currentTimeMillis();
        if (!key.equals(toastKey)) {
            toastKey = key;
            toastAt = now;
        }
        long age = now - toastAt;
        if (age > 4500) return;
        float a = Math.min(1f, age / 300f) * Math.min(1f, (4500 - age) / 500f);
        if (a < 0.06f) return;
        String title = t.get().title();
        String artist = t.get().artist();
        int w = Math.max(Draw.width(mc.font, title), Draw.width(mc.font, artist)) + 44;
        int x = ctx.guiWidth() / 2 - w / 2, y = 28;
        Draw.panel(ctx, x, y, w, 30, ((int) (0x9C * a) << 24) | 0x1B1236, ((int) (0x70 * a) << 24) | 0xB9A6FF, 8f);
        ctx.fill(x + 8, y + 7, x + 11, y + 23, ((int) (255 * a) << 24) | 0xA78BFA);
        Draw.text(ctx, mc.font, title, x + 18, y + 6, ((int) (255 * a) << 24) | 0xEDE9FE);
        Draw.text(ctx, mc.font, artist, x + 18, y + 17, ((int) (255 * a) << 24) | 0xA79BCB);
    }

    private static String ping(Minecraft mc) {
        if (mc.player == null || mc.getConnection() == null) return "0 ms";
        PlayerInfo e = mc.getConnection().getPlayerInfo(mc.player.getUUID());
        return (e == null ? 0 : e.getLatency()) + " ms";
    }

    private static void pill(GuiGraphicsExtractor ctx, Minecraft mc, int x, int y, int w, String text) {
        Draw.panel(ctx, x, y, w, 16, Draw.BG, Draw.BORDER, 8f);
        Draw.text(ctx, mc.font, text, x + 7, y + 4, Draw.TEXT);
    }

    private static void musicPill(GuiGraphicsExtractor ctx, Minecraft mc, int x, int y, int w, MusicProvider.Track t) {
        Astra.LYRICS.ensure(t);
        Draw.panel(ctx, x, y, w, 16, Draw.BG, Draw.BORDER, 8f);
        int s = (int) (t.positionMs() / 1000);
        String clock = (s / 60) + ":" + String.format("%02d", s % 60);
        ctx.fill(x + 6, y + 5, x + 10, y + 11, t.playing() ? Draw.ACCENT : Draw.TEXT_DIM);
        Draw.text(ctx, mc.font, clock, x + 14, y + 4, Draw.TEXT_DIM);

        LyricsTimeline tl = Astra.LYRICS.timeline();
        int i = tl.indexAt(t.positionMs());
        String line = i >= 0 ? tl.line(i).text() : t.title() + " - " + t.artist();
        if (line.isEmpty()) line = t.title();
        int max = w - 14 - Draw.width(mc.font, clock) - 14;
        while (line.length() > 1 && Draw.width(mc.font, line) > max) line = line.substring(0, line.length() - 1);
        Draw.text(ctx, mc.font, line, x + 14 + Draw.width(mc.font, clock) + 6, y + 4, Draw.TEXT);
    }
}
