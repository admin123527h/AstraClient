package client.astra.hud;

import net.minecraft.network.chat.Style;
import net.minecraft.network.chat.FontDescription;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.Identifier;

import java.util.List;
import java.util.Map;

public final class Fonts {
    public static final String DEFAULT = "Poppins";
    public static final List<String> NAMES = List.of(
            "Poppins", "Poppins Italic", "Serif", "Abril", "Pacifico", "Brush", "Bangers", "Luckiest", "Lilita", "Minecraft");

    private static final Map<String, String> IDS = Map.of(
            "Poppins", "poppins", "Poppins Italic", "poppins_italic", "Serif", "serif", "Abril", "abril",
            "Pacifico", "pacifico", "Brush", "brush", "Bangers", "bangers", "Luckiest", "luckiest", "Lilita", "lilita");

    public static final Style POPPINS = style(DEFAULT);

    private Fonts() {}

    public static Style style(String name) {
        String id = IDS.get(name);
        if (id == null) return Style.EMPTY;
        return Style.EMPTY.withFont(new FontDescription.Resource(Identifier.fromNamespaceAndPath("astra", id)));
    }

    public static Component of(String s) {
        return of(s, DEFAULT);
    }

    public static Component of(String s, String font) {
        return Component.literal(s).setStyle(style(font));
    }
}
