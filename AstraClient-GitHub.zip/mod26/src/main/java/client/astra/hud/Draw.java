package client.astra.hud;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphicsExtractor;

import java.util.HashMap;
import java.util.Map;

/**
 * Glass-style drawing helpers. Shapes are laid out at device resolution so corners stay smooth at any GUI scale,
 * but corner rows with the same inset are merged and the straight body is one gradient fill, so a panel costs
 * around 40 draw calls instead of several hundred.
 */
public final class Draw {
    public static final int BG = 0x9C1B1236;
    public static final int BG_SOFT = 0x7A2A1D4D;
    public static final int BORDER = 0x70B9A6FF;
    public static final int ACCENT = 0xFFA78BFA;
    public static final int ACCENT_DIM = 0x66A78BFA;
    public static final int TEXT = 0xFFEDE9FE;
    public static final int TEXT_DIM = 0xFFA79BCB;

    private static final int WHITE = 0xFFFFFF;
    private static final int DEEP = 0x0A0614;

    /** Rows [start, end) of one corner that share the same horizontal inset. */
    private record Group(int start, int end, int inset) {}

    private static final Map<Integer, Group[]> CORNERS = new HashMap<>();

    public static int fills;

    private Draw() {}

    private static void fill(GuiGraphicsExtractor c, int x1, int y1, int x2, int y2, int color) {
        if (x2 <= x1 || y2 <= y1) return;
        fills++;
        c.fill(x1, y1, x2, y2, color);
    }

    private static void fillGradient(GuiGraphicsExtractor c, int x1, int y1, int x2, int y2, int top, int bottom) {
        if (x2 <= x1 || y2 <= y1) return;
        fills++;
        c.fillGradient(x1, y1, x2, y2, top, bottom);
    }

    public static void text(GuiGraphicsExtractor c, Font f, String s, int x, int y, int color) {
        c.text(f, Fonts.of(s), x, y, color, false);
    }

    public static void text(GuiGraphicsExtractor c, Font f, String s, int x, int y, int color, String font) {
        c.text(f, Fonts.of(s, font), x, y, color, false);
    }

    public static int width(Font f, String s, String font) {
        return f.width(Fonts.of(s, font));
    }

    public static int width(Font f, String s) {
        return f.width(Fonts.of(s));
    }

    // ---- public shapes ----

    /** Flat rounded rectangle. */
    public static void round(GuiGraphicsExtractor c, int x, int y, int w, int h, int color) {
        gradient(c, x, y, w, h, color, color, Math.min(h / 2f, 4f));
    }

    /** Glass panel: vertical gradient, bright top edge, soft border. */
    public static void panel(GuiGraphicsExtractor c, int x, int y, int w, int h, int fill, int border) {
        panel(c, x, y, w, h, fill, border, Math.min(h / 2f, 4f));
    }

    public static void panel(GuiGraphicsExtractor c, int x, int y, int w, int h, int fill, int border, float radius) {
        gradient(c, x, y, w, h, mix(fill, WHITE, 0.12f), mix(fill, DEEP, 0.22f), radius);
        ring(c, x, y, w, h, mix(border, WHITE, 0.45f), mix(border, DEEP, 0.25f), radius);
    }

    /** Large floating window: soft shadow plus glass panel. */
    public static void window(GuiGraphicsExtractor c, int x, int y, int w, int h, int fill, int border, float radius) {
        for (int g = 3; g >= 1; g -= 2) {
            gradient(c, x - g, y - g + 1, w + g * 2, h + g * 2, 0x1A14081F, 0x1A14081F, radius + g);
        }
        panel(c, x, y, w, h, fill, border, radius);
    }

    // ---- layout ----

    private static Group[] corner(int radius) {
        return CORNERS.computeIfAbsent(radius, r -> {
            java.util.List<Group> out = new java.util.ArrayList<>();
            int start = 0, current = -1;
            for (int row = 0; row <= r; row++) {
                int inset = row == r ? -2 : insetFor(row, r);
                if (row > 0 && inset != current) {
                    out.add(new Group(start, row, current));
                    start = row;
                }
                current = inset;
            }
            return out.toArray(new Group[0]);
        });
    }

    private static int insetFor(int row, int r) {
        double dy = r - row - 0.5;
        return (int) Math.round(r - Math.sqrt(Math.max(0, (double) r * r - dy * dy)));
    }

    private interface Layout {
        void run(GuiGraphicsExtractor c, int X, int Y, int W, int H, int R);
    }

    private static void device(GuiGraphicsExtractor c, int x, int y, int w, int h, float radius, Layout layout) {
        double s = Minecraft.getInstance().getWindow().getGuiScale();
        int X = (int) Math.round(x * s), Y = (int) Math.round(y * s);
        int W = (int) Math.round(w * s), H = (int) Math.round(h * s);
        if (W < 2 || H < 2) return;
        int R = Math.max(1, Math.min(Math.round((float) (radius * s)), Math.min(W, H) / 2));

        var m = c.pose();
        m.pushMatrix();
        m.scale((float) (1 / s), (float) (1 / s));
        layout.run(c, X, Y, W, H, R);
        m.popMatrix();
    }

    // ---- rasterisation ----

    /** Corner pieces are small textures (one blit each) instead of many one-pixel rows: far fewer draw elements per panel. */
    private static final java.util.Map<Long, net.minecraft.resources.Identifier> CORNER_TEX = new HashMap<>();

    /** A 2R x 2R white disc (thickness 0) or ring, anti-aliased; its four quadrants are the four corners. */
    private static net.minecraft.resources.Identifier cornerTexture(int radius, int thickness) {
        long key = ((long) radius << 32) | thickness;
        var cached = CORNER_TEX.get(key);
        if (cached != null) return cached;
        int size = radius * 2;
        var texture = new net.minecraft.client.renderer.texture.DynamicTexture("astra corner " + radius + "/" + thickness, size, size, true);
        var image = texture.getPixels();
        for (int py = 0; py < size; py++) {
            for (int px = 0; px < size; px++) {
                double d = Math.hypot(px + 0.5 - radius, py + 0.5 - radius);
                double outer = Math.max(0, Math.min(1, radius - d + 0.5));
                double a = thickness <= 0 ? outer : outer - Math.max(0, Math.min(1, radius - thickness - d + 0.5));
                int alpha = (int) Math.round(Math.max(0, Math.min(1, a)) * 255);
                image.setPixelABGR(px, py, (alpha << 24) | 0xFFFFFF);
            }
        }
        texture.upload();
        var id = net.minecraft.resources.Identifier.fromNamespaceAndPath("astra", "draw/corner_" + radius + "_" + thickness);
        Minecraft.getInstance().getTextureManager().register(id, texture);
        CORNER_TEX.put(key, id);
        return id;
    }

    private static void corners(GuiGraphicsExtractor ctx, int X, int Y, int W, int H, int R, int thickness, int topColor, int bottomColor) {
        var id = cornerTexture(R, thickness);
        int size = R * 2;
        var pipe = net.minecraft.client.renderer.RenderPipelines.GUI_TEXTURED;
        fills += 4;
        ctx.blit(pipe, id, X, Y, 0f, 0f, R, R, size, size, topColor);
        ctx.blit(pipe, id, X + W - R, Y, (float) R, 0f, R, R, size, size, topColor);
        ctx.blit(pipe, id, X, Y + H - R, 0f, (float) R, R, R, size, size, bottomColor);
        ctx.blit(pipe, id, X + W - R, Y + H - R, (float) R, (float) R, R, R, size, size, bottomColor);
    }

    public static void gradient(GuiGraphicsExtractor c, int x, int y, int w, int h, int top, int bottom, float radius) {
        device(c, x, y, w, h, radius, (ctx, X, Y, W, H, R) -> {
            int topEdge = lerp(top, bottom, (float) R / 2f / H);
            int bottomEdge = lerp(top, bottom, 1f - (float) R / 2f / H);
            corners(ctx, X, Y, W, H, R, 0, topEdge, bottomEdge);
            fill(ctx, X + R, Y, X + W - R, Y + R, topEdge);
            fill(ctx, X + R, Y + H - R, X + W - R, Y + H, bottomEdge);
            fillGradient(ctx, X, Y + R, X + W, Y + H - R, lerp(top, bottom, (float) R / H), lerp(top, bottom, 1f - (float) R / H));
        });
    }

    /** Thin outline following the rounded shape. */
    public static void ring(GuiGraphicsExtractor c, int x, int y, int w, int h, int top, int bottom, float radius) {
        device(c, x, y, w, h, radius, (ctx, X, Y, W, H, R) -> {
            int T = Math.max(1, Math.round((float) (Minecraft.getInstance().getWindow().getGuiScale() * 0.5)));
            T = Math.min(T, R);
            int topEdge = lerp(top, bottom, (float) R / 2f / H);
            int bottomEdge = lerp(top, bottom, 1f - (float) R / 2f / H);
            corners(ctx, X, Y, W, H, R, T, topEdge, bottomEdge);
            fill(ctx, X + R, Y, X + W - R, Y + T, top);
            fill(ctx, X + R, Y + H - T, X + W - R, Y + H, bottom);
            int sideTop = lerp(top, bottom, (float) R / H), sideBottom = lerp(top, bottom, 1f - (float) R / H);
            fillGradient(ctx, X, Y + R, X + T, Y + H - R, sideTop, sideBottom);
            fillGradient(ctx, X + W - T, Y + R, X + W, Y + H - R, sideTop, sideBottom);
        });
    }

    // ---- colour maths ----

    public static int mix(int argb, int rgb, float t) {
        int a = argb >>> 24;
        int r = blend((argb >> 16) & 0xFF, (rgb >> 16) & 0xFF, t);
        int g = blend((argb >> 8) & 0xFF, (rgb >> 8) & 0xFF, t);
        int b = blend(argb & 0xFF, rgb & 0xFF, t);
        return (a << 24) | (r << 16) | (g << 8) | b;
    }

    private static int blend(int a, int b, float t) {
        return Math.round(a + (b - a) * t);
    }

    private static int lerp(int c1, int c2, float t) {
        int a = blend(c1 >>> 24, c2 >>> 24, t);
        int r = blend((c1 >> 16) & 0xFF, (c2 >> 16) & 0xFF, t);
        int g = blend((c1 >> 8) & 0xFF, (c2 >> 8) & 0xFF, t);
        int b = blend(c1 & 0xFF, c2 & 0xFF, t);
        return (a << 24) | (r << 16) | (g << 8) | b;
    }
}
