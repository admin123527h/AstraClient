package client.astra.music;

import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.sun.net.httpserver.HttpServer;
import com.mojang.blaze3d.Blaze3D;
import net.minecraft.client.Minecraft;

import java.io.IOException;
import java.net.BindException;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.URI;
import java.net.URLDecoder;
import java.net.URLEncoder;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.SecureRandom;
import java.util.Base64;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;

/** Spotify Authorization Code flow with PKCE (no client secret needed). */
public final class SpotifyAuth {
    public static final int PORT = 8888;
    public static final String REDIRECT = "http://127.0.0.1:" + PORT + "/callback";
    private static final int SCOPE_VERSION = 2;
    private static final String SCOPE = "user-read-currently-playing user-read-playback-state user-modify-playback-state"
            + " playlist-read-private playlist-read-collaborative user-library-read";
    private static final HttpClient HTTP = HttpClient.newHttpClient();

    private volatile String accessToken;
    private volatile long expiresAtMs;
    private volatile String lastError = "";

    public String lastError() { return lastError; }

    public synchronized String accessToken() {
        AstraConfig cfg = AstraConfig.get();
        if (accessToken != null && System.currentTimeMillis() < expiresAtMs - 30_000) return accessToken;
        if (!loggedIn() || cfg.clientId().isEmpty()) return null;
        try {
            store(post("grant_type=refresh_token&refresh_token=" + enc(cfg.spotifyRefreshToken)
                    + "&client_id=" + enc(cfg.clientId())));
            lastError = "";
        } catch (Exception e) {
            lastError = e.getMessage();
            return null;
        }
        return accessToken;
    }

    public boolean loggedIn() {
        AstraConfig cfg = AstraConfig.get();
        return !cfg.spotifyRefreshToken.isEmpty() && cfg.spotifyScopeVersion == SCOPE_VERSION;
    }

    public static boolean looksLikeClientId(String id) {
        return id != null && id.matches("[0-9a-fA-F]{32}");
    }

    /** Opens the browser, waits for the redirect and stores the refresh token. Resolves to null on success, else a message. */
    public CompletableFuture<String> login() {
        return CompletableFuture.supplyAsync(() -> {
            AstraConfig cfg = AstraConfig.get();
            String clientId = cfg.clientId();
            if (clientId.isEmpty()) return "Enter your Spotify Client ID in Settings first.";
            if (!looksLikeClientId(clientId)) {
                return "That is not a Spotify Client ID. It has 32 letters and digits (the Azure ID from the launcher has dashes).";
            }
            HttpServer server = null;
            try {
                byte[] raw = new byte[48];
                new SecureRandom().nextBytes(raw);
                String verifier = Base64.getUrlEncoder().withoutPadding().encodeToString(raw);
                String challenge = Base64.getUrlEncoder().withoutPadding().encodeToString(
                        MessageDigest.getInstance("SHA-256").digest(verifier.getBytes(StandardCharsets.US_ASCII)));

                CompletableFuture<String> code = new CompletableFuture<>();
                try {
                    server = HttpServer.create(new InetSocketAddress(InetAddress.getLoopbackAddress(), PORT), 0);
                } catch (BindException e) {
                    return "Port " + PORT + " is already in use. Close the program that uses it and try again.";
                }
                server.createContext("/callback", ex -> {
                    Map<String, String> q = query(ex.getRequestURI().getRawQuery());
                    boolean ok = q.containsKey("code");
                    String message = ok ? "Spotify connected. You can close this window."
                            : "Spotify refused the login: " + q.getOrDefault("error_description", q.getOrDefault("error", "no code received"));
                    byte[] body = ("<html><body style='background:#120d22;color:#ede9fe;font-family:sans-serif;text-align:center;padding-top:20vh'>"
                            + "<h1>Astra Client</h1><p>" + escape(message) + "</p></body></html>").getBytes(StandardCharsets.UTF_8);
                    ex.getResponseHeaders().add("Content-Type", "text/html; charset=utf-8");
                    ex.sendResponseHeaders(200, body.length);
                    ex.getResponseBody().write(body);
                    ex.close();
                    if (ok) code.complete(q.get("code"));
                    else code.completeExceptionally(new IllegalStateException(message));
                });
                server.start();

                String url = "https://accounts.spotify.com/authorize?response_type=code&client_id=" + enc(clientId)
                        + "&redirect_uri=" + enc(REDIRECT) + "&scope=" + enc(SCOPE)
                        + "&code_challenge_method=S256&code_challenge=" + challenge;
                openBrowser(url);

                String authCode = code.get(3, TimeUnit.MINUTES);
                store(post("grant_type=authorization_code&code=" + enc(authCode) + "&redirect_uri=" + enc(REDIRECT)
                        + "&client_id=" + enc(clientId) + "&code_verifier=" + verifier));
                lastError = "";
                return null;
            } catch (TimeoutException e) {
                return "No answer from the browser after 3 minutes. Click Connect Spotify and try again.";
            } catch (java.util.concurrent.ExecutionException e) {
                return e.getCause() == null ? String.valueOf(e) : e.getCause().getMessage();
            } catch (Exception e) {
                return e.getMessage() == null ? e.toString() : e.getMessage();
            } finally {
                if (server != null) server.stop(0);
            }
        });
    }

    /** Minecraft runs Java in headless mode, so java.awt.Desktop does not work; its own opener does. */
    private static void openBrowser(String url) {
        Minecraft mc = Minecraft.getInstance();
        mc.execute(() -> mc.keyboardHandler.setClipboard(url));
        Blaze3D.openUri(URI.create(url));
    }

    private void store(JsonObject r) {
        accessToken = r.get("access_token").getAsString();
        expiresAtMs = System.currentTimeMillis() + r.get("expires_in").getAsLong() * 1000;
        if (r.has("refresh_token")) {
            AstraConfig cfg = AstraConfig.get();
            cfg.spotifyRefreshToken = r.get("refresh_token").getAsString();
            cfg.spotifyScopeVersion = SCOPE_VERSION;
            cfg.save();
        }
    }

    private static JsonObject post(String form) throws IOException, InterruptedException {
        HttpRequest req = HttpRequest.newBuilder(URI.create("https://accounts.spotify.com/api/token"))
                .header("Content-Type", "application/x-www-form-urlencoded")
                .POST(HttpRequest.BodyPublishers.ofString(form)).build();
        HttpResponse<String> res;
        try {
            res = HTTP.send(req, HttpResponse.BodyHandlers.ofString());
        } catch (IOException e) {
            throw new IOException("Could not reach Spotify. Check your internet connection or firewall. (" + e.getMessage() + ")");
        }
        if (res.statusCode() != 200) {
            String detail = "";
            try {
                JsonObject o = JsonParser.parseString(res.body()).getAsJsonObject();
                detail = o.has("error_description") ? o.get("error_description").getAsString()
                        : o.has("error") ? o.get("error").getAsString() : "";
            } catch (RuntimeException ignored) {
            }
            throw new IOException("Spotify refused the token request (HTTP " + res.statusCode() + (detail.isEmpty() ? "" : ": " + detail) + ")");
        }
        return JsonParser.parseString(res.body()).getAsJsonObject();
    }

    private static Map<String, String> query(String raw) {
        Map<String, String> out = new HashMap<>();
        if (raw == null) return out;
        for (String pair : raw.split("&")) {
            int eq = pair.indexOf('=');
            if (eq > 0) out.put(URLDecoder.decode(pair.substring(0, eq), StandardCharsets.UTF_8), URLDecoder.decode(pair.substring(eq + 1), StandardCharsets.UTF_8));
        }
        return out;
    }

    private static String escape(String s) {
        return s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;");
    }

    private static String enc(String s) {
        return URLEncoder.encode(s, StandardCharsets.UTF_8);
    }
}
