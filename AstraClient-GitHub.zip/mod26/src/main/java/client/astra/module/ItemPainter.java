package client.astra.module;

import com.mojang.blaze3d.platform.NativeImage;

import java.util.ArrayList;
import java.util.List;

/**
 * Repaints a texture with a design instead of just shifting its colours. The silhouette and the light/dark relief of the
 * original are kept (so every model still looks right), but the surface is new: crystal facets, glowing lava cracks or
 * runed metal, with the design's own outline, glow and floating sparks.
 */
public final class ItemPainter {
    public enum Style { CRYSTAL, EMBER, RUNIC }

    public record Design(String name, Style style, int outline, int dark, int mid, int light, int accent) {}

    private ItemPainter() {}

    public static NativeImage paint(NativeImage src, Design d, String seedText) {
        int w = src.getWidth(), h = src.getHeight();
        boolean sprite = w <= 32 && h <= 32;
        int seed = seedText.hashCode() * 31 + d.name().hashCode();

        int[] argb = new int[w * h];
        boolean[] opaque = new boolean[w * h];
        double lo = 1, hi = 0;
        int count = 0;
        for (int y = 0; y < h; y++) {
            for (int x = 0; x < w; x++) {
                int px = src.getPixel(x, y);
                argb[y * w + x] = px;
                if ((px >>> 24) >= 20) {
                    opaque[y * w + x] = true;
                    count++;
                    double l = luma(px);
                    lo = Math.min(lo, l);
                    hi = Math.max(hi, l);
                }
            }
        }
        double span = Math.max(0.08, hi - lo);

        // distance from the outside (inside the shape) and from the shape (outside it), capped small
        int[] depth = distance(opaque, w, h, true);
        int[] outside = distance(opaque, w, h, false);

        // seeds for crystal facets
        List<int[]> seeds = new ArrayList<>();
        if (d.style() == Style.CRYSTAL) {
            int n = Math.max(3, count / (sprite ? 13 : 70));
            List<int[]> pool = new ArrayList<>();
            for (int y = 0; y < h; y++) for (int x = 0; x < w; x++) if (opaque[y * w + x]) pool.add(new int[] {x, y});
            for (int i = 0; i < n && !pool.isEmpty(); i++) seeds.add(pool.get(Math.floorMod(hash(seed, i, 7, 3), pool.size())));
        }
        int[] cell = new int[w * h];
        if (!seeds.isEmpty()) {
            for (int y = 0; y < h; y++) {
                for (int x = 0; x < w; x++) {
                    int best = 0;
                    long bestD = Long.MAX_VALUE;
                    for (int i = 0; i < seeds.size(); i++) {
                        long dx = x - seeds.get(i)[0], dy = y - seeds.get(i)[1];
                        long dist = dx * dx + dy * dy;
                        if (dist < bestD) { bestD = dist; best = i; }
                    }
                    cell[y * w + x] = best;
                }
            }
        }

        NativeImage out = new NativeImage(w, h, false);
        for (int y = 0; y < h; y++) {
            for (int x = 0; x < w; x++) {
                int i = y * w + x;
                if (!opaque[i]) {
                    // floating embers just outside the silhouette
                    if (sprite && d.style() == Style.EMBER && outside[i] >= 1 && outside[i] <= 2 && Math.floorMod(hash(seed, x, y, 11), 26) == 0) {
                        out.setPixel(x, y, 0xFF000000 | ((x + y) % 2 == 0 ? d.accent() : d.light()));
                    } else {
                        out.setPixel(x, y, 0);
                    }
                    continue;
                }
                double rel = Math.max(0, Math.min(1, (luma(argb[i]) - lo) / span));
                double shade = 0.78 + 0.44 * rel;
                boolean edge = depth[i] == 1;
                int rgb;
                switch (d.style()) {
                    case CRYSTAL -> {
                        int c = cell[i];
                        int[] pal = {d.dark(), d.mid(), d.mid(), d.light()};
                        rgb = scale(pal[Math.floorMod(hash(seed, seeds.get(c)[0], seeds.get(c)[1], 5), 4)], shade);
                        boolean border = (x + 1 < w && cell[i + 1] != c) || (y + 1 < h && cell[i + w] != c);
                        if (border) rgb = mix(rgb, d.light(), 0.38);
                        if (x == seeds.get(c)[0] && y == seeds.get(c)[1] && Math.floorMod(hash(seed, x, y, 9), 3) == 0) rgb = d.accent();
                    }
                    case EMBER -> {
                        double n = noise(seed, x / (sprite ? 2.2 : 5.0), y / (sprite ? 2.2 : 5.0));
                        rgb = scale(mix(d.dark(), d.mid(), n), shade);
                        double crack = noise(seed + 77, x / (sprite ? 1.7 : 4.0), y / (sprite ? 1.7 : 4.0));
                        if (Math.abs(crack - 0.5) < (sprite ? 0.075 : 0.05)) rgb = mix(d.light(), d.accent(), rel);
                        if (depth[i] == 2 && Math.floorMod(hash(seed, x, y, 4), 3) == 0) rgb = mix(rgb, d.mid(), 0.7);
                    }
                    default -> {
                        int band = ((x * 2 + y) % 8) / 2;
                        int[] pal = {d.dark(), d.mid(), d.light(), d.mid()};
                        rgb = scale(pal[band], shade);
                        if (depth[i] == 2) rgb = mix(rgb, d.accent(), 0.55);
                        if (depth[i] >= 3 && Math.floorMod(x * 5 + y * 3, 13) == 0) rgb = d.accent();
                        else if (depth[i] >= 3 && Math.floorMod(x + y * 7, 17) == 0) rgb = d.light();
                    }
                }
                if (edge) rgb = mix(d.outline(), rgb, 0.12);
                out.setPixel(x, y, (argb[i] & 0xFF000000) | rgb);
            }
        }
        return out;
    }

    // ---- helpers ----

    /** Chebyshev-free 4-neighbour distance: inside = steps from outside (1 on the border), else steps to the shape. */
    private static int[] distance(boolean[] opaque, int w, int h, boolean inside) {
        int[] dist = new int[w * h];
        java.util.ArrayDeque<int[]> q = new java.util.ArrayDeque<>();
        for (int y = 0; y < h; y++) {
            for (int x = 0; x < w; x++) {
                int i = y * w + x;
                boolean mine = opaque[i] == inside;
                if (!mine) continue;
                boolean border = x == 0 || y == 0 || x == w - 1 || y == h - 1
                        || opaque[i - 1 < 0 ? i : i - 1] != inside && x > 0 || x + 1 < w && opaque[i + 1] != inside
                        || y > 0 && opaque[i - w] != inside || y + 1 < h && opaque[i + w] != inside;
                if (inside) {
                    if (border && (x == 0 || y == 0 || x == w - 1 || y == h - 1 || neighborOutside(opaque, w, h, x, y))) {
                        dist[i] = 1;
                        q.add(new int[] {x, y});
                    }
                } else if (neighborOpaque(opaque, w, h, x, y)) {
                    dist[i] = 1;
                    q.add(new int[] {x, y});
                }
            }
        }
        int[] dx = {1, -1, 0, 0}, dy = {0, 0, 1, -1};
        while (!q.isEmpty()) {
            int[] p = q.poll();
            int cur = dist[p[1] * w + p[0]];
            if (cur >= 6) continue;
            for (int k = 0; k < 4; k++) {
                int nx = p[0] + dx[k], ny = p[1] + dy[k];
                if (nx < 0 || ny < 0 || nx >= w || ny >= h) continue;
                int ni = ny * w + nx;
                if (opaque[ni] != inside || dist[ni] != 0) continue;
                dist[ni] = cur + 1;
                q.add(new int[] {nx, ny});
            }
        }
        for (int i = 0; i < dist.length; i++) if (dist[i] == 0 && opaque[i] == inside) dist[i] = 7;
        return dist;
    }

    private static boolean neighborOutside(boolean[] o, int w, int h, int x, int y) {
        return x > 0 && !o[y * w + x - 1] || x + 1 < w && !o[y * w + x + 1] || y > 0 && !o[(y - 1) * w + x] || y + 1 < h && !o[(y + 1) * w + x];
    }

    private static boolean neighborOpaque(boolean[] o, int w, int h, int x, int y) {
        return x > 0 && o[y * w + x - 1] || x + 1 < w && o[y * w + x + 1] || y > 0 && o[(y - 1) * w + x] || y + 1 < h && o[(y + 1) * w + x];
    }

    private static double luma(int argb) {
        int r = (argb >> 16) & 255, g = (argb >> 8) & 255, b = argb & 255;
        return (0.299 * r + 0.587 * g + 0.114 * b) / 255.0;
    }

    private static int scale(int rgb, double k) {
        int r = (int) Math.max(0, Math.min(255, ((rgb >> 16) & 255) * k));
        int g = (int) Math.max(0, Math.min(255, ((rgb >> 8) & 255) * k));
        int b = (int) Math.max(0, Math.min(255, (rgb & 255) * k));
        return (r << 16) | (g << 8) | b;
    }

    private static int mix(int a, int b, double t) {
        int r = (int) Math.round(((a >> 16) & 255) + (((b >> 16) & 255) - ((a >> 16) & 255)) * t);
        int g = (int) Math.round(((a >> 8) & 255) + (((b >> 8) & 255) - ((a >> 8) & 255)) * t);
        int bl = (int) Math.round((a & 255) + ((b & 255) - (a & 255)) * t);
        return (r << 16) | (g << 8) | bl;
    }

    private static int hash(int seed, int a, int b, int c) {
        int h = seed * 0x9E3779B1 + a * 0x85EBCA6B + b * 0xC2B2AE35 + c * 0x27D4EB2F;
        h ^= h >>> 15;
        h *= 0x2C1B3C6D;
        h ^= h >>> 12;
        h *= 0x297A2D39;
        h ^= h >>> 15;
        return h;
    }

    /** Smooth value noise in 0..1. */
    private static double noise(int seed, double x, double y) {
        int x0 = (int) Math.floor(x), y0 = (int) Math.floor(y);
        double fx = x - x0, fy = y - y0;
        fx = fx * fx * (3 - 2 * fx);
        fy = fy * fy * (3 - 2 * fy);
        double a = (hash(seed, x0, y0, 1) & 0xFFFF) / 65535.0, b = (hash(seed, x0 + 1, y0, 1) & 0xFFFF) / 65535.0;
        double c = (hash(seed, x0, y0 + 1, 1) & 0xFFFF) / 65535.0, e = (hash(seed, x0 + 1, y0 + 1, 1) & 0xFFFF) / 65535.0;
        return (a + (b - a) * fx) * (1 - fy) + (c + (e - c) * fx) * fy;
    }
}
