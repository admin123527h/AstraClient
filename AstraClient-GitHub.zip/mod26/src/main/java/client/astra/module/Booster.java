package client.astra.module;

import client.astra.music.AstraConfig;
import net.minecraft.client.CloudStatus;
import net.minecraft.client.Minecraft;
import net.minecraft.client.Options;
import net.minecraft.server.level.ParticleStatus;

/**
 * FPS booster: lowers Minecraft's own video settings step by step, live, and raises them again when there is room.
 * It works from a baseline (the player's own settings) and puts everything back when switched off or on exit.
 */
public final class Booster {
    private static BoosterPlan.Settings base;
    private static int level;
    private static int slow;
    private static int fast;
    private static int ticks;

    private Booster() {}

    public static int level() { return level; }

    public static BoosterPlan.Settings baseline() { return base; }

    public static boolean active() { return level > 0; }

    private static BoosterPlan.Settings read(Options o) {
        return new BoosterPlan.Settings(o.renderDistance().get(), o.simulationDistance().get(), o.entityDistanceScaling().get(),
                o.cloudStatus().get() != CloudStatus.OFF, o.particles().get() != ParticleStatus.ALL, o.biomeBlendRadius().get(),
                AstraConfig.get().skyQuality);
    }

    /** Jumps straight to a level (the preset buttons use this). */
    public static void setLevel(int wanted) {
        Options o = Minecraft.getInstance().options;
        if (level == 0 && wanted > 0) base = read(o);
        if (base == null) return;
        int next = Math.max(0, Math.min(BoosterPlan.MAX_LEVEL, wanted));
        BoosterPlan.Settings s = BoosterPlan.at(next, base);
        o.renderDistance().set(s.renderDistance());
        o.simulationDistance().set(s.simulationDistance());
        o.entityDistanceScaling().set(s.entityDistance());
        o.cloudStatus().set(s.clouds() ? (base.clouds() ? o.cloudStatus().get() : CloudStatus.FAST) : CloudStatus.OFF);
        o.particles().set(s.minimalParticles() ? ParticleStatus.MINIMAL : ParticleStatus.ALL);
        o.biomeBlendRadius().set(s.biomeBlend());
        level = next;
        if (level == 0) base = null;
    }

    /** Puts the player's own settings back (also called when the game closes, so they are never saved lowered). */
    public static void restore() {
        if (level > 0) setLevel(0);
    }

    /** Called every client tick; only does something while the adaptive mode is on. */
    public static void tick(Minecraft mc) {
        AstraConfig cfg = AstraConfig.get();
        if (!cfg.boosterAdaptive) return;
        if (mc.level == null || mc.gui.screen() != null || ++ticks % 40 != 0) return;
        int fps = mc.getFps();
        int target = Math.max(20, cfg.boosterTarget);
        if (fps < target * 0.92) {
            fast = 0;
            if (++slow >= 2 && level < BoosterPlan.MAX_LEVEL) {
                setLevel(level + 1);
                slow = 0;
            }
        } else if (fps > target * 1.6) {
            slow = 0;
            if (++fast >= 5 && level > 0) {
                setLevel(level - 1);
                fast = 0;
            }
        } else {
            slow = 0;
            fast = 0;
        }
    }
}
