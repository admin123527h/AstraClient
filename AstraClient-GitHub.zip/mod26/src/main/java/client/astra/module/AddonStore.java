package client.astra.module;

import client.astra.addons.Addons;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.Minecraft;

import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/** The in-game side of the add-on manager: one shared Addons instance, background installs and a "restart needed" flag. */
public final class AddonStore {
    private static Addons addons;
    private static final Map<String, String> MESSAGES = new ConcurrentHashMap<>();
    private static final Map<String, Boolean> BUSY = new ConcurrentHashMap<>();
    private static volatile boolean restartNeeded;

    private AddonStore() {}

    public static synchronized Addons get() {
        if (addons == null) {
            String mc = FabricLoader.getInstance().getModContainer("minecraft")
                    .map(c -> c.getMetadata().getVersion().getFriendlyString()).orElse("unknown");
            addons = new Addons(FabricLoader.getInstance().getGameDir(), mc);
        }
        return addons;
    }

    public static boolean restartNeeded() { return restartNeeded; }

    public static String message(Addons.Entry e) { return MESSAGES.getOrDefault(e.slug(), ""); }

    public static boolean busy(Addons.Entry e) { return BUSY.containsKey(e.slug()); }

    public static void toggle(Addons.Entry e) {
        Addons a = get();
        boolean on = !a.enabled(e);
        a.setEnabled(e, on);
        if (e.kind() == Addons.Kind.PACK) {
            if (on && a.status(e) == Addons.State.NOT_INSTALLED) install(e);
            else applyPack(e);
        } else {
            restartNeeded = true;
            if (on && a.status(e) == Addons.State.NOT_INSTALLED) install(e);
        }
    }

    /** Downloads (or updates) one entry on a background thread. */
    public static void install(Addons.Entry e) {
        if (BUSY.putIfAbsent(e.slug(), true) != null) return;
        MESSAGES.put(e.slug(), "Downloading...");
        Thread t = new Thread(() -> {
            String problem = get().install(e, line -> MESSAGES.put(e.slug(), line));
            MESSAGES.put(e.slug(), problem == null ? "Ready" : problem);
            if (problem == null) {
                if (e.kind() == Addons.Kind.MOD) restartNeeded = true;
                else Minecraft.getInstance().execute(() -> applyPack(e));
            }
            BUSY.remove(e.slug());
        }, "astra-addon-" + e.slug());
        t.setDaemon(true);
        t.start();
    }

    public static void installAll() {
        for (Addons.Entry e : Addons.CATALOG) if (get().enabled(e)) install(e);
    }

    /** Switches a resource pack on or off right now (one resource reload). */
    private static void applyPack(Addons.Entry e) {
        Minecraft mc = Minecraft.getInstance();
        Addons a = get();
        String file = a.file(e);
        if (file == null) return;
        String id = "file/" + file;
        var repo = mc.getResourcePackRepository();
        repo.reload();
        if (a.enabled(e) && repo.isAvailable(id)) {
            repo.removePack(id);
            repo.addPack(id);
        } else {
            repo.removePack(id);
        }
        List<String> old = List.copyOf(mc.options.resourcePacks);
        mc.options.updateResourcePacks(repo);
        if (old.equals(mc.options.resourcePacks)) mc.reloadResourcePacks();
    }
}
