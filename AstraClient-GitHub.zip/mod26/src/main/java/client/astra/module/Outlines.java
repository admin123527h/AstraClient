package client.astra.module;

import client.astra.music.AstraConfig;
import com.mojang.blaze3d.vertex.PoseStack;
import net.fabricmc.fabric.api.client.rendering.v1.level.LevelRenderEvents;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.components.debug.DebugScreenEntries;
import net.minecraft.client.renderer.rendertype.RenderTypes;
import net.minecraft.core.BlockPos;
import net.minecraft.world.phys.Vec3;

/** Draws the outline of the block you look at in your own colour, and toggles the vanilla entity hitboxes. */
public final class Outlines {
    private Outlines() {}

    /** False in the builds for older 26.x versions, where this part of the render API differs. */
    public static boolean supported() { return true; }

    public static void init() {
        LevelRenderEvents.BEFORE_BLOCK_OUTLINE.register((ctx, state) -> {
            AstraConfig cfg = AstraConfig.get();
            if (!cfg.outlines) return true;
            PoseStack m = ctx.poseStack();
            Vec3 cam = ctx.levelState().cameraRenderState.pos;
            BlockPos pos = state.pos();
            m.pushPose();
            m.translate(pos.getX() - cam.x, pos.getY() - cam.y, pos.getZ() - cam.z);
            ctx.submitNodeCollector().submitShapeOutline(m, state.shape(), RenderTypes.linesDepthBias(), 0xFF000000 | cfg.outlineColor, 3.5f, state.isTranslucent());
            m.popPose();
            return false;
        });
    }

    public static boolean hitboxes() {
        return Minecraft.getInstance().debugEntries.isCurrentlyEnabled(DebugScreenEntries.ENTITY_HITBOXES);
    }

    public static void toggleHitboxes() {
        Minecraft.getInstance().debugEntries.toggleStatus(DebugScreenEntries.ENTITY_HITBOXES);
    }
}
