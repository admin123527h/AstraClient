package client.astra.module;

import net.minecraft.client.KeyMapping;

/** The key a binding is on right now, so the menu always shows what the player set in Minecraft's controls. */
public final class KeyNames {
    private KeyNames() {}

    public static String of(KeyMapping key) {
        if (key == null) return "?";
        return key.isUnbound() ? "no key" : key.getTranslatedKeyMessage().getString();
    }
}
