package client.astra.module;

import client.astra.music.AstraConfig;
import net.minecraft.client.Minecraft;
import net.minecraft.client.Options;

/**
 * Zoom like Zoomify: hold (or toggle) the zoom key, scroll to change how far you zoom, smooth transition, optional
 * cinematic camera and a slower mouse while zoomed. The FOV part is called from the camera's FOV calculation.
 */
public final class Zoom {
    private static float current = 1f;
    private static long last = System.nanoTime();
    private static boolean toggled;
    private static boolean engaged;
    private static double baseSensitivity;
    private static boolean baseSmooth;

    private Zoom() {}

    /** True while the zoom key is in effect (held, or toggled on). */
    public static boolean wanted() {
        AstraConfig cfg = AstraConfig.get();
        if (!cfg.zoomEnabled || Minecraft.getInstance().gui.screen() != null) return false;
        return cfg.zoomToggle ? toggled : Modules.zoomHeld();
    }

    public static void keyClicked() {
        toggled = !toggled;
    }

    /** Scroll wheel while zooming; returns true when the scroll was used (so the hotbar does not move). */
    public static boolean scroll(double amount) {
        if (!wanted() || amount == 0) return false;
        AstraConfig cfg = AstraConfig.get();
        double factor = amount > 0 ? 0.85 : 1 / 0.85;
        int next = (int) Math.round(cfg.zoomPercent * factor);
        if (next == cfg.zoomPercent) next += amount > 0 ? -1 : 1;
        cfg.zoomPercent = Math.max(2, Math.min(90, next));
        cfg.save();
        return true;
    }

    public static float apply(float fov) {
        AstraConfig cfg = AstraConfig.get();
        float target = wanted() ? Math.max(0.02f, cfg.zoomPercent / 100f) : 1f;
        long now = System.nanoTime();
        float dt = Math.min(0.1f, (now - last) / 1e9f);
        last = now;
        current += (target - current) * Math.min(1f, dt * 12f);
        if (Math.abs(current - target) < 0.002f) current = target;
        return current >= 0.999f ? fov : fov * current;
    }

    /** Per tick: cinematic camera and mouse speed while zoomed, put back afterwards. */
    public static void tick(Minecraft mc) {
        AstraConfig cfg = AstraConfig.get();
        Options o = mc.options;
        if (wanted()) {
            if (!engaged) {
                engaged = true;
                baseSensitivity = o.sensitivity().get();
                baseSmooth = o.smoothCamera;
            }
            if (cfg.zoomSlowMouse) o.sensitivity().set(Math.max(0.01, baseSensitivity * Math.max(0.12, current)));
            if (cfg.zoomCinematic) o.smoothCamera = true;
        } else if (engaged && current >= 0.999f) {
            restore(mc);
        }
        if (!cfg.zoomEnabled) toggled = false;
    }

    public static void restore(Minecraft mc) {
        if (!engaged) return;
        mc.options.sensitivity().set(baseSensitivity);
        mc.options.smoothCamera = baseSmooth;
        engaged = false;
    }
}
