package client.astra.module;

import com.mojang.blaze3d.Blaze3D;
import net.fabricmc.loader.api.FabricLoader;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;

/** Opens the game's folders in the system file manager, so the player can add or remove files by hand. */
public final class Folders {
    private Folders() {}

    public static Path game() {
        return FabricLoader.getInstance().getGameDir();
    }

    /** Opens a folder inside the game folder ("" for the game folder itself); it is created first when missing. */
    public static void open(String sub) {
        Path dir = sub.isEmpty() ? game() : game().resolve(sub);
        try {
            Files.createDirectories(dir);
        } catch (IOException ignored) {
        }
        Blaze3D.openPath(dir.toAbsolutePath());
    }
}
