package client.astra.module;

import client.astra.music.AstraConfig;
import com.mojang.blaze3d.platform.NativeImage;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.texture.DynamicTexture;
import net.minecraft.resources.Identifier;
import net.minecraft.server.packs.resources.Resource;

import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.function.Consumer;
import java.util.regex.Pattern;
import java.util.stream.Stream;

/**
 * Item looks: totems, shields, tools and armor can be repainted with a design (facets, glow, runes). The recoloured textures are made on
 * this computer from the player's own copy of the game (nothing from Minecraft is shipped with Astra), written into a
 * small resource pack named astra_items, and applied with one resource reload.
 */
public final class ItemSkins {
    public record Preset(String name, ItemPainter.Design design) {}

    public record Category(String id, String label, String previewTexture, int cropX, int cropY, int cropW, int cropH, List<Pattern> files) {}

    public static final String PACK = "astra_items";

    public static final List<Category> CATEGORIES = List.of(
            new Category("totem", "Totem of Undying", "textures/item/totem_of_undying.png", 0, 0, 16, 16,
                    List.of(Pattern.compile("textures/item/totem_of_undying\\.png"))),
            new Category("shield", "Shield", "textures/entity/shield/shield_base_nopattern.png", 1, 1, 12, 22,
                    List.of(Pattern.compile("textures/entity/shield/shield_base(_nopattern)?\\.png"))),
            new Category("sword", "Swords", "textures/item/diamond_sword.png", 0, 0, 16, 16,
                    List.of(Pattern.compile("textures/item/(?!leather)[a-z]+_sword\\.png"))),
            new Category("tools", "Pickaxes, axes, shovels, hoes and spears", "textures/item/diamond_pickaxe.png", 0, 0, 16, 16,
                    List.of(Pattern.compile("textures/item/(?!leather)[a-z]+_(pickaxe|axe|shovel|hoe|spear|spear_in_hand)\\.png"))),
            new Category("armor", "Armor (items and worn)", "textures/item/diamond_chestplate.png", 0, 0, 16, 16,
                    List.of(Pattern.compile("textures/item/(?!leather)[a-z]+_(helmet|chestplate|leggings|boots)\\.png"),
                            Pattern.compile("textures/entity/equipment/humanoid(_leggings|_baby)?/(?!leather)[a-z_]+\\.png"))));

    public static final List<Preset> PRESETS = List.of(
            new Preset("Default", null),
            new Preset("Amethyst", new ItemPainter.Design("Amethyst", ItemPainter.Style.CRYSTAL, 0x1A0F3D, 0x4C1D95, 0x8B5CF6, 0xD8B4FE, 0xF0ABFC)),
            new Preset("Ocean", new ItemPainter.Design("Ocean", ItemPainter.Style.CRYSTAL, 0x04202E, 0x0E5A7A, 0x22D3EE, 0xA5F3FC, 0xFFFFFF)),
            new Preset("Inferno", new ItemPainter.Design("Inferno", ItemPainter.Style.EMBER, 0x120505, 0x3B0A0A, 0xB91C1C, 0xF97316, 0xFDE047)),
            new Preset("Toxic", new ItemPainter.Design("Toxic", ItemPainter.Style.EMBER, 0x04120A, 0x10281A, 0x15803D, 0xA3E635, 0xFEF9C3)),
            new Preset("Frostbite", new ItemPainter.Design("Frostbite", ItemPainter.Style.RUNIC, 0x0B1C2C, 0x2B5A82, 0x7DD3FC, 0xE0F2FE, 0x38BDF8)),
            new Preset("Royal", new ItemPainter.Design("Royal", ItemPainter.Style.RUNIC, 0x2B1A02, 0x92400E, 0xF59E0B, 0xFEF3C7, 0xDC2626)));

    private static final Map<String, Identifier> PREVIEWS = new HashMap<>();
    private static final Map<String, NativeImage> ORIGINALS = new HashMap<>();
    private static volatile String status = "";

    private ItemSkins() {}

    public static String status() { return status; }

    public static Preset preset(String name) {
        for (Preset p : PRESETS) if (p.name().equals(name)) return p;
        return PRESETS.get(0);
    }

    public static String selected(Category c) {
        return AstraConfig.get().itemSkins.getOrDefault(c.id(), "Default");
    }

    public static boolean pending() {
        AstraConfig cfg = AstraConfig.get();
        for (Category c : CATEGORIES) {
            if (!cfg.itemSkins.getOrDefault(c.id(), "Default").equals(cfg.itemSkinsApplied.getOrDefault(c.id(), "Default"))) return true;
        }
        return false;
    }

    // ---- reading the player's own vanilla textures ----

    private static NativeImage vanilla(Minecraft mc, String path) throws IOException {
        Identifier id = Identifier.withDefaultNamespace(path);
        Resource chosen = null;
        for (Resource r : mc.getResourceManager().getResourceStack(id)) {
            if (r.sourcePackId().equals("vanilla")) chosen = r;
        }
        if (chosen == null) chosen = mc.getResourceManager().getResource(id).orElseThrow(() -> new IOException("missing " + path));
        try (InputStream in = chosen.open()) {
            return NativeImage.read(in);
        }
    }

    private static NativeImage copy(NativeImage src) {
        NativeImage out = new NativeImage(src.getWidth(), src.getHeight(), false);
        out.copyFrom(src);
        return out;
    }

    // ---- previews for the menu ----

    /** A small texture showing what the category looks like with this preset (made on first use, then kept). */
    public static Identifier preview(Category c, Preset p) {
        String key = c.id() + "/" + p.name();
        Identifier cached = PREVIEWS.get(key);
        if (cached != null) return cached;
        try {
            NativeImage base = ORIGINALS.get(c.id());
            if (base == null) {
                NativeImage full = vanilla(Minecraft.getInstance(), c.previewTexture());
                base = new NativeImage(c.cropW(), c.cropH(), false);
                for (int y = 0; y < c.cropH(); y++) for (int x = 0; x < c.cropW(); x++) base.setPixel(x, y, full.getPixel(c.cropX() + x, c.cropY() + y));
                full.close();
                ORIGINALS.put(c.id(), base);
            }
            NativeImage tinted = p.design() == null ? copy(base) : ItemPainter.paint(base, p.design(), c.previewTexture());
            DynamicTexture tex = new DynamicTexture(() -> "astra item preview", tinted);
            Identifier id = Identifier.fromNamespaceAndPath("astra", "preview/" + c.id() + "_" + p.name().toLowerCase());
            Minecraft.getInstance().getTextureManager().register(id, tex);
            PREVIEWS.put(key, id);
            return id;
        } catch (IOException | RuntimeException e) {
            return null;
        }
    }

    // ---- applying ----

    /** Writes the pack from the selection and reloads resources. Returns quickly; progress shows in status(). */
    public static void apply(Minecraft mc) {
        AstraConfig cfg = AstraConfig.get();
        Map<String, String> wanted = new HashMap<>(cfg.itemSkins);
        status = "Making item textures...";
        Thread t = new Thread(() -> {
            try {
                Path dir = mc.gameDirectory.toPath().resolve("resourcepacks").resolve(PACK);
                if (Files.exists(dir)) {
                    try (Stream<Path> walk = Files.walk(dir)) {
                        for (Path p : walk.sorted(Comparator.reverseOrder()).toList()) Files.delete(p);
                    }
                }
                int written = 0;
                for (Category c : CATEGORIES) {
                    Preset preset = preset(wanted.getOrDefault(c.id(), "Default"));
                    if (preset.name().equals("Default")) continue;
                    for (Identifier id : matching(mc, c)) {
                        try (NativeImage src = vanilla(mc, id.getPath()); NativeImage out = ItemPainter.paint(src, preset.design(), id.getPath())) {
                            Path file = dir.resolve("assets").resolve("minecraft").resolve(id.getPath());
                            Files.createDirectories(file.getParent());
                            out.writeToFile(file);
                            written++;
                        } catch (IOException e) {
                            // one unreadable texture must not stop the rest
                        }
                    }
                }
                boolean any = written > 0;
                if (any) writeMeta(dir);
                int count = written;
                mc.execute(() -> finish(mc, wanted, any, count));
            } catch (IOException | RuntimeException e) {
                status = "Could not make the item textures: " + e.getMessage();
            }
        }, "astra-item-skins");
        t.setDaemon(true);
        t.start();
    }

    private static List<Identifier> matching(Minecraft mc, Category c) {
        List<Identifier> out = new ArrayList<>();
        for (Identifier id : mc.getResourceManager().listResources("textures", i -> i.getNamespace().equals("minecraft")).keySet()) {
            for (Pattern pat : c.files()) {
                if (pat.matcher(id.getPath()).matches()) {
                    out.add(id);
                    break;
                }
            }
        }
        return out;
    }

    private static void writeMeta(Path dir) throws IOException {
        Files.createDirectories(dir);
        int major = net.minecraft.SharedConstants.getCurrentVersion().packVersion(net.minecraft.server.packs.PackType.CLIENT_RESOURCES).major();
        Files.writeString(dir.resolve("pack.mcmeta"), "{\"pack\":{\"description\":\"Astra item skins (made by Astra Client)\",\"min_format\":" + major
                + ",\"max_format\":" + major + "}}");
    }

    private static void finish(Minecraft mc, Map<String, String> wanted, boolean any, int count) {
        var repo = mc.getResourcePackRepository();
        repo.reload();
        String id = "file/" + PACK;
        if (any && repo.isAvailable(id)) {
            repo.removePack(id);
            repo.addPack(id);
        } else {
            repo.removePack(id);
        }
        AstraConfig cfg = AstraConfig.get();
        cfg.itemSkinsApplied = new HashMap<>(wanted);
        cfg.save();
        status = any ? "Applied " + count + " textures. Reloading..." : "Back to the normal item looks. Reloading...";
        List<String> old = new ArrayList<>(mc.options.resourcePacks);
        mc.options.updateResourcePacks(repo);
        if (old.equals(mc.options.resourcePacks)) mc.reloadResourcePacks();
        status = any ? "Item skins applied (" + count + " textures)" : "Normal item looks restored";
    }

    public static void reset(Minecraft mc) {
        AstraConfig cfg = AstraConfig.get();
        cfg.itemSkins.clear();
        cfg.save();
        apply(mc);
    }
}
