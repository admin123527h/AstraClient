package client.astra.module;

import client.astra.music.AstraConfig;
import com.mojang.blaze3d.platform.InputConstants;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientLifecycleEvents;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;

import java.util.function.BiFunction;

/** Registers the keys of all optional modules and drives their per-tick work. */
public final class Modules {
    private static KeyMapping zoomKey;
    private static KeyMapping fullbrightKey;

    private Modules() {}

    public static String zoomKeyName() { return KeyNames.of(zoomKey); }

    public static String fullbrightKeyName() { return KeyNames.of(fullbrightKey); }

    public static boolean zoomHeld() { return zoomKey != null && zoomKey.isDown(); }

    public static void init(BiFunction<String, Integer, KeyMapping> key) {
        zoomKey = key.apply("key.astra.zoom", InputConstants.KEY_C);
        fullbrightKey = key.apply("key.astra.fullbright", InputConstants.KEY_G);

        ClientTickEvents.END_CLIENT_TICK.register(Modules::tick);
        ClientLifecycleEvents.CLIENT_STOPPING.register(mc -> {
            Booster.restore();
            Fullbright.off(mc);
            Zoom.restore(mc);
        });
        Outlines.init();
    }

    private static void tick(Minecraft mc) {
        AstraConfig cfg = AstraConfig.get();
        while (fullbrightKey.consumeClick()) {
            cfg.fullbright = !cfg.fullbright;
            cfg.save();
        }
        while (zoomKey.consumeClick()) {
            if (cfg.zoomToggle) Zoom.keyClicked();
        }
        Zoom.tick(mc);
        if (client.astra.Astra.DEV && mc.level != null && mc.level.getGameTime() % 100 == 0) {
            var id = net.minecraft.resources.Identifier.withDefaultNamespace("textures/item/totem_of_undying.png");
            System.out.println("[astra-items] totem source: " + mc.getResourceManager().getResource(id).map(r -> r.sourcePackId()).orElse("none"));
        }
        Fullbright.tick(mc);
        Booster.tick(mc);
    }
}
