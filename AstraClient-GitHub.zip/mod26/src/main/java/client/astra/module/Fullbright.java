package client.astra.module;

import client.astra.music.AstraConfig;
import net.minecraft.client.Minecraft;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;

/**
 * Fullbright through a client-side night vision effect: purely visual, nothing is sent to the server,
 * and the effect is taken off again when the module is switched off.
 */
public final class Fullbright {
    private static boolean applied;

    private Fullbright() {}

    public static void tick(Minecraft mc) {
        if (mc.player == null) {
            applied = false;
            return;
        }
        boolean want = AstraConfig.get().fullbright;
        MobEffectInstance now = mc.player.getEffect(MobEffects.NIGHT_VISION);
        if (want) {
            if (now == null || !now.isInfiniteDuration() && now.getDuration() < 300) {
                mc.player.addEffect(new MobEffectInstance(MobEffects.NIGHT_VISION, MobEffectInstance.INFINITE_DURATION, 0, true, false, false));
                applied = true;
            }
        } else if (applied) {
            if (now != null && now.isInfiniteDuration()) mc.player.removeEffectNoUpdate(MobEffects.NIGHT_VISION);
            applied = false;
        }
    }

    public static void off(Minecraft mc) {
        if (applied && mc.player != null) {
            MobEffectInstance now = mc.player.getEffect(MobEffects.NIGHT_VISION);
            if (now != null && now.isInfiniteDuration()) mc.player.removeEffectNoUpdate(MobEffects.NIGHT_VISION);
        }
        applied = false;
    }
}
