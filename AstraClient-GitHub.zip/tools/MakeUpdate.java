import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.security.MessageDigest;
import java.util.*;
import java.util.regex.*;
import java.util.zip.ZipFile;

/**
 * Builds the update/ folder that the launcher downloads from GitHub.
 * Run from the project root after building:   java tools/MakeUpdate.java
 * Jars whose content did not change keep their old build number, so nobody re-downloads them for nothing.
 */
public class MakeUpdate {
    static final String[][] MODS = {
            {"1.21.11", "mod/build/libs/astra-client-0.1.0.jar"},
            {"26.3", "mod26/build/libs/astra-client-26-0.2.0.jar"},
            {"26.2", "mod262/build/libs/astra-client-262-0.2.0.jar"},
            {"26.1", "mod261/build/libs/astra-client-261-0.2.0.jar"},
    };

    public static void main(String[] args) throws Exception {
        Path out = Path.of(args.length > 0 && !args[0].startsWith("--") ? args[0] : "update");
        Files.createDirectories(out.resolve("mods"));
        Path manifest = out.resolve("manifest.json");
        String old = Files.exists(manifest) ? Files.readString(manifest) : "";
        long now = System.currentTimeMillis() / 60000L;

        // Shared app IDs: kept from the old manifest, or set with --microsoft=<id> / --spotify=<id>.
        String ms = valueOf(old, "microsoftClientId"), sp = valueOf(old, "spotifyClientId");
        for (String arg : args) {
            if (arg.startsWith("--microsoft=")) ms = arg.substring("--microsoft=".length());
            if (arg.startsWith("--spotify=")) sp = arg.substring("--spotify=".length());
        }
        StringBuilder json = new StringBuilder("{\n  \"format\": 1,\n");
        json.append("  \"defaults\": {\"microsoftClientId\": \"").append(ms).append("\", \"spotifyClientId\": \"").append(sp).append("\"},\n");

        Path launcher = Path.of("launcher/build/libs/AstraLauncher.jar");
        if (Files.exists(launcher)) {
            long build;
            try (ZipFile zip = new ZipFile(launcher.toFile()); InputStream in = zip.getInputStream(zip.getEntry("launcher.build"))) {
                build = Long.parseLong(new String(in.readAllBytes(), StandardCharsets.UTF_8).trim());
            }
            Files.copy(launcher, out.resolve("core.jar"), StandardCopyOption.REPLACE_EXISTING);
            json.append("  \"core\": {\"build\": ").append(build).append(", \"url\": \"core.jar\", \"sha1\": \"")
                    .append(sha1(launcher)).append("\"},\n");
            System.out.println("launcher  build " + build);
        }

        json.append("  \"mods\": {\n");
        List<String> entries = new ArrayList<>();
        for (String[] m : MODS) {
            Path jar = Path.of(m[1]);
            if (!Files.exists(jar)) {
                System.out.println("skipped " + m[0] + " (not built)");
                continue;
            }
            String sha = sha1(jar);
            long build = now;
            Matcher prev = Pattern.compile("\"" + Pattern.quote(m[0]) + "\": \\{\"build\": (\\d+), \"url\": \"[^\"]*\", \"sha1\": \"" + sha + "\"").matcher(old);
            if (prev.find()) build = Long.parseLong(prev.group(1));
            Files.copy(jar, out.resolve("mods/astra-" + m[0] + ".jar"), StandardCopyOption.REPLACE_EXISTING);
            entries.add("    \"" + m[0] + "\": {\"build\": " + build + ", \"url\": \"mods/astra-" + m[0] + ".jar\", \"sha1\": \"" + sha + "\"}");
            System.out.println("mod " + m[0] + "  build " + build + (build == now ? " (new)" : " (unchanged)"));
        }
        json.append(String.join(",\n", entries)).append("\n  }\n}\n");
        Files.writeString(manifest, json.toString());
        System.out.println("Wrote " + manifest.toAbsolutePath());
    }

    static String valueOf(String json, String key) {
        Matcher m = Pattern.compile("\"" + key + "\": \"([^\"]*)\"").matcher(json);
        return m.find() ? m.group(1) : "";
    }

    static String sha1(Path file) throws Exception {
        MessageDigest md = MessageDigest.getInstance("SHA-1");
        return HexFormat.of().formatHex(md.digest(Files.readAllBytes(file)));
    }
}
