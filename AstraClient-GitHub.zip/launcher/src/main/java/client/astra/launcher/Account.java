package client.astra.launcher;

import java.nio.charset.StandardCharsets;
import java.util.UUID;

public record Account(String name, String uuid, String accessToken, boolean microsoft) {
    public static Account offline(String name) {
        String clean = name == null || name.isBlank() ? "Player" : name.trim();
        UUID id = UUID.nameUUIDFromBytes(("OfflinePlayer:" + clean).getBytes(StandardCharsets.UTF_8));
        return new Account(clean, id.toString().replace("-", ""), "0", false);
    }
}
