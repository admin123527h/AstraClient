package client.astra.launcher;

import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

/** Finds a Java 21+ runtime for the game, downloading Temurin 21 when none is available. */
public final class JavaRuntime {
    private JavaRuntime() {}

    public static Path find(Config cfg, int major, Install.Progress p) throws Exception {
        if (!cfg.javaPath.isBlank() && Files.exists(Path.of(cfg.javaPath))) return Path.of(cfg.javaPath);
        if (Runtime.version().feature() >= major && System.getProperty("jpackage.app-path") == null) {
            Path own = locate(Path.of(System.getProperty("java.home")));
            if (own != null) return own;
        }
        Path dir = Dirs.RUNTIME.resolve("java" + major);
        Path local = Files.isDirectory(dir) ? locate(dir) : null;
        if (local != null) return local;

        p.update("Downloading Java " + major, 0.0);
        String os = switch (Dirs.osName()) { case "windows" -> "windows"; case "osx" -> "mac"; default -> "linux"; };
        String arch = System.getProperty("os.arch", "").matches(".*(aarch64|arm64).*") ? "aarch64" : "x64";
        String url = "https://api.adoptium.net/v3/binary/latest/" + major + "/ga/" + os + "/" + arch + "/jre/hotspot/normal/eclipse";
        Files.createDirectories(dir);
        Path archive = Dirs.RUNTIME.resolve("java" + major + "." + (os.equals("windows") ? "zip" : "tar.gz"));
        Http.download(url, archive, null);
        p.update("Unpacking Java " + major, 0.5);
        if (os.equals("windows")) unzip(archive, dir); else untar(archive, dir);
        Files.deleteIfExists(archive);
        Path found = locate(dir);
        if (found == null) throw new IOException("Java " + major + " was downloaded but no java executable was found");
        return found;
    }

    private static Path locate(Path root) throws IOException {
        String[] names = Dirs.osName().equals("windows") ? new String[] {"javaw.exe", "java.exe"} : new String[] {"java"};
        try (var walk = Files.walk(root, 6)) {
            for (String n : names) {
                var hit = walk.filter(f -> f.getFileName().toString().equals(n) && f.getParent().getFileName().toString().equals("bin")).findFirst();
                if (hit.isPresent()) return hit.get();
            }
        }
        try (var walk = Files.walk(root, 6)) {
            return walk.filter(f -> f.getFileName().toString().equals(names[names.length - 1]) && f.getParent().getFileName().toString().equals("bin")).findFirst().orElse(null);
        }
    }

    private static void unzip(Path zip, Path dest) throws IOException {
        try (ZipInputStream in = new ZipInputStream(Files.newInputStream(zip))) {
            for (ZipEntry e; (e = in.getNextEntry()) != null; ) {
                Path out = dest.resolve(e.getName()).normalize();
                if (!out.startsWith(dest)) throw new IOException("bad zip entry " + e.getName());
                if (e.isDirectory()) { Files.createDirectories(out); continue; }
                Files.createDirectories(out.getParent());
                Files.copy(in, out, StandardCopyOption.REPLACE_EXISTING);
            }
        }
    }

    private static void untar(Path archive, Path dest) throws IOException {
        try {
            Process pr = new ProcessBuilder("tar", "-xzf", archive.toString(), "-C", dest.toString()).inheritIO().start();
            if (pr.waitFor() != 0) throw new IOException("tar failed");
            try (InputStream ignored = InputStream.nullInputStream()) { /* keep stream import used */ }
            new ProcessBuilder("chmod", "-R", "u+x", dest.toString()).start().waitFor();
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            throw new IOException(e);
        }
    }
}
