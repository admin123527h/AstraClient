package client.astra.launcher;

import javax.swing.SwingUtilities;

public final class Main {
    private Main() {}

    public static void main(String[] args) throws Exception {
        if (args.length > 0 && args[0].equals("--version")) {
            System.out.println("Astra Launcher build " + Updates.launcherBuild());
            return;
        }
        if (args.length > 0 && args[0].equals("--update")) {
            String core = Updates.refreshCore();
            System.out.println(core == null ? "Launcher: up to date" : core);
            for (String family : new String[] {"26.3", "26.2", "26.1", "1.21.11"}) {
                String mod = Updates.refreshMod(family);
                System.out.println(mod == null ? "Mod " + family + ": up to date" : mod);
            }
            return;
        }
        for (int i = 0; i < args.length; i++) {
            if (args[i].equals("--cli")) {
                Cli.run(i + 1 < args.length ? args[i + 1] : "Player", i + 2 < args.length ? args[i + 2] : "1.21.11");
                return;
            }
        }
        System.setProperty("awt.useSystemAAFontSettings", "on");
        SwingUtilities.invokeLater(() -> new LauncherWindow().setVisible(true));
    }
}
