package client.astra.launcher;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.io.InputStream;

final class Theme {
    static final Color SKY_TOP = new Color(0x090615);
    static final Color SKY_BOTTOM = new Color(0x2C1B58);
    static final Color ACCENT = new Color(0xA78BFA);
    static final Color ACCENT_DEEP = new Color(0x6D3FD8);
    static final Color TEXT = new Color(0xEDE9FE);
    static final Color DIM = new Color(0xA79BCB);
    static final Color GLASS_TOP = new Color(255, 255, 255, 34);
    static final Color GLASS_BOTTOM = new Color(190, 170, 255, 14);
    static final Color BORDER = new Color(200, 180, 255, 90);
    static final Color OK = new Color(0x86EFAC);
    static final Color ERROR = new Color(0xFCA5A5);

    private static Font base;

    private Theme() {}

    static Font font(float size) {
        if (base == null) {
            try (InputStream in = Theme.class.getResourceAsStream("/fonts/poppins.ttf")) {
                base = in == null ? new Font(Font.SANS_SERIF, Font.BOLD, 12) : Font.createFont(Font.TRUETYPE_FONT, in);
            } catch (Exception e) {
                base = new Font(Font.SANS_SERIF, Font.BOLD, 12);
            }
        }
        return base.deriveFont(size);
    }

    static void quality(Graphics2D g) {
        g.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        g.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);
        g.setRenderingHint(RenderingHints.KEY_STROKE_CONTROL, RenderingHints.VALUE_STROKE_PURE);
    }
}
