package client.astra.launcher;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.geom.Ellipse2D;
import java.awt.geom.Path2D;
import java.awt.geom.RoundRectangle2D;

/** Vector icons drawn with Java2D, so they stay sharp at any size and take any colour. */
final class Icons {
    static final int PLAY = 0, USER = 1, GEAR = 2, TERMINAL = 3, SKY = 4, NOTE = 5, CUBE = 6;

    private Icons() {}

    static void draw(Graphics2D g, int kind, float cx, float cy, float s, Color color) {
        g.setColor(color);
        g.setStroke(new BasicStroke(Math.max(1.4f, s * 0.1f), BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND));
        switch (kind) {
            case PLAY -> {
                Path2D p = new Path2D.Float();
                p.moveTo(cx - s * 0.22f, cy - s * 0.32f);
                p.lineTo(cx + s * 0.34f, cy);
                p.lineTo(cx - s * 0.22f, cy + s * 0.32f);
                p.closePath();
                g.fill(p);
                g.draw(p);
            }
            case USER -> {
                g.draw(new Ellipse2D.Float(cx - s * 0.17f, cy - s * 0.38f, s * 0.34f, s * 0.34f));
                Path2D p = new Path2D.Float();
                p.moveTo(cx - s * 0.36f, cy + s * 0.4f);
                p.curveTo(cx - s * 0.36f, cy + s * 0.05f, cx + s * 0.36f, cy + s * 0.05f, cx + s * 0.36f, cy + s * 0.4f);
                g.draw(p);
            }
            case GEAR -> {
                g.draw(new Ellipse2D.Float(cx - s * 0.2f, cy - s * 0.2f, s * 0.4f, s * 0.4f));
                for (int i = 0; i < 8; i++) {
                    double a = Math.PI / 4 * i;
                    g.draw(new java.awt.geom.Line2D.Float(cx + (float) Math.cos(a) * s * 0.3f, cy + (float) Math.sin(a) * s * 0.3f,
                            cx + (float) Math.cos(a) * s * 0.42f, cy + (float) Math.sin(a) * s * 0.42f));
                }
            }
            case TERMINAL -> {
                g.draw(new RoundRectangle2D.Float(cx - s * 0.42f, cy - s * 0.32f, s * 0.84f, s * 0.64f, s * 0.16f, s * 0.16f));
                g.draw(new java.awt.geom.Line2D.Float(cx - s * 0.24f, cy - s * 0.1f, cx - s * 0.08f, cy + s * 0.02f));
                g.draw(new java.awt.geom.Line2D.Float(cx - s * 0.08f, cy + s * 0.02f, cx - s * 0.24f, cy + s * 0.14f));
                g.draw(new java.awt.geom.Line2D.Float(cx + s * 0.02f, cy + s * 0.15f, cx + s * 0.22f, cy + s * 0.15f));
            }
            case SKY -> {
                Path2D p = new Path2D.Float();
                for (int i = 0; i < 8; i++) {
                    double a = Math.PI / 4 * i - Math.PI / 2;
                    float r = i % 2 == 0 ? s * 0.44f : s * 0.13f;
                    float x = cx + (float) Math.cos(a) * r, y = cy + (float) Math.sin(a) * r;
                    if (i == 0) p.moveTo(x, y); else p.lineTo(x, y);
                }
                p.closePath();
                g.fill(p);
            }
            case NOTE -> {
                g.fill(new Ellipse2D.Float(cx - s * 0.3f, cy + s * 0.12f, s * 0.3f, s * 0.24f));
                g.draw(new java.awt.geom.Line2D.Float(cx - s * 0.02f, cy + s * 0.22f, cx - s * 0.02f, cy - s * 0.34f));
                g.draw(new java.awt.geom.Line2D.Float(cx - s * 0.02f, cy - s * 0.34f, cx + s * 0.28f, cy - s * 0.18f));
            }
            default -> {
                Path2D p = new Path2D.Float();
                p.moveTo(cx, cy - s * 0.42f);
                p.lineTo(cx + s * 0.38f, cy - s * 0.2f);
                p.lineTo(cx + s * 0.38f, cy + s * 0.22f);
                p.lineTo(cx, cy + s * 0.42f);
                p.lineTo(cx - s * 0.38f, cy + s * 0.22f);
                p.lineTo(cx - s * 0.38f, cy - s * 0.2f);
                p.closePath();
                g.draw(p);
                g.draw(new java.awt.geom.Line2D.Float(cx, cy, cx, cy + s * 0.42f));
                g.draw(new java.awt.geom.Line2D.Float(cx, cy, cx + s * 0.38f, cy - s * 0.2f));
                g.draw(new java.awt.geom.Line2D.Float(cx, cy, cx - s * 0.38f, cy - s * 0.2f));
            }
        }
    }
}
