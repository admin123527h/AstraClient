package client.astra.launcher;

import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.Shape;
import java.awt.BasicStroke;

/** Small helpers for the animated look: a shared clock, colour mixing and soft glows. */
final class Fx {
    private static final long START = System.nanoTime();

    private Fx() {}

    static float time() {
        return (System.nanoTime() - START) / 1_000_000_000f;
    }

    static Color alpha(Color c, int a) {
        return new Color(c.getRed(), c.getGreen(), c.getBlue(), Math.max(0, Math.min(255, a)));
    }

    static Color mix(Color a, Color b, float t) {
        t = Math.max(0, Math.min(1, t));
        return new Color(
                Math.round(a.getRed() + (b.getRed() - a.getRed()) * t),
                Math.round(a.getGreen() + (b.getGreen() - a.getGreen()) * t),
                Math.round(a.getBlue() + (b.getBlue() - a.getBlue()) * t),
                Math.round(a.getAlpha() + (b.getAlpha() - a.getAlpha()) * t));
    }

    /** A soft glow around a shape, made of a few widening translucent outlines. */
    static void glow(Graphics2D g, Shape s, Color c, int layers, float spread, int alpha) {
        java.awt.Stroke old = g.getStroke();
        for (int i = layers; i >= 1; i--) {
            g.setStroke(new BasicStroke(1f + i * spread, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND));
            g.setColor(alpha(c, Math.max(1, alpha / (layers + 1) * (layers - i + 1) / 2)));
            g.draw(s);
        }
        g.setStroke(old);
    }

    /** Eases a value toward a target; call once per frame. */
    static float approach(float value, float target, float speed) {
        return value + (target - value) * speed;
    }
}
