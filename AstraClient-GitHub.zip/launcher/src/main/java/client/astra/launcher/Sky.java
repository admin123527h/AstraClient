package client.astra.launcher;

import javax.swing.JPanel;
import java.awt.AlphaComposite;
import java.awt.Color;
import java.awt.GradientPaint;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.LinearGradientPaint;
import java.awt.RadialGradientPaint;
import java.awt.geom.Path2D;
import java.awt.image.BufferedImage;
import java.util.Random;

/**
 * The launcher's living night sky: drifting nebula clouds, flowing aurora ribbons, twinkling stars in three depths,
 * the odd shooting star, and a blocky horizon. The static parts are painted once per size and cached.
 */
final class Sky extends JPanel {
    private BufferedImage back, front;
    private int cachedW, cachedH;
    private float[][] stars;

    private static final Color[] BLOB = {new Color(124, 92, 224), new Color(236, 72, 153), new Color(34, 211, 238), new Color(99, 102, 241), new Color(192, 132, 252)};
    private static final Color[] RIBBON = {new Color(80, 255, 190), new Color(170, 110, 255), new Color(255, 120, 220)};

    Sky() {
        setOpaque(true);
    }

    private void build(int w, int h) {
        cachedW = w;
        cachedH = h;
        back = new BufferedImage(w, h, BufferedImage.TYPE_INT_RGB);
        Graphics2D g = back.createGraphics();
        Theme.quality(g);
        g.setPaint(new LinearGradientPaint(0, 0, 0, h, new float[] {0f, 0.55f, 0.85f, 1f},
                new Color[] {new Color(0x05030F), new Color(0x120A33), new Color(0x2A1560), new Color(0x4A2578)}));
        g.fillRect(0, 0, w, h);
        g.dispose();

        front = new BufferedImage(w, h, BufferedImage.TYPE_INT_ARGB);
        g = front.createGraphics();
        Theme.quality(g);
        Random r = new Random(42);
        // horizon: layered silhouettes with a faint glow behind them
        g.setPaint(new RadialGradientPaint(w * 0.5f, h * 0.9f, w * 0.6f, new float[] {0f, 1f},
                new Color[] {new Color(236, 110, 200, 70), new Color(236, 110, 200, 0)}));
        g.fillRect(0, (int) (h * 0.55), w, (int) (h * 0.45));
        int[] shades = {0x140C2E, 0x0C0720, 0x06040F};
        int[] bases = {(int) (h * 0.80), (int) (h * 0.86), (int) (h * 0.92)};
        for (int layer = 0; layer < 3; layer++) {
            g.setColor(new Color(shades[layer]));
            int step = 22 + layer * 4, level = 0;
            for (int x = 0; x < w; x += step) {
                level += r.nextInt(3) - 1;
                level = Math.max(-3, Math.min(3, level));
                g.fillRect(x, bases[layer] - level * step / 2, step, h);
            }
            for (int i = 0; i < 4 + layer; i++) {
                int tx = r.nextInt(w) / step * step;
                int ty = bases[layer] - 14 - r.nextInt(18);
                g.fillRect(tx + 16, ty, 10, 56);
                g.fillRect(tx, ty - 20, 42, 20);
                g.fillRect(tx + 10, ty - 38, 22, 18);
            }
        }
        // vignette
        g.setPaint(new RadialGradientPaint(w / 2f, h / 2f, Math.max(w, h) * 0.75f, new float[] {0.55f, 1f},
                new Color[] {new Color(0, 0, 0, 0), new Color(0, 0, 0, 150)}));
        g.fillRect(0, 0, w, h);
        g.dispose();

        stars = new float[170][];
        for (int i = 0; i < stars.length; i++) {
            stars[i] = new float[] {r.nextFloat() * w, r.nextFloat() * h * 0.74f, r.nextInt(14) == 0 ? 3 : (r.nextBoolean() ? 2 : 1),
                    r.nextFloat() * 6.28f, 0.6f + r.nextFloat() * 2.2f, r.nextInt(3)};
        }
    }

    @Override
    protected void paintComponent(Graphics g0) {
        int w = getWidth(), h = getHeight();
        if (back == null || w != cachedW || h != cachedH) build(w, h);
        Graphics2D g = (Graphics2D) g0.create();
        Theme.quality(g);
        float t = Fx.time();
        g.drawImage(back, 0, 0, null);

        // nebula clouds
        for (int i = 0; i < BLOB.length; i++) {
            float cx = w * (0.15f + 0.7f * (i / (float) (BLOB.length - 1))) + (float) Math.sin(t * 0.07f + i * 1.7f) * w * 0.12f;
            float cy = h * (0.25f + 0.3f * ((i * 37 % 5) / 4f)) + (float) Math.cos(t * 0.06f + i * 2.3f) * h * 0.1f;
            float radius = Math.max(w, h) * (0.32f + 0.06f * (i % 3));
            g.setPaint(new RadialGradientPaint(cx, cy, radius, new float[] {0f, 1f}, new Color[] {Fx.alpha(BLOB[i], 60), Fx.alpha(BLOB[i], 0)}));
            g.fillRect(0, 0, w, h);
        }

        // aurora ribbons
        for (int k = 0; k < RIBBON.length; k++) {
            float base = h * (0.2f + 0.09f * k);
            Path2D.Float p = new Path2D.Float();
            float[] bottoms = new float[w / 10 + 2];
            int n = 0;
            for (int x = 0; x <= w + 10; x += 10, n++) {
                float y = base + (float) (Math.sin(x * 0.007 + t * 0.32 + k * 2.1) * 38 + Math.sin(x * 0.019 - t * 0.45 + k) * 14);
                if (x == 0) p.moveTo(x, y); else p.lineTo(x, y);
                bottoms[Math.min(n, bottoms.length - 1)] = y + 120 + (float) Math.sin(x * 0.011 + t * 0.2 + k) * 34;
            }
            for (int x = ((n - 1) * 10); x >= 0; x -= 10) p.lineTo(x, bottoms[Math.min(x / 10, bottoms.length - 1)]);
            p.closePath();
            g.setPaint(new LinearGradientPaint(0, base - 60, 0, base + 190, new float[] {0f, 0.4f, 1f},
                    new Color[] {Fx.alpha(RIBBON[k], 0), Fx.alpha(RIBBON[k], 44), Fx.alpha(RIBBON[k], 0)}));
            g.fill(p);
        }

        // stars
        for (float[] s : stars) {
            float speed = 1.5f + s[5] * 4f;
            float x = (s[0] + t * speed) % w;
            float tw = 0.5f + 0.5f * (float) Math.sin(t * s[4] + s[3]);
            int a = (int) (50 + 190 * tw * (0.5f + 0.25f * (s[5] + 1)));
            int size = (int) s[2];
            g.setColor(new Color(255, 255, 255, Math.min(255, a)));
            g.fillRect((int) x, (int) s[1], size, size);
            if (size == 3) {
                g.setColor(new Color(220, 210, 255, a / 3));
                g.fillRect((int) x - 3, (int) s[1] + 1, 9, 1);
                g.fillRect((int) x + 1, (int) s[1] - 3, 1, 9);
            }
        }

        // shooting star every few seconds
        float period = 7.5f, c = t % period;
        if (c < 1.1f) {
            int round = (int) (t / period);
            float sx = w * (0.1f + 0.5f * ((round * 0.37f) % 1f)), sy = h * (0.05f + 0.15f * ((round * 0.61f) % 1f));
            float p = c / 1.1f;
            float hx = sx + p * 420f, hy = sy + p * 190f;
            float tx = hx - 110f, ty = hy - 50f;
            g.setPaint(new GradientPaint(tx, ty, new Color(255, 255, 255, 0), hx, hy, new Color(255, 255, 255, (int) (230 * (1 - p * 0.5f)))));
            g.setStroke(new java.awt.BasicStroke(2.2f, java.awt.BasicStroke.CAP_ROUND, java.awt.BasicStroke.JOIN_ROUND));
            g.draw(new java.awt.geom.Line2D.Float(tx, ty, hx, hy));
            g.setColor(new Color(255, 255, 255, 240));
            g.fillOval((int) hx - 2, (int) hy - 2, 5, 5);
        }

        g.setComposite(AlphaComposite.SrcOver);
        g.drawImage(front, 0, 0, null);
        g.dispose();
    }
}
