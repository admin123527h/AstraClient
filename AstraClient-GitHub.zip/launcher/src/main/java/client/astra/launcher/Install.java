package client.astra.launcher;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorCompletionService;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/** Installs vanilla Minecraft, Fabric, Fabric API and the Astra mod for one Minecraft version. */
public final class Install {
    public interface Progress {
        void update(String text, double fraction);
    }

    public record Result(String mc, int javaMajor, List<Path> classpath, String mainClass, String assetsIndexId,
                         JsonArray jvmArgs, JsonArray gameArgs, Path gameDir, boolean astraMod) {}

    private record Lib(String path, String url, String sha1) {}

    private Install() {}

    public static Result run(String mc, Progress p) throws Exception {
        p.update("Reading version list", 0.01);
        JsonObject manifest = Http.json("https://piston-meta.mojang.com/mc/game/version_manifest_v2.json");
        String versionUrl = null, versionSha = null;
        for (JsonElement e : manifest.getAsJsonArray("versions")) {
            JsonObject v = e.getAsJsonObject();
            if (mc.equals(v.get("id").getAsString())) {
                versionUrl = v.get("url").getAsString();
                versionSha = v.get("sha1").getAsString();
            }
        }
        if (versionUrl == null) throw new IOException("Minecraft " + mc + " not found in the version manifest");
        Path vanillaJson = Dirs.VERSIONS.resolve(mc).resolve(mc + ".json");
        Http.download(versionUrl, vanillaJson, versionSha);
        JsonObject vanilla = JsonParser.parseString(Files.readString(vanillaJson)).getAsJsonObject();
        int javaMajor = vanilla.has("javaVersion") ? vanilla.getAsJsonObject("javaVersion").get("majorVersion").getAsInt() : 21;

        p.update("Reading Fabric profile", 0.03);
        String loader = Versions.loaderFor(mc);
        String fabricId = "fabric-loader-" + loader + "-" + mc;
        Path fabricJson = Dirs.VERSIONS.resolve(fabricId).resolve(fabricId + ".json");
        JsonObject fabric;
        try {
            fabric = Http.json("https://meta.fabricmc.net/v2/versions/loader/" + mc + "/" + loader + "/profile/json");
            Files.createDirectories(fabricJson.getParent());
            Files.writeString(fabricJson, fabric.toString());
        } catch (IOException e) {
            if (!Files.exists(fabricJson)) throw e;
            fabric = JsonParser.parseString(Files.readString(fabricJson)).getAsJsonObject();
        }

        Map<String, Lib> libs = new LinkedHashMap<>();
        collectFabric(fabric, libs);
        collectVanilla(vanilla, libs);

        List<Callable<Void>> libTasks = new ArrayList<>();
        for (Lib lib : libs.values()) {
            libTasks.add(() -> {
                Http.download(lib.url(), Dirs.LIBRARIES.resolve(lib.path()), lib.sha1());
                return null;
            });
        }
        runAll(libTasks, 8, done -> p.update("Libraries " + (int) (done * libTasks.size()) + "/" + libTasks.size(), 0.05 + 0.20 * done));

        JsonObject client = vanilla.getAsJsonObject("downloads").getAsJsonObject("client");
        Path clientJar = Dirs.VERSIONS.resolve(mc).resolve(mc + ".jar");
        p.update("Minecraft " + mc, 0.26);
        Http.download(client.get("url").getAsString(), clientJar, client.get("sha1").getAsString());

        JsonObject assetIndex = vanilla.getAsJsonObject("assetIndex");
        String indexId = assetIndex.get("id").getAsString();
        Path indexFile = Dirs.ASSETS.resolve("indexes").resolve(indexId + ".json");
        p.update("Asset index", 0.34);
        Http.download(assetIndex.get("url").getAsString(), indexFile, assetIndex.get("sha1").getAsString());
        installAssets(JsonParser.parseString(Files.readString(indexFile)).getAsJsonObject(), p);

        p.update("Fabric API and Astra mod", 0.93);
        boolean astra = installMods(mc);
        p.update("Mods from Modrinth", 0.97);
        try {
            new client.astra.addons.Addons(Dirs.instance(mc), mc).syncAll(line -> p.update(line, 0.97));
        } catch (RuntimeException e) {
            // Extra mods are optional: a problem there must never stop the game from starting.
        }

        List<Path> classpath = new ArrayList<>();
        for (Lib lib : libs.values()) classpath.add(Dirs.LIBRARIES.resolve(lib.path()));
        classpath.add(clientJar);

        p.update("Ready", 1.0);
        return new Result(mc, javaMajor, classpath, fabric.get("mainClass").getAsString(), indexId,
                merge(vanilla, fabric, "jvm"), merge(vanilla, fabric, "game"), Dirs.instance(mc), astra);
    }

    private static JsonArray merge(JsonObject vanilla, JsonObject fabric, String key) {
        JsonArray out = new JsonArray();
        for (JsonObject src : new JsonObject[] {vanilla, fabric}) {
            JsonObject args = src.getAsJsonObject("arguments");
            if (args != null && args.has(key)) out.addAll(args.getAsJsonArray(key));
        }
        return out;
    }

    private static void collectVanilla(JsonObject v, Map<String, Lib> out) {
        for (JsonElement e : v.getAsJsonArray("libraries")) {
            JsonObject lib = e.getAsJsonObject();
            if (lib.has("rules") && !Rules.allowed(lib.getAsJsonArray("rules"))) continue;
            JsonObject downloads = lib.getAsJsonObject("downloads");
            if (downloads == null || !downloads.has("artifact")) continue;
            JsonObject a = downloads.getAsJsonObject("artifact");
            out.putIfAbsent(a.get("path").getAsString(), new Lib(a.get("path").getAsString(), a.get("url").getAsString(), a.get("sha1").getAsString()));
        }
    }

    private static void collectFabric(JsonObject f, Map<String, Lib> out) {
        for (JsonElement e : f.getAsJsonArray("libraries")) {
            JsonObject lib = e.getAsJsonObject();
            String path = mavenPath(lib.get("name").getAsString());
            String base = lib.has("url") ? lib.get("url").getAsString() : "https://maven.fabricmc.net/";
            if (!base.endsWith("/")) base += "/";
            String sha = lib.has("sha1") ? lib.get("sha1").getAsString() : null;
            out.putIfAbsent(path, new Lib(path, base + path, sha));
        }
    }

    static String mavenPath(String coords) {
        String[] p = coords.split(":");
        String file = p[1] + "-" + p[2] + (p.length > 3 ? "-" + p[3] : "") + ".jar";
        return p[0].replace('.', '/') + "/" + p[1] + "/" + p[2] + "/" + file;
    }

    private static void installAssets(JsonObject index, Progress p) throws Exception {
        Set<String> hashes = new LinkedHashSet<>();
        for (Map.Entry<String, JsonElement> e : index.getAsJsonObject("objects").entrySet()) {
            hashes.add(e.getValue().getAsJsonObject().get("hash").getAsString());
        }
        List<Callable<Void>> tasks = new ArrayList<>();
        for (String hash : hashes) {
            String prefix = hash.substring(0, 2);
            Path target = Dirs.ASSETS.resolve("objects").resolve(prefix).resolve(hash);
            if (Files.exists(target)) continue;
            tasks.add(() -> {
                Http.download("https://resources.download.minecraft.net/" + prefix + "/" + hash, target, hash);
                return null;
            });
        }
        if (tasks.isEmpty()) return;
        runAll(tasks, 16, done -> p.update("Game assets " + (int) (done * tasks.size()) + "/" + tasks.size(), 0.36 + 0.56 * done));
    }

    /** Fabric API for the version plus the Astra mod when a build exists. Returns true when Astra was installed. */
    private static boolean installMods(String mc) throws IOException {
        Path mods = Dirs.mods(mc);
        Files.createDirectories(mods);

        String api = Versions.fabricApiFor(mc);
        String apiFile = api == null ? null : "fabric-api-" + api + ".jar";
        try (var stream = Files.list(mods)) {
            for (Path old : (Iterable<Path>) stream::iterator) {
                String n = old.getFileName().toString();
                if (n.startsWith("fabric-api-") && !n.equals(apiFile)) Files.deleteIfExists(old);
            }
        }
        if (api != null) {
            Http.download("https://maven.fabricmc.net/net/fabricmc/fabric-api/fabric-api/" + api + "/" + apiFile, mods.resolve(apiFile), null);
        }

        Path target = mods.resolve("astra-client.jar");
        String family = Mods.family(mc);
        String override = System.getProperty("astra.mod." + (family == null ? "none" : family));
        if (override == null) override = System.getProperty("astra.mod");
        if (family == null || api == null || !Mods.available(mc) && override == null) {
            Files.deleteIfExists(target);
            return false;
        }
        if (override != null && !override.isBlank()) {
            Files.copy(Path.of(override), target, StandardCopyOption.REPLACE_EXISTING);
            return true;
        }
        Updates.refreshMod(family);
        try (InputStream in = Mods.open(family)) {
            Files.copy(in, target, StandardCopyOption.REPLACE_EXISTING);
        }
        return true;
    }

    private static void runAll(List<Callable<Void>> tasks, int threads, java.util.function.DoubleConsumer progress) throws Exception {
        ExecutorService pool = Executors.newFixedThreadPool(threads);
        try {
            ExecutorCompletionService<Void> done = new ExecutorCompletionService<>(pool);
            for (Callable<Void> t : tasks) done.submit(t);
            for (int i = 1; i <= tasks.size(); i++) {
                try {
                    done.take().get();
                } catch (ExecutionException e) {
                    throw e.getCause() instanceof Exception ex ? ex : e;
                }
                if (i % 8 == 0 || i == tasks.size()) progress.accept((double) i / tasks.size());
            }
        } finally {
            pool.shutdownNow();
        }
    }

    /** Evaluates Mojang's allow/disallow rule lists for the current OS. Rules with features never match. */
    static final class Rules {
        static boolean allowed(JsonArray rules) {
            boolean allow = false;
            for (JsonElement e : rules) {
                JsonObject r = e.getAsJsonObject();
                boolean matches = !r.has("features");
                if (matches && r.has("os")) {
                    JsonObject os = r.getAsJsonObject("os");
                    if (os.has("name") && !os.get("name").getAsString().equals(Dirs.osName())) matches = false;
                    if (os.has("arch")) {
                        String want = os.get("arch").getAsString();
                        String have = System.getProperty("os.arch", "");
                        boolean arm = have.contains("aarch64") || have.contains("arm");
                        if (want.equals("x86") && Dirs.is64Bit()) matches = false;
                        if ((want.equals("arm64") || want.equals("aarch64")) && !arm) matches = false;
                    }
                }
                if (matches) allow = "allow".equals(r.get("action").getAsString());
            }
            return allow;
        }
    }
}
