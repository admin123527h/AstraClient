package client.astra.launcher;

import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import java.io.IOException;
import java.net.URLEncoder;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;
import java.util.function.BooleanSupplier;

/** Microsoft sign-in with the device code flow, then Xbox Live, XSTS and the Minecraft services. */
public final class MicrosoftAuth {
    public record DeviceCode(String userCode, String verificationUri, String deviceCode, int intervalSeconds, int expiresInSeconds) {}

    /** Raised when the Minecraft services reject an app that Microsoft has not approved yet. */
    public static final class NotApproved extends IOException {
        public NotApproved(String message) {
            super(message);
        }
    }

    /** Receives short progress messages such as "Xbox Live: ok". */
    public static volatile java.util.function.Consumer<String> onStep = s -> { };

    private static final String SCOPE = "XboxLive.signin offline_access";
    private static final String TENANT = "https://login.microsoftonline.com/consumers/oauth2/v2.0/";

    private MicrosoftAuth() {}

    public static DeviceCode requestDeviceCode(String clientId) throws IOException {
        HttpResponse<String> res = Http.postForm(TENANT + "devicecode", "client_id=" + enc(clientId) + "&scope=" + enc(SCOPE));
        JsonObject o = JsonParser.parseString(res.body()).getAsJsonObject();
        if (res.statusCode() != 200) throw new IOException(describe(o, "Could not start the Microsoft sign-in"));
        return new DeviceCode(o.get("user_code").getAsString(), o.get("verification_uri").getAsString(), o.get("device_code").getAsString(),
                o.has("interval") ? o.get("interval").getAsInt() : 5, o.get("expires_in").getAsInt());
    }

    /** Polls until the user has finished signing in in the browser. */
    public static Account completeLogin(String clientId, DeviceCode code, BooleanSupplier cancelled) throws Exception {
        long deadline = System.currentTimeMillis() + code.expiresInSeconds() * 1000L;
        int interval = Math.max(2, code.intervalSeconds());
        while (System.currentTimeMillis() < deadline) {
            if (cancelled.getAsBoolean()) throw new IOException("Sign-in cancelled");
            Thread.sleep(interval * 1000L);
            HttpResponse<String> res = Http.postForm(TENANT + "token", "grant_type=" + enc("urn:ietf:params:oauth:grant-type:device_code")
                    + "&client_id=" + enc(clientId) + "&device_code=" + enc(code.deviceCode()));
            JsonObject o = JsonParser.parseString(res.body()).getAsJsonObject();
            if (o.has("access_token")) return minecraftFrom(o);
            String error = o.has("error") ? o.get("error").getAsString() : "";
            switch (error) {
                case "authorization_pending" -> { }
                case "slow_down" -> interval += 5;
                default -> throw new IOException(describe(o, "Microsoft sign-in failed"));
            }
        }
        throw new IOException("The sign-in code expired. Try again.");
    }

    /**
     * Sign-in through the normal Microsoft page in the browser (authorization code with PKCE, redirect to this
     * computer only). The app registration must list http://localhost as a "Mobile and desktop" redirect URI.
     */
    public static Account loginInBrowser(String clientId, java.util.function.Consumer<String> openUrl, BooleanSupplier cancelled) throws Exception {
        byte[] raw = new byte[48];
        new java.security.SecureRandom().nextBytes(raw);
        String verifier = java.util.Base64.getUrlEncoder().withoutPadding().encodeToString(raw);
        String challenge = java.util.Base64.getUrlEncoder().withoutPadding().encodeToString(
                java.security.MessageDigest.getInstance("SHA-256").digest(verifier.getBytes(StandardCharsets.US_ASCII)));
        String state = Long.toHexString(new java.security.SecureRandom().nextLong());

        java.util.concurrent.CompletableFuture<java.util.Map<String, String>> result = new java.util.concurrent.CompletableFuture<>();
        com.sun.net.httpserver.HttpServer server = com.sun.net.httpserver.HttpServer.create(
                new java.net.InetSocketAddress(java.net.InetAddress.getLoopbackAddress(), 0), 0);
        try {
            server.createContext("/", ex -> {
                java.util.Map<String, String> q = new java.util.HashMap<>();
                String query = ex.getRequestURI().getRawQuery();
                if (query != null) {
                    for (String pair : query.split("&")) {
                        int eq = pair.indexOf('=');
                        if (eq > 0) q.put(java.net.URLDecoder.decode(pair.substring(0, eq), StandardCharsets.UTF_8),
                                java.net.URLDecoder.decode(pair.substring(eq + 1), StandardCharsets.UTF_8));
                    }
                }
                boolean answer = q.containsKey("code") || q.containsKey("error");
                String message = q.containsKey("code") ? "Signed in. You can close this window and go back to Astra."
                        : answer ? "Microsoft refused the sign-in: " + q.getOrDefault("error_description", q.get("error"))
                        : "Waiting for Microsoft...";
                byte[] body = ("<html><body style='background:#120d22;color:#ede9fe;font-family:sans-serif;text-align:center;padding-top:20vh'>"
                        + "<h1>Astra Client</h1><p>" + message.replace("&", "&amp;").replace("<", "&lt;") + "</p></body></html>").getBytes(StandardCharsets.UTF_8);
                ex.getResponseHeaders().add("Content-Type", "text/html; charset=utf-8");
                ex.sendResponseHeaders(200, body.length);
                ex.getResponseBody().write(body);
                ex.close();
                if (answer) result.complete(q);
            });
            server.start();
            String redirect = "http://localhost:" + server.getAddress().getPort();
            openUrl.accept(TENANT + "authorize?client_id=" + enc(clientId) + "&response_type=code&redirect_uri=" + enc(redirect)
                    + "&scope=" + enc(SCOPE) + "&state=" + state + "&prompt=select_account"
                    + "&code_challenge_method=S256&code_challenge=" + challenge);

            long deadline = System.currentTimeMillis() + 5 * 60_000L;
            java.util.Map<String, String> q = null;
            while (q == null) {
                if (cancelled.getAsBoolean()) throw new IOException("Sign-in cancelled");
                if (System.currentTimeMillis() > deadline) throw new IOException("No answer from the browser after 5 minutes. Try again.");
                try {
                    q = result.get(500, java.util.concurrent.TimeUnit.MILLISECONDS);
                } catch (java.util.concurrent.TimeoutException ignored) {
                }
            }
            if (!q.containsKey("code")) throw new IOException("Microsoft refused the sign-in: " + q.getOrDefault("error_description", q.get("error")));
            if (!state.equals(q.get("state"))) throw new IOException("The sign-in answer did not match this request. Try again.");
            HttpResponse<String> res = Http.postForm(TENANT + "token", "grant_type=authorization_code&client_id=" + enc(clientId)
                    + "&code=" + enc(q.get("code")) + "&redirect_uri=" + enc(redirect) + "&code_verifier=" + enc(verifier) + "&scope=" + enc(SCOPE));
            JsonObject o = JsonParser.parseString(res.body()).getAsJsonObject();
            if (!o.has("access_token")) throw new IOException(describe(o, "Microsoft sign-in failed"));
            return minecraftFrom(o);
        } finally {
            server.stop(0);
        }
    }

    /** Signs in again with the stored refresh token. */
    public static Account refresh(Config cfg) throws Exception {
        String clientId = cfg.effectiveAzureClientId();
        if (cfg.msRefreshToken.isBlank() || clientId.isBlank()) throw new IOException("Not signed in");
        HttpResponse<String> res = Http.postForm(TENANT + "token", "grant_type=refresh_token&client_id=" + enc(clientId)
                + "&refresh_token=" + enc(cfg.msRefreshToken) + "&scope=" + enc(SCOPE));
        JsonObject o = JsonParser.parseString(res.body()).getAsJsonObject();
        if (!o.has("access_token")) throw new IOException(describe(o, "Your Microsoft session expired. Please sign in again."));
        return minecraftFrom(o);
    }

    private static Account minecraftFrom(JsonObject msToken) throws IOException {
        Config cfg = Config.get();
        String msAccess = msToken.get("access_token").getAsString();
        if (msToken.has("refresh_token")) cfg.msRefreshToken = msToken.get("refresh_token").getAsString();

        JsonObject xblBody = new JsonObject();
        JsonObject xblProps = new JsonObject();
        xblProps.addProperty("AuthMethod", "RPS");
        xblProps.addProperty("SiteName", "user.auth.xboxlive.com");
        xblProps.addProperty("RpsTicket", "d=" + msAccess);
        xblBody.add("Properties", xblProps);
        xblBody.addProperty("RelyingParty", "http://auth.xboxlive.com");
        xblBody.addProperty("TokenType", "JWT");
        JsonObject xbl = postJson("https://user.auth.xboxlive.com/user/authenticate", xblBody, "Xbox Live sign-in failed");
        onStep.accept("Microsoft: ok. Xbox Live: ok.");
        String xblToken = xbl.get("Token").getAsString();

        JsonObject xstsBody = new JsonObject();
        JsonObject xstsProps = new JsonObject();
        xstsProps.addProperty("SandboxId", "RETAIL");
        JsonArray tokens = new JsonArray();
        tokens.add(xblToken);
        xstsProps.add("UserTokens", tokens);
        xstsBody.add("Properties", xstsProps);
        xstsBody.addProperty("RelyingParty", "rp://api.minecraftservices.com/");
        xstsBody.addProperty("TokenType", "JWT");
        HttpResponse<String> xstsRes = Http.postJson("https://xsts.auth.xboxlive.com/xsts/authorize", xstsBody.toString());
        JsonObject xsts = JsonParser.parseString(xstsRes.body()).getAsJsonObject();
        if (xstsRes.statusCode() != 200) throw new IOException(xstsError(xsts));
        onStep.accept("Microsoft: ok. Xbox Live: ok. Xbox security: ok.");
        String uhs = xsts.getAsJsonObject("DisplayClaims").getAsJsonArray("xui").get(0).getAsJsonObject().get("uhs").getAsString();

        JsonObject mcBody = new JsonObject();
        mcBody.addProperty("identityToken", "XBL3.0 x=" + uhs + ";" + xsts.get("Token").getAsString());
        HttpResponse<String> mcRes = Http.postJson("https://api.minecraftservices.com/authentication/login_with_xbox", mcBody.toString());
        if (mcRes.statusCode() == 403) {
            String detail = "";
            try {
                JsonObject body = JsonParser.parseString(mcRes.body()).getAsJsonObject();
                if (body.has("errorMessage")) detail = body.get("errorMessage").getAsString();
            } catch (RuntimeException ignored) {
            }
            throw new NotApproved("Microsoft, Xbox and Xbox security worked, but Minecraft refused the sign-in (403)"
                    + (detail.isEmpty() ? "." : ": " + detail)
                    + " Your Azure app is not approved for Minecraft yet. Microsoft has to approve it first.");
        }
        if (mcRes.statusCode() != 200) throw new IOException("Minecraft sign-in failed (HTTP " + mcRes.statusCode() + ")");
        String mcToken = JsonParser.parseString(mcRes.body()).getAsJsonObject().get("access_token").getAsString();

        HttpResponse<String> profile = Http.getWith("https://api.minecraftservices.com/minecraft/profile", "Authorization", "Bearer " + mcToken);
        if (profile.statusCode() == 404) throw new IOException("This Microsoft account does not own Minecraft: Java Edition.");
        if (profile.statusCode() != 200) throw new IOException("Could not read the Minecraft profile (HTTP " + profile.statusCode() + ")");
        JsonObject p = JsonParser.parseString(profile.body()).getAsJsonObject();

        cfg.useMicrosoft = true;
        cfg.msName = p.get("name").getAsString();
        cfg.msUuid = p.get("id").getAsString();
        cfg.save();
        return new Account(cfg.msName, cfg.msUuid, mcToken, true);
    }

    private static JsonObject postJson(String url, JsonObject body, String failure) throws IOException {
        HttpResponse<String> res = Http.postJson(url, body.toString());
        if (res.statusCode() != 200) throw new IOException(failure + " (HTTP " + res.statusCode() + ")");
        return JsonParser.parseString(res.body()).getAsJsonObject();
    }

    private static String xstsError(JsonObject o) {
        long code = o.has("XErr") ? o.get("XErr").getAsLong() : 0;
        if (code == 2148916233L) return "This Microsoft account has no Xbox profile. Sign in once at xbox.com to create it.";
        if (code == 2148916238L) return "This is a child account. An adult must add it to a Microsoft family first.";
        if (code == 2148916235L) return "Xbox Live is not available in your country or region.";
        return "Xbox sign-in failed (XErr " + code + ").";
    }

    private static String describe(JsonObject o, String fallback) {
        String desc = o.has("error_description") ? o.get("error_description").getAsString() : "";
        return desc.isBlank() ? fallback : fallback + ": " + desc.split("\\r?\\n")[0];
    }

    private static String enc(String s) {
        return URLEncoder.encode(s, StandardCharsets.UTF_8);
    }
}
