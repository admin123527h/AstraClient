package client.astra.launcher;

import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import java.io.IOException;
import java.io.InputStream;
import java.net.URI;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.function.Consumer;

/**
 * Live updates. A small manifest (update/manifest.json in the project's GitHub repository) lists the newest build of
 * every mod jar and of the launcher itself. Mod jars are replaced at launch time; a new launcher is downloaded once and
 * used from the next start of the launcher on (see Boot). Everything is optional: with no internet the bundled
 * versions are used.
 */
public final class Updates {
    public static final String DEFAULT_URL = "https://raw.githubusercontent.com/admin123527h/AstraClient/main/update/manifest.json";

    private static final Path STATE = Dirs.UPDATES.resolve("state.json");

    private Updates() {}

    public static String manifestUrl() {
        String url = System.getProperty("astra.updateUrl");
        if (url == null || url.isBlank()) url = Config.get().updateUrl;
        if (url != null && !url.isBlank()) return url;
        Path local = localManifest();
        return local != null ? local.toUri().toString() : DEFAULT_URL;
    }

    /**
     * An update folder next to the launcher wins over the internet: put the "update" folder (from AstraUpdate.zip)
     * into the AstraClient folder, restart the launcher, and the new build is used.
     */
    static Path localManifest() {
        java.util.List<Path> places = new java.util.ArrayList<>();
        places.add(Path.of("update", "manifest.json"));
        String cp = System.getProperty("java.class.path", "");
        if (!cp.isBlank()) {
            Path jar = Path.of(cp.split(java.io.File.pathSeparator)[0]).toAbsolutePath();
            if (jar.getParent() != null) places.add(jar.getParent().resolve("update").resolve("manifest.json"));
        }
        places.add(Path.of(System.getProperty("user.home", "."), "Documents", "AstraClient", "update", "manifest.json"));
        for (Path p : places) {
            if (Files.isRegularFile(p)) return p.toAbsolutePath();
        }
        return null;
    }

    /** Build number of the running launcher (minutes since 1970 at the time it was built). */
    public static long launcherBuild() {
        return readBuild(Updates.class.getResourceAsStream("/launcher.build"));
    }

    private static long readBuild(InputStream in) {
        if (in == null) return 0;
        try (in) {
            return Long.parseLong(new String(in.readAllBytes(), StandardCharsets.UTF_8).trim());
        } catch (IOException | NumberFormatException e) {
            return 0;
        }
    }

    // ---- manifest access ----

    private static byte[] fetch(String url) throws IOException {
        if (url.startsWith("file:")) return Files.readAllBytes(Path.of(URI.create(url)));
        return Http.get(url).getBytes(StandardCharsets.UTF_8);
    }

    private static JsonObject manifest() throws IOException {
        return JsonParser.parseString(new String(fetch(manifestUrl()), StandardCharsets.UTF_8)).getAsJsonObject();
    }

    private static void download(String relative, Path target, String sha1) throws IOException {
        String url = URI.create(manifestUrl()).resolve(relative).toString();
        if (url.startsWith("file:")) {
            Files.createDirectories(target.getParent());
            Path tmp = target.resolveSibling(target.getFileName() + ".part");
            Files.copy(Path.of(URI.create(url)), tmp, java.nio.file.StandardCopyOption.REPLACE_EXISTING);
            if (sha1 != null && !sha1.equalsIgnoreCase(Http.sha1(tmp))) throw new IOException("checksum mismatch for " + relative);
            Files.move(tmp, target, java.nio.file.StandardCopyOption.REPLACE_EXISTING);
            return;
        }
        Path tmp = target.resolveSibling(target.getFileName() + ".new");
        Files.deleteIfExists(tmp);
        Http.download(url, tmp, sha1);
        Files.move(tmp, target, java.nio.file.StandardCopyOption.REPLACE_EXISTING);
    }

    // ---- remembered builds ----

    private static synchronized JsonObject state() {
        try {
            if (Files.exists(STATE)) return JsonParser.parseString(Files.readString(STATE)).getAsJsonObject();
        } catch (IOException | RuntimeException ignored) {
        }
        return new JsonObject();
    }

    private static synchronized void remember(String group, String key, long build) {
        JsonObject s = state();
        JsonObject g = s.has(group) ? s.getAsJsonObject(group) : new JsonObject();
        g.addProperty(key, build);
        s.add(group, g);
        try {
            Files.createDirectories(STATE.getParent());
            Files.writeString(STATE, s.toString());
        } catch (IOException ignored) {
        }
    }

    private static long known(String group, String key) {
        JsonObject s = state();
        return s.has(group) && s.getAsJsonObject(group).has(key) ? s.getAsJsonObject(group).get(key).getAsLong() : 0;
    }

    // ---- shared defaults (app IDs shipped with the project, so players do not have to enter any) ----

    /** An ID the project ships in the manifest ("defaults" block), or "" when there is none. */
    public static String defaultId(String key) {
        JsonObject s = state();
        return s.has("defaults") && s.getAsJsonObject("defaults").has(key) ? s.getAsJsonObject("defaults").get(key).getAsString() : "";
    }

    private static synchronized void rememberDefaults(JsonObject defaults) {
        JsonObject s = state();
        s.add("defaults", defaults);
        try {
            Files.createDirectories(STATE.getParent());
            Files.writeString(STATE, s.toString());
        } catch (IOException ignored) {
        }
    }

    /** Reads the manifest's shared IDs. Returns true when a Microsoft ID is available afterwards. */
    public static boolean refreshDefaults() {
        try {
            JsonObject m = manifest();
            if (m.has("defaults")) rememberDefaults(m.getAsJsonObject("defaults"));
        } catch (IOException | RuntimeException ignored) {
        }
        return !defaultId("microsoftClientId").isEmpty();
    }

    // ---- updates ----

    /** Fetches the newest jar of one mod family when the manifest has a newer build. Returns a message or null. */
    public static String refreshMod(String family) {
        try {
            JsonObject entry = manifest().getAsJsonObject("mods").getAsJsonObject(family);
            if (entry == null) return null;
            long build = entry.get("build").getAsLong();
            Path jar = Mods.cached(family);
            if (build <= known("mods", family) && Files.exists(jar)) return null;
            download(entry.get("url").getAsString(), jar, entry.get("sha1").getAsString());
            remember("mods", family, build);
            return "Astra mod " + family + " updated (build " + build + ")";
        } catch (IOException | RuntimeException e) {
            return null;
        }
    }

    /** Downloads a newer launcher when there is one; Boot uses it the next time the launcher starts. */
    public static String refreshCore() {
        try {
            JsonObject core = manifest().getAsJsonObject("core");
            if (core == null) return null;
            long build = core.get("build").getAsLong();
            if (build <= launcherBuild() || build <= known("core", "build")) return null;
            Path jar = Dirs.UPDATES.resolve("core.jar");
            download(core.get("url").getAsString(), jar, core.get("sha1").getAsString());
            Files.writeString(Dirs.UPDATES.resolve("core.build"), Long.toString(build));
            remember("core", "build", build);
            return "A launcher update was downloaded. Restart the launcher to use it.";
        } catch (IOException | RuntimeException e) {
            return null;
        }
    }

    /** Runs both checks on a background thread and reports anything that changed. */
    public static void checkInBackground(Consumer<String> report) {
        Thread t = new Thread(() -> {
            refreshDefaults();
            String core = refreshCore();
            if (core != null) report.accept(core);
            for (String family : new String[] {"26.3", "26.2", "26.1", "1.21.11"}) {
                String mod = refreshMod(family);
                if (mod != null) report.accept(mod);
            }
        }, "astra-updates");
        t.setDaemon(true);
        t.start();
    }
}
