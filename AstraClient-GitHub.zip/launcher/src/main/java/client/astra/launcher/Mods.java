package client.astra.launcher;

import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Path;

/** Which Astra mod build belongs to a Minecraft version, and where its jar comes from. */
public final class Mods {
    private Mods() {}

    /**
     * Each family is one Astra mod jar: "1.21.11", "26.1" (26.1, 26.1.1, 26.1.2), "26.2", and "26.3" for 26.3 and
     * every newer 26.x release. Null means no Astra mod yet.
     */
    public static String family(String mc) {
        if (mc.equals("1.21.11")) return "1.21.11";
        java.util.regex.Matcher m = java.util.regex.Pattern.compile("26\\.(\\d+)(\\.\\d+)?").matcher(mc);
        if (!m.matches()) return null;
        int minor = Integer.parseInt(m.group(1));
        if (minor <= 1) return "26.1";
        if (minor == 2) return "26.2";
        return "26.3";
    }

    public static boolean available(String mc) {
        String family = family(mc);
        if (family == null) return false;
        return Files.exists(cached(family)) || Mods.class.getResource("/astra-mod-" + family + ".jar") != null;
    }

    public static Path cached(String family) {
        return Dirs.UPDATES.resolve("mods").resolve("astra-" + family + ".jar");
    }

    /** The newest jar: a downloaded update wins over the one bundled in the launcher. */
    public static InputStream open(String family) throws IOException {
        Path update = cached(family);
        if (Files.exists(update)) return Files.newInputStream(update);
        InputStream in = Mods.class.getResourceAsStream("/astra-mod-" + family + ".jar");
        if (in == null) throw new IOException("The Astra mod for this version is not bundled in this launcher build");
        return in;
    }
}
