package client.astra.launcher;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import java.io.IOException;
import java.nio.file.Files;

public final class Config {
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static Config instance;

    public int ramMb = 4096;
    public String mcVersion = "";
    /** Where the update manifest lives; empty means the default. */
    public String updateUrl = "";
    public String javaPath = "";
    public String azureClientId = "";

    /** The player's own ID if one was typed, else the one shipped with the project's update manifest. */
    public String effectiveAzureClientId() {
        if (azureClientId != null && !azureClientId.isBlank()) return azureClientId.trim();
        return Updates.defaultId("microsoftClientId");
    }
    public String offlineName = "Player";
    public boolean useMicrosoft = false;
    public String msName = "";
    public String msUuid = "";
    public String msRefreshToken = "";

    public static synchronized Config get() {
        if (instance == null) {
            try {
                instance = Files.exists(Dirs.CONFIG) ? GSON.fromJson(Files.readString(Dirs.CONFIG), Config.class) : new Config();
            } catch (IOException | RuntimeException e) {
                instance = new Config();
            }
            if (instance == null) instance = new Config();
        }
        return instance;
    }

    public synchronized void save() {
        try {
            Files.createDirectories(Dirs.ROOT);
            Files.writeString(Dirs.CONFIG, GSON.toJson(this));
        } catch (IOException ignored) {
        }
    }
}
