package client.astra.launcher;

/** Headless mode: installs, then launches with an offline account. Used for testing without the window. */
public final class Cli {
    private Cli() {}

    public static void run(String name, String mc) throws Exception {
        Install.Progress progress = (text, f) -> System.out.printf("[%3d%%] %s%n", (int) (f * 100), text);
        Install.Result result = Install.run(mc, progress);
        var java = JavaRuntime.find(Config.get(), result.javaMajor(), progress);
        System.out.println("Java: " + java + " (needs " + result.javaMajor() + "), Astra mod: " + result.astraMod());
        Process p = GameLauncher.launch(result, Account.offline(name), Config.get(), java, line -> System.out.println("[game] " + line));
        System.exit(p.waitFor());
    }
}
