package client.astra.launcher;

import java.nio.file.Path;

public final class Dirs {
    public static final Path ROOT = root();
    public static final Path LIBRARIES = ROOT.resolve("libraries");
    public static final Path ASSETS = ROOT.resolve("assets");
    public static final Path VERSIONS = ROOT.resolve("versions");
    public static final Path RUNTIME = ROOT.resolve("runtime");
    public static final Path INSTANCES = ROOT.resolve("instances");
    public static final Path CACHE = ROOT.resolve("cache");
    public static final Path UPDATES = ROOT.resolve("updates");
    public static final Path CONFIG = ROOT.resolve("launcher.json");

    private Dirs() {}

    private static Path root() {
        String override = System.getProperty("astra.home");
        if (override != null && !override.isBlank()) return Path.of(override);
        String os = System.getProperty("os.name", "").toLowerCase();
        String home = System.getProperty("user.home");
        if (os.contains("win")) {
            String appData = System.getenv("APPDATA");
            return Path.of(appData != null ? appData : home, ".astra");
        }
        if (os.contains("mac")) return Path.of(home, "Library", "Application Support", "astra");
        return Path.of(home, ".astra");
    }

    public static Path instance(String mc) {
        return INSTANCES.resolve(mc);
    }

    public static Path mods(String mc) {
        return instance(mc).resolve("mods");
    }

    public static String osName() {
        String os = System.getProperty("os.name", "").toLowerCase();
        if (os.contains("win")) return "windows";
        if (os.contains("mac")) return "osx";
        return "linux";
    }

    public static boolean is64Bit() {
        return System.getProperty("os.arch", "").contains("64");
    }
}
