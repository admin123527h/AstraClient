package client.astra.launcher;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** Which Minecraft versions can be played, and which Fabric loader and Fabric API go with each. */
public final class Versions {
    /** Offline fallback shown before the network list arrives. */
    public static final List<String> BUILT_IN = List.of("26.3", "26.2", "26.1.2", "26.1.1", "26.1", "1.21.11");

    private static final String DEFAULT_LOADER = "0.20.1";

    private Versions() {}

    /** Newest first: 26.x and 1.21.x releases that Fabric supports. */
    public static List<String> available() throws IOException {
        JsonObject manifest = Http.json("https://piston-meta.mojang.com/mc/game/version_manifest_v2.json");
        Set<String> fabric = new HashSet<>();
        for (JsonElement e : Http.getArray("https://meta.fabricmc.net/v2/versions/game")) {
            JsonObject o = e.getAsJsonObject();
            if (o.get("stable").getAsBoolean()) fabric.add(o.get("version").getAsString());
        }
        List<String> out = new ArrayList<>();
        for (JsonElement e : manifest.getAsJsonArray("versions")) {
            JsonObject v = e.getAsJsonObject();
            String id = v.get("id").getAsString();
            if (!"release".equals(v.get("type").getAsString()) || !fabric.contains(id)) continue;
            if (id.startsWith("26.") || id.startsWith("1.21")) out.add(id);
        }
        return out;
    }

    public static String loaderFor(String mc) {
        try {
            JsonArray arr = Http.getArray("https://meta.fabricmc.net/v2/versions/loader/" + mc);
            for (JsonElement e : arr) {
                JsonObject l = e.getAsJsonObject().getAsJsonObject("loader");
                if (l.get("stable").getAsBoolean()) {
                    String v = l.get("version").getAsString();
                    remember(mc, "loader", v);
                    return v;
                }
            }
        } catch (IOException ignored) {
        }
        String cached = recall(mc, "loader");
        return cached != null ? cached : DEFAULT_LOADER;
    }

    /** Newest Fabric API build for this game version, or null when none exists. */
    public static String fabricApiFor(String mc) {
        try {
            String xml = Http.get("https://maven.fabricmc.net/net/fabricmc/fabric-api/fabric-api/maven-metadata.xml");
            Matcher m = Pattern.compile("<version>([^<]+\\+" + Pattern.quote(mc) + ")</version>").matcher(xml);
            String best = null;
            while (m.find()) {
                if (best == null || compare(m.group(1), best) > 0) best = m.group(1);
            }
            if (best != null) {
                remember(mc, "api", best);
                return best;
            }
        } catch (IOException ignored) {
            return recall(mc, "api");
        }
        return null;
    }

    static int compare(String a, String b) {
        String[] x = a.split("\\+")[0].split("\\.");
        String[] y = b.split("\\+")[0].split("\\.");
        for (int i = 0; i < Math.max(x.length, y.length); i++) {
            int p = i < x.length ? parse(x[i]) : 0;
            int q = i < y.length ? parse(y[i]) : 0;
            if (p != q) return Integer.compare(p, q);
        }
        return 0;
    }

    private static int parse(String s) {
        try {
            return Integer.parseInt(s);
        } catch (NumberFormatException e) {
            return 0;
        }
    }

    private static void remember(String mc, String key, String value) {
        try {
            Files.createDirectories(Dirs.CACHE);
            Path f = Dirs.CACHE.resolve(mc + "." + key);
            Files.writeString(f, value);
        } catch (IOException ignored) {
        }
    }

    private static String recall(String mc, String key) {
        try {
            Path f = Dirs.CACHE.resolve(mc + "." + key);
            return Files.exists(f) ? Files.readString(f).trim() : null;
        } catch (IOException e) {
            return null;
        }
    }
}
