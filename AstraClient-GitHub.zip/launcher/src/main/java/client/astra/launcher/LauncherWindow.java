package client.astra.launcher;

import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JComponent;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.SwingUtilities;
import java.awt.BasicStroke;
import java.awt.BorderLayout;
import java.awt.CardLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Cursor;
import java.awt.Desktop;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.FontMetrics;
import java.awt.GradientPaint;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Point;
import java.awt.RadialGradientPaint;
import java.awt.Toolkit;
import java.awt.datatransfer.StringSelection;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.geom.RoundRectangle2D;
import java.net.URI;
import java.nio.file.Files;
import java.util.List;
import java.util.Random;

final class LauncherWindow extends JFrame {
    private static final int W = 980, H = 600;
    private static final String[] PAGES = {"Play", "Account", "Settings", "Console"};

    private final Config cfg = Config.get();
    private final CardLayout cards = new CardLayout();
    private final JPanel content = new JPanel(cards);
    private final Nav[] navs = new Nav[PAGES.length];
    private final Widgets.Bar bar = new Widgets.Bar();
    private final JLabel status = label("Ready to play", 13f, Theme.DIM);
    private final JLabel accountLine = label("", 13f, Theme.DIM);
    private final JTextArea console = new JTextArea();
    private final JLabel msStatus = label("", 13f, Theme.DIM);
    private Widgets.Button play;
    private Widgets.Picker picker;
    private boolean busy;
    private volatile boolean cancelLogin;
    private Point dragFrom;

    LauncherWindow() {
        super("Astra Launcher");
        java.net.URL iconUrl = LauncherWindow.class.getResource("/icons/astra.png");
        if (iconUrl != null) setIconImage(new javax.swing.ImageIcon(iconUrl).getImage());
        setUndecorated(true);
        Updates.checkInBackground(message -> { log(message); setStatus(message, -1, false); });
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setSize(W, H);
        setLocationRelativeTo(null);
        try {
            setShape(new RoundRectangle2D.Double(0, 0, W, H, 30, 30));
        } catch (RuntimeException ignored) {
        }

        Sky sky = new Sky();
        sky.setLayout(new BorderLayout());
        setContentPane(sky);
        sky.add(sidebar(), BorderLayout.WEST);

        JPanel right = new JPanel(new BorderLayout());
        right.setOpaque(false);
        right.add(topBar(), BorderLayout.NORTH);
        content.setOpaque(false);
        content.add(playPage(), PAGES[0]);
        content.add(accountPage(), PAGES[1]);
        content.add(settingsPage(), PAGES[2]);
        content.add(consolePage(), PAGES[3]);
        right.add(content, BorderLayout.CENTER);
        sky.add(right, BorderLayout.CENTER);

        MouseAdapter drag = new MouseAdapter() {
            @Override public void mousePressed(MouseEvent e) { dragFrom = e.getPoint(); }
            @Override public void mouseDragged(MouseEvent e) {
                if (dragFrom != null) setLocation(e.getXOnScreen() - dragFrom.x, e.getYOnScreen() - dragFrom.y);
            }
        };
        sky.addMouseListener(drag);
        sky.addMouseMotionListener(drag);
        refreshAccountLine();
        show(0);

        // the sky and the glow effects animate: ~30 frames a second while you look at it, slower in the background
        javax.swing.Timer animation = new javax.swing.Timer(33, null);
        animation.addActionListener(e -> {
            animation.setDelay(isActive() && !isIconified() ? 33 : 160);
            repaint();
        });
        animation.start();
    }

    private boolean isIconified() {
        return (getExtendedState() & ICONIFIED) != 0;
    }

    // ---- layout pieces ----

    private JComponent sidebar() {
        Widgets.Glass side = new Widgets.Glass(28);
        side.setLayout(new BoxLayout(side, BoxLayout.Y_AXIS));
        side.setBorder(BorderFactory.createEmptyBorder(22, 16, 16, 16));
        side.setPreferredSize(new Dimension(224, H));

        JComponent brand = new JComponent() {
            @Override protected void paintComponent(Graphics g0) {
                Graphics2D g = (Graphics2D) g0.create();
                Theme.quality(g);
                g.setRenderingHint(java.awt.RenderingHints.KEY_INTERPOLATION, java.awt.RenderingHints.VALUE_INTERPOLATION_BICUBIC);
                java.awt.image.BufferedImage img = logo();
                float pulse = 0.5f + 0.5f * (float) Math.sin(Fx.time() * 1.5f);
                g.setPaint(new RadialGradientPaint(22, 22, 34, new float[] {0f, 1f},
                        new Color[] {new Color(190, 130, 255, (int) (60 + 40 * pulse)), new Color(190, 130, 255, 0)}));
                g.fillRect(-14, -14, 72, 72);
                if (img != null) g.drawImage(img, 0, 0, 44, 44, null);
                g.setColor(Theme.TEXT);
                g.setFont(Theme.font(21f));
                g.drawString("Astra", 56, 21);
                g.setColor(Theme.ACCENT);
                g.setFont(Theme.font(10.5f));
                g.drawString("L A U N C H E R", 57, 37);
                g.dispose();
            }
        };
        brand.setMaximumSize(new Dimension(190, 46));
        brand.setPreferredSize(new Dimension(190, 46));
        brand.setAlignmentX(Component.LEFT_ALIGNMENT);
        side.add(brand);
        side.add(Box.createVerticalStrut(30));

        int[] icons = {Icons.PLAY, Icons.USER, Icons.GEAR, Icons.TERMINAL};
        for (int i = 0; i < PAGES.length; i++) {
            final int index = i;
            navs[i] = new Nav(PAGES[i], icons[i], () -> show(index));
            navs[i].setAlignmentX(Component.LEFT_ALIGNMENT);
            side.add(navs[i]);
            side.add(Box.createVerticalStrut(6));
        }
        side.add(Box.createVerticalGlue());
        side.add(new AccountChip());
        side.add(Box.createVerticalStrut(10));
        JLabel version = label("Build " + Updates.launcherBuild() % 100000, 10.5f, Theme.DIM);
        version.setAlignmentX(Component.LEFT_ALIGNMENT);
        side.add(version);

        JPanel wrap = new JPanel(new BorderLayout());
        wrap.setOpaque(false);
        wrap.setBorder(BorderFactory.createEmptyBorder(14, 14, 14, 0));
        wrap.add(side);
        return wrap;
    }

    private JComponent topBar() {
        JPanel top = new JPanel(new FlowLayout(FlowLayout.RIGHT, 8, 12));
        top.setOpaque(false);
        top.setPreferredSize(new Dimension(10, 48));
        top.add(windowButton(false, () -> setState(ICONIFIED)));
        top.add(windowButton(true, () -> System.exit(0)));
        return top;
    }

    private JComponent windowButton(boolean close, Runnable action) {
        JComponent b = new JComponent() {
            private boolean hover;
            {
                setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
                addMouseListener(new MouseAdapter() {
                    @Override public void mouseEntered(MouseEvent e) { hover = true; repaint(); }
                    @Override public void mouseExited(MouseEvent e) { hover = false; repaint(); }
                    @Override public void mouseClicked(MouseEvent e) { action.run(); }
                });
            }
            @Override protected void paintComponent(Graphics g0) {
                Graphics2D g = (Graphics2D) g0.create();
                Theme.quality(g);
                g.setColor(new Color(255, 255, 255, hover ? 60 : 24));
                g.fillOval(0, 0, getWidth() - 1, getHeight() - 1);
                g.setColor(Color.WHITE);
                g.setStroke(new BasicStroke(1.6f, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND));
                int cx = getWidth() / 2, cy = getHeight() / 2;
                if (close) {
                    g.drawLine(cx - 4, cy - 4, cx + 4, cy + 4);
                    g.drawLine(cx - 4, cy + 4, cx + 4, cy - 4);
                } else {
                    g.drawLine(cx - 5, cy, cx + 5, cy);
                }
                g.dispose();
            }
        };
        b.setPreferredSize(new Dimension(26, 26));
        return b;
    }

    // ---- pages ----

    private JComponent playPage() {
        JPanel p = new JPanel();
        p.setOpaque(false);
        p.setLayout(new BoxLayout(p, BoxLayout.Y_AXIS));
        p.setBorder(BorderFactory.createEmptyBorder(0, 20, 18, 30));

        p.add(Box.createVerticalGlue());
        p.add(center(new Hero()));
        p.add(Box.createVerticalStrut(12));

        Widgets.Glass card = new Widgets.Glass(32);
        card.setLayout(new BoxLayout(card, BoxLayout.Y_AXIS));
        card.setBorder(BorderFactory.createEmptyBorder(20, 28, 18, 28));
        card.setPreferredSize(new Dimension(500, 206));
        card.setMaximumSize(new Dimension(500, 206));

        picker = new Widgets.Picker(this::versionLabel, id -> { cfg.mcVersion = id; cfg.save(); });
        picker.setItems(Versions.BUILT_IN, currentVersion());
        picker.setPreferredSize(new Dimension(444, 40));
        picker.setMaximumSize(new Dimension(444, 40));
        card.add(center(picker));
        card.add(Box.createVerticalStrut(10));
        loadVersions();

        play = new Widgets.Button("PLAY", true, this::startGame);
        play.setPreferredSize(new Dimension(444, 66));
        play.setMaximumSize(new Dimension(444, 66));
        card.add(center(play));
        card.add(Box.createVerticalStrut(8));

        bar.setPreferredSize(new Dimension(444, 8));
        bar.setMaximumSize(new Dimension(444, 8));
        card.add(center(bar));
        card.add(Box.createVerticalStrut(10));
        card.add(center(status));
        p.add(center(card));
        p.add(Box.createVerticalStrut(14));

        JPanel cards = new JPanel(new FlowLayout(FlowLayout.CENTER, 12, 0));
        cards.setOpaque(false);
        cards.add(new FeatureCard("Animated skies", "16 shader skies", Icons.SKY));
        cards.add(new FeatureCard("Lyrics in 3D", "word by word", Icons.NOTE));
        cards.add(new FeatureCard("Mods and items", "one click", Icons.CUBE));
        p.add(center(cards));
        p.add(Box.createVerticalGlue());
        return p;
    }

    private JComponent accountPage() {
        JPanel page = pageShell("Account", "Sign in with Microsoft to play on servers, or use an offline name to test.");
        Widgets.Glass card = new Widgets.Glass(22);
        card.setLayout(new BoxLayout(card, BoxLayout.Y_AXIS));
        card.setBorder(BorderFactory.createEmptyBorder(18, 20, 18, 20));

        card.add(left(label("MICROSOFT", 11f, Theme.ACCENT)));
        card.add(Box.createVerticalStrut(8));
        card.add(left(label("Application (client) ID. Leave empty to use the one that comes with Astra.", 12f, Theme.DIM)));
        Widgets.Field clientId = new Widgets.Field(cfg.azureClientId);
        clientId.setMaximumSize(new Dimension(Integer.MAX_VALUE, 38));
        clientId.setAlignmentX(Component.LEFT_ALIGNMENT);
        clientId.getDocument().addDocumentListener((SimpleDoc) () -> { cfg.azureClientId = clientId.getText().trim(); cfg.save(); });
        card.add(clientId);
        card.add(Box.createVerticalStrut(6));
        JLabel help = label("<html>Register a free app in the Azure portal (personal accounts, public client) and ask Microsoft to approve it for the Minecraft API (aka.ms/mce-reviewappid). Until it is approved, sign-in stops at the Minecraft step.</html>", 11f, Theme.DIM);
        help.setAlignmentX(Component.LEFT_ALIGNMENT);
        card.add(help);
        card.add(Box.createVerticalStrut(10));

        JPanel row = new JPanel(new FlowLayout(FlowLayout.LEFT, 0, 0));
        row.setOpaque(false);
        row.setAlignmentX(Component.LEFT_ALIGNMENT);
        Widgets.Button signIn = new Widgets.Button("Sign in with Microsoft", false, this::microsoftSignIn);
        signIn.setPreferredSize(new Dimension(190, 34));
        Widgets.Button useCode = new Widgets.Button("Use a code", false, () -> signInWith(false));
        useCode.setPreferredSize(new Dimension(120, 34));
        Widgets.Button signOut = new Widgets.Button("Sign out", false, () -> {
            cancelLogin = true;
            cfg.useMicrosoft = false;
            cfg.msRefreshToken = "";
            cfg.msName = "";
            cfg.msUuid = "";
            cfg.save();
            msStatus.setText("Signed out");
            refreshAccountLine();
        });
        signOut.setPreferredSize(new Dimension(92, 34));
        Widgets.Button approval = new Widgets.Button("Request approval", false, () -> {
            try {
                Desktop.getDesktop().browse(URI.create("https://aka.ms/mce-reviewappid"));
            } catch (Exception e) {
                msStatus.setText("Open aka.ms/mce-reviewappid in your browser.");
            }
        });
        approval.setPreferredSize(new Dimension(140, 34));
        row.add(signIn);
        row.add(Box.createHorizontalStrut(8));
        row.add(useCode);
        row.add(Box.createHorizontalStrut(8));
        row.add(signOut);
        row.add(Box.createHorizontalStrut(8));
        row.add(approval);
        card.add(row);
        card.add(Box.createVerticalStrut(8));
        msStatus.setAlignmentX(Component.LEFT_ALIGNMENT);
        msStatus.setText(cfg.msName.isBlank() ? "Not signed in" : "Signed in as " + cfg.msName);
        card.add(msStatus);

        card.add(Box.createVerticalStrut(20));
        card.add(left(label("OFFLINE", 11f, Theme.ACCENT)));
        card.add(Box.createVerticalStrut(8));
        card.add(left(label("Offline name (cannot join online servers)", 12f, Theme.DIM)));
        Widgets.Field offline = new Widgets.Field(cfg.offlineName);
        offline.setMaximumSize(new Dimension(Integer.MAX_VALUE, 38));
        offline.setAlignmentX(Component.LEFT_ALIGNMENT);
        offline.getDocument().addDocumentListener((SimpleDoc) () -> { cfg.offlineName = offline.getText().trim(); cfg.save(); refreshAccountLine(); });
        card.add(offline);
        card.add(Box.createVerticalStrut(10));

        JPanel mode = new JPanel(new FlowLayout(FlowLayout.LEFT, 0, 0));
        mode.setOpaque(false);
        mode.setAlignmentX(Component.LEFT_ALIGNMENT);
        mode.add(new Widgets.Button("Play with Microsoft", false, () -> { cfg.useMicrosoft = true; cfg.save(); refreshAccountLine(); }));
        mode.add(new Widgets.Button("Play offline", false, () -> { cfg.useMicrosoft = false; cfg.save(); refreshAccountLine(); }));
        mode.add(Box.createHorizontalStrut(8), 1);
        for (Component c : mode.getComponents()) if (c instanceof Widgets.Button) c.setPreferredSize(new Dimension(170, 34));
        card.add(mode);

        page.add(card);
        return page;
    }

    private JComponent settingsPage() {
        JPanel page = pageShell("Settings", "Memory, Java and game files.");
        Widgets.Glass card = new Widgets.Glass(22);
        card.setLayout(new BoxLayout(card, BoxLayout.Y_AXIS));
        card.setBorder(BorderFactory.createEmptyBorder(18, 20, 18, 20));

        JLabel ram = label(ramText(), 13f, Theme.TEXT);
        ram.setAlignmentX(Component.LEFT_ALIGNMENT);
        card.add(ram);
        Widgets.Slider slider = new Widgets.Slider(1, 16, cfg.ramMb / 1024.0, v -> {
            cfg.ramMb = (int) (Math.round(v * 2) * 512);
            cfg.save();
            ram.setText(ramText());
        });
        slider.setAlignmentX(Component.LEFT_ALIGNMENT);
        slider.setMaximumSize(new Dimension(Integer.MAX_VALUE, 28));
        card.add(slider);
        card.add(Box.createVerticalStrut(18));

        card.add(left(label("Java executable (leave empty to use Java 21 automatically)", 12f, Theme.DIM)));
        Widgets.Field java = new Widgets.Field(cfg.javaPath);
        java.setMaximumSize(new Dimension(Integer.MAX_VALUE, 38));
        java.setAlignmentX(Component.LEFT_ALIGNMENT);
        java.getDocument().addDocumentListener((SimpleDoc) () -> { cfg.javaPath = java.getText().trim(); cfg.save(); });
        card.add(java);
        card.add(Box.createVerticalStrut(18));

        JPanel row = new JPanel(new FlowLayout(FlowLayout.LEFT, 0, 0));
        row.setOpaque(false);
        row.setAlignmentX(Component.LEFT_ALIGNMENT);
        Widgets.Button open = new Widgets.Button("Open game folder", false, () -> {
            try {
                Files.createDirectories(Dirs.instance(currentVersion()));
                Desktop.getDesktop().open(Dirs.instance(currentVersion()).toFile());
            } catch (Exception e) {
                status.setText("Could not open the folder: " + e.getMessage());
            }
        });
        Widgets.Button verify = new Widgets.Button("Verify game files", false, this::verifyFiles);
        open.setPreferredSize(new Dimension(170, 34));
        verify.setPreferredSize(new Dimension(170, 34));
        row.add(open);
        row.add(Box.createHorizontalStrut(8));
        row.add(verify);
        card.add(row);

        page.add(card);
        return page;
    }

    private JComponent consolePage() {
        JPanel page = pageShell("Console", "Output of the game and the launcher.");
        console.setEditable(false);
        console.setOpaque(false);
        console.setForeground(new Color(0xD8CFFF));
        console.setFont(new java.awt.Font(java.awt.Font.MONOSPACED, java.awt.Font.PLAIN, 12));
        console.setLineWrap(true);
        JScrollPane scroll = new JScrollPane(console);
        scroll.setOpaque(false);
        scroll.getViewport().setOpaque(false);
        scroll.setBorder(BorderFactory.createEmptyBorder(10, 12, 10, 12));
        Widgets.Glass card = new Widgets.Glass(22);
        card.setLayout(new BorderLayout());
        card.add(scroll);
        page.add(card);
        return page;
    }

    private JPanel pageShell(String title, String subtitle) {
        JPanel page = new JPanel();
        page.setOpaque(false);
        page.setLayout(new BoxLayout(page, BoxLayout.Y_AXIS));
        page.setBorder(BorderFactory.createEmptyBorder(6, 24, 24, 30));
        JLabel t = label(title, 26f, Theme.TEXT);
        t.setAlignmentX(Component.LEFT_ALIGNMENT);
        JLabel s = label(subtitle, 13f, Theme.DIM);
        s.setAlignmentX(Component.LEFT_ALIGNMENT);
        page.add(t);
        page.add(s);
        page.add(Box.createVerticalStrut(16));
        return page;
    }

    // ---- actions ----

    private void show(int index) {
        cards.show(content, PAGES[index]);
        for (int i = 0; i < navs.length; i++) navs[i].setSelected(i == index);
    }

    private void refreshAccountLine() {
        String text = cfg.useMicrosoft && !cfg.msName.isBlank()
                ? "Playing as " + cfg.msName + " (Microsoft)"
                : "Playing as " + (cfg.offlineName.isBlank() ? "Player" : cfg.offlineName) + " (offline)";
        accountLine.setText(text);
    }

    private void log(String line) {
        SwingUtilities.invokeLater(() -> {
            console.append(line + "\n");
            if (console.getLineCount() > 3000) {
                try {
                    console.replaceRange("", 0, console.getLineEndOffset(500));
                } catch (Exception ignored) {
                }
            }
            console.setCaretPosition(console.getDocument().getLength());
        });
    }

    /** A short human reason for an error, instead of an exception class name. */
    private static String friendly(Throwable e) {
        Throwable t = e;
        while (t != null) {
            if (t instanceof java.net.ConnectException || t instanceof java.net.UnknownHostException || t instanceof java.net.http.HttpConnectTimeoutException) {
                return "No connection to the internet. Check your network and try again.";
            }
            t = t.getCause();
        }
        return e.getMessage() == null || e.getMessage().isBlank() ? e.getClass().getSimpleName() : e.getMessage();
    }

    private void setStatus(String text, double fraction, boolean error) {
        SwingUtilities.invokeLater(() -> {
            status.setText(text);
            status.setForeground(error ? Theme.ERROR : Theme.DIM);
            if (fraction >= 0) bar.set(fraction);
        });
    }

    private void startGame() {
        if (busy) return;
        busy = true;
        play.setActive(false);
        play.setLabel("Preparing...");
        new Thread(() -> {
            try {
                Account account;
                if (cfg.useMicrosoft && !cfg.msRefreshToken.isBlank()) {
                    setStatus("Signing in...", 0, false);
                    account = MicrosoftAuth.refresh(cfg);
                } else {
                    account = Account.offline(cfg.offlineName);
                }
                Install.Progress progress = (text, f) -> setStatus(text, f, false);
                String mc = currentVersion();
                Install.Result result = Install.run(mc, progress);
                if (!result.astraMod()) log("No Astra mod build for " + mc + " yet. Starting Fabric only.");
                var java = JavaRuntime.find(cfg, result.javaMajor(), progress);
                setStatus("Starting Minecraft...", 1, false);
                Process process = GameLauncher.launch(result, account, cfg, java, this::log);
                SwingUtilities.invokeLater(() -> play.setLabel("PLAYING"));
                setStatus("Minecraft is running", 1, false);
                int code = process.waitFor();
                log("Game exited with code " + code);
                setStatus(code == 0 ? "Ready to play" : "The game closed with an error. See Console.", 0, code != 0);
            } catch (Exception e) {
                log("Launch failed: " + e);
                setStatus(friendly(e), 0, true);
            } finally {
                busy = false;
                SwingUtilities.invokeLater(() -> {
                    play.setLabel("PLAY");
                    play.setActive(true);
                });
            }
        }, "astra-launch").start();
    }

    private void verifyFiles() {
        if (busy) return;
        busy = true;
        new Thread(() -> {
            try {
                Install.run(currentVersion(), (text, f) -> setStatus(text, f, false));
                setStatus("All game files are in place", 1, false);
            } catch (Exception e) {
                setStatus(friendly(e), 0, true);
            } finally {
                busy = false;
            }
        }, "astra-verify").start();
    }

    private void microsoftSignIn() {
        signInWith(true);
    }

    /** browser = the normal Microsoft page; otherwise the short code flow. */
    private void signInWith(boolean browser) {
        String clientId = cfg.effectiveAzureClientId();
        if (clientId.isBlank()) {
            msStatus.setForeground(Theme.ERROR);
            msStatus.setText("No application ID yet. Enter your Azure application (client) ID above.");
            return;
        }
        cancelLogin = false;
        msStatus.setForeground(Theme.DIM);
        msStatus.setText(browser ? "Opening the Microsoft sign-in page..." : "Contacting Microsoft...");
        new Thread(() -> {
            try {
                MicrosoftAuth.onStep = step -> SwingUtilities.invokeLater(() -> {
                    msStatus.setForeground(Theme.DIM);
                    msStatus.setText(step);
                });
                Account account;
                if (browser) {
                    account = MicrosoftAuth.loginInBrowser(clientId, url -> {
                        SwingUtilities.invokeLater(() -> msStatus.setText("<html>Finish the sign-in in your browser. If it says <b>redirect_uri is not valid</b>: in the Azure portal open your app, Authentication, Add a platform, Mobile and desktop applications, and add <b>http://localhost</b>. Or use 'Use a code'.</html>"));
                        try {
                            Toolkit.getDefaultToolkit().getSystemClipboard().setContents(new StringSelection(url), null);
                            Desktop.getDesktop().browse(URI.create(url));
                        } catch (Exception ignored) {
                        }
                    }, () -> cancelLogin);
                } else {
                    MicrosoftAuth.DeviceCode code = MicrosoftAuth.requestDeviceCode(clientId);
                    SwingUtilities.invokeLater(() -> msStatus.setText("<html>Open <b>" + code.verificationUri() + "</b> and enter the code <b>"
                            + code.userCode() + "</b> (copied to your clipboard).</html>"));
                    try {
                        Toolkit.getDefaultToolkit().getSystemClipboard().setContents(new StringSelection(code.userCode()), null);
                        Desktop.getDesktop().browse(URI.create(code.verificationUri()));
                    } catch (Exception ignored) {
                    }
                    account = MicrosoftAuth.completeLogin(clientId, code, () -> cancelLogin);
                }
                Account done = account;
                SwingUtilities.invokeLater(() -> {
                    msStatus.setForeground(Theme.OK);
                    msStatus.setText("Signed in as " + done.name());
                    refreshAccountLine();
                });
            } catch (Exception e) {
                SwingUtilities.invokeLater(() -> {
                    msStatus.setForeground(Theme.ERROR);
                    String text = e.getMessage() == null ? e.toString() : e.getMessage();
                    if (e instanceof MicrosoftAuth.NotApproved) text += " Use 'Request approval' to open Microsoft's form, then try again after they answered.";
                    if (browser && text.contains("redirect_uri")) text += " Add http://localhost as a 'Mobile and desktop applications' redirect URI in the Azure app, or use 'Use a code'.";
                    msStatus.setText("<html>" + text.replace("<", "&lt;") + "</html>");
                });
            }
        }, "astra-login").start();
    }

    private String ramText() {
        return String.format("Memory for the game: %.1f GB", cfg.ramMb / 1024.0);
    }


    // ---- versions ----

    private String currentVersion() {
        if (!cfg.mcVersion.isBlank()) return cfg.mcVersion;
        for (String id : Versions.BUILT_IN) if (Mods.available(id)) return id;
        return Versions.BUILT_IN.get(0);
    }

    private String versionLabel(String id) {
        return "Minecraft " + id + (Mods.available(id) ? "" : "  (Fabric only)");
    }

    private void loadVersions() {
        new Thread(() -> {
            try {
                java.util.List<String> list = Versions.available();
                if (list.isEmpty()) return;
                SwingUtilities.invokeLater(() -> picker.setItems(list, currentVersion()));
            } catch (Exception ignored) {
            }
        }, "astra-versions").start();
    }

    // ---- helpers ----

    private static JLabel label(String text, float size, Color color) {
        JLabel l = new JLabel(text);
        l.setFont(Theme.font(size));
        l.setForeground(color);
        return l;
    }

    private static JComponent center(JComponent c) {
        c.setAlignmentX(Component.CENTER_ALIGNMENT);
        return c;
    }

    private static JComponent left(JComponent c) {
        c.setAlignmentX(Component.LEFT_ALIGNMENT);
        return c;
    }

    @FunctionalInterface
    private interface SimpleDoc extends javax.swing.event.DocumentListener {
        void changed();
        @Override default void insertUpdate(javax.swing.event.DocumentEvent e) { changed(); }
        @Override default void removeUpdate(javax.swing.event.DocumentEvent e) { changed(); }
        @Override default void changedUpdate(javax.swing.event.DocumentEvent e) { changed(); }
    }

    // ---- custom components ----

    private static final class Nav extends JComponent {
        private final String text;
        private final int icon;
        private boolean selected, hover;
        private float selT, hovT;

        Nav(String text, int icon, Runnable action) {
            this.text = text;
            this.icon = icon;
            setMaximumSize(new Dimension(190, 44));
            setPreferredSize(new Dimension(190, 44));
            setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
            addMouseListener(new MouseAdapter() {
                @Override public void mouseEntered(MouseEvent e) { hover = true; repaint(); }
                @Override public void mouseExited(MouseEvent e) { hover = false; repaint(); }
                @Override public void mouseClicked(MouseEvent e) { action.run(); }
            });
        }

        void setSelected(boolean s) { selected = s; repaint(); }

        @Override protected void paintComponent(Graphics g0) {
            Graphics2D g = (Graphics2D) g0.create();
            Theme.quality(g);
            selT = Fx.approach(selT, selected ? 1f : 0f, 0.25f);
            hovT = Fx.approach(hovT, hover ? 1f : 0f, 0.25f);
            int w = getWidth(), h = getHeight();
            RoundRectangle2D shape = new RoundRectangle2D.Double(0.5, 0.5, w - 1, h - 1, 18, 18);
            if (hovT > 0.02f) {
                g.setColor(new Color(255, 255, 255, (int) (20 * hovT)));
                g.fill(shape);
            }
            if (selT > 0.02f) {
                g.setPaint(new java.awt.LinearGradientPaint(0, 0, w, 0, new float[] {0f, 1f},
                        new Color[] {new Color(167, 139, 250, (int) (105 * selT)), new Color(236, 72, 153, (int) (46 * selT))}));
                g.fill(shape);
                g.setColor(new Color(216, 190, 255, (int) (90 * selT)));
                g.draw(shape);
                RoundRectangle2D bar = new RoundRectangle2D.Double(0, h * 0.24, 3.5, h * 0.52, 3, 3);
                Fx.glow(g, bar, Theme.ACCENT, 4, 1.8f, (int) (130 * selT));
                g.setColor(Color.WHITE);
                g.fill(bar);
            }
            float k = Math.max(selT, hovT * 0.7f);
            Color c = Fx.mix(Theme.DIM, Color.WHITE, k);
            Icons.draw(g, icon, 25, h / 2f, 19, c);
            g.setColor(c);
            g.setFont(Theme.font(14f));
            FontMetrics fm = g.getFontMetrics();
            g.drawString(text, 48 + (int) (selT * 3), (h + fm.getAscent() - fm.getDescent()) / 2);
            g.dispose();
        }
    }

    private static java.awt.image.BufferedImage logoImage;

    private static java.awt.image.BufferedImage logo() {
        if (logoImage == null) {
            try (java.io.InputStream in = LauncherWindow.class.getResourceAsStream("/icons/astra.png")) {
                if (in != null) logoImage = javax.imageio.ImageIO.read(in);
            } catch (java.io.IOException ignored) {
            }
        }
        return logoImage;
    }

    /** Logo with a breathing halo, the ASTRA title with a light sweeping through it, and the tagline. */
    private static final class Hero extends JComponent {
        Hero() {
            setPreferredSize(new Dimension(560, 178));
            setMaximumSize(new Dimension(560, 178));
        }

        @Override protected void paintComponent(Graphics g0) {
            Graphics2D g = (Graphics2D) g0.create();
            Theme.quality(g);
            g.setRenderingHint(java.awt.RenderingHints.KEY_INTERPOLATION, java.awt.RenderingHints.VALUE_INTERPOLATION_BICUBIC);
            float t = Fx.time();
            int w = getWidth(), cx = w / 2;
            float pulse = 0.5f + 0.5f * (float) Math.sin(t * 1.5f);

            int logoY = 2 + (int) (Math.sin(t * 1.1f) * 2.5f);
            g.setPaint(new RadialGradientPaint(cx, logoY + 34, 74, new float[] {0f, 1f},
                    new Color[] {new Color(190, 130, 255, (int) (95 + 60 * pulse)), new Color(190, 130, 255, 0)}));
            g.fillRect(cx - 80, logoY - 40, 160, 150);
            java.awt.image.BufferedImage img = logo();
            if (img != null) g.drawImage(img, cx - 34, logoY, 68, 68, null);

            g.setFont(Theme.font(70f));
            FontMetrics fm = g.getFontMetrics();
            String text = "ASTRA";
            int tw = fm.stringWidth(text), x = cx - tw / 2, y = 142;
            g.setColor(new Color(150, 100, 255, 46));
            for (int i = 1; i <= 6; i++) g.drawString(text, x, y + i);
            g.setColor(new Color(236, 130, 255, 26));
            for (int i = 1; i <= 3; i++) {
                g.drawString(text, x - i, y);
                g.drawString(text, x + i, y);
            }
            float sweep = (t * 90f) % (tw * 2f);
            g.setPaint(new java.awt.LinearGradientPaint(x - tw + sweep, 0, x + sweep, 0, new float[] {0f, 0.35f, 0.5f, 0.65f, 1f},
                    new Color[] {new Color(0xA78BFA), new Color(0xC4B5FD), Color.WHITE, new Color(0xF0ABFC), new Color(0xA78BFA)},
                    java.awt.MultipleGradientPaint.CycleMethod.REPEAT));
            g.drawString(text, x, y);

            g.setFont(Theme.font(11.5f));
            fm = g.getFontMetrics();
            String sub = "THE NEXT LEVEL OF MINECRAFT";
            int total = 0;
            for (char ch : sub.toCharArray()) total += fm.charWidth(ch) + 4;
            int sx = cx - total / 2;
            for (int i = 0; i < sub.length(); i++) {
                char ch = sub.charAt(i);
                float wave = 0.5f + 0.5f * (float) Math.sin(t * 2f - i * 0.35f);
                g.setColor(Fx.mix(Theme.DIM, Color.WHITE, wave * 0.55f));
                g.drawString(String.valueOf(ch), sx, 166);
                sx += fm.charWidth(ch) + 4;
            }
            g.dispose();
        }
    }

    private static final class FeatureCard extends JComponent {
        private final String title, desc;
        private final int icon;
        private boolean hover;
        private float hovT;

        FeatureCard(String title, String desc, int icon) {
            this.title = title;
            this.desc = desc;
            this.icon = icon;
            setPreferredSize(new Dimension(190, 66));
            setMaximumSize(new Dimension(190, 66));
            addMouseListener(new MouseAdapter() {
                @Override public void mouseEntered(MouseEvent e) { hover = true; repaint(); }
                @Override public void mouseExited(MouseEvent e) { hover = false; repaint(); }
            });
        }

        @Override protected void paintComponent(Graphics g0) {
            Graphics2D g = (Graphics2D) g0.create();
            Theme.quality(g);
            hovT = Fx.approach(hovT, hover ? 1f : 0f, 0.25f);
            int w = getWidth(), h = getHeight();
            RoundRectangle2D shape = new RoundRectangle2D.Double(0.5, 0.5, w - 1, h - 1, 22, 22);
            g.setColor(new Color(13, 7, 32, 150));
            g.fill(shape);
            g.setPaint(new GradientPaint(0, 0, new Color(255, 255, 255, (int) (32 + 26 * hovT)), 0, h, new Color(170, 130, 255, (int) (12 + 18 * hovT))));
            g.fill(shape);
            g.setPaint(Fx.mix(new Color(200, 180, 255, 80), new Color(226, 205, 255, 220), hovT));
            g.draw(shape);
            if (hovT > 0.05f) Fx.glow(g, shape, Theme.ACCENT, 3, 1.6f, (int) (55 * hovT));
            // icon in a glowing disc
            float cy = h / 2f;
            java.awt.geom.Ellipse2D disc = new java.awt.geom.Ellipse2D.Float(14, cy - 18, 36, 36);
            g.setPaint(new GradientPaint(0, cy - 18, new Color(167, 139, 250, 200), 0, cy + 18, new Color(109, 63, 216, 200)));
            g.fill(disc);
            g.setColor(new Color(255, 255, 255, 90));
            g.draw(disc);
            Icons.draw(g, icon, 32, cy, 18, Color.WHITE);
            g.setColor(Theme.TEXT);
            g.setFont(Theme.font(13f));
            g.drawString(title, 60, cy - 2);
            g.setColor(Theme.DIM);
            g.setFont(Theme.font(10.5f));
            g.drawString(desc, 60, cy + 14);
            g.dispose();
        }
    }

    /** Who you play as, with an avatar disc and a coloured status dot. */
    private final class AccountChip extends JComponent {
        AccountChip() {
            setPreferredSize(new Dimension(188, 56));
            setMaximumSize(new Dimension(188, 56));
            setAlignmentX(Component.LEFT_ALIGNMENT);
        }

        @Override protected void paintComponent(Graphics g0) {
            Graphics2D g = (Graphics2D) g0.create();
            Theme.quality(g);
            boolean ms = cfg.useMicrosoft && !cfg.msName.isBlank();
            String name = ms ? cfg.msName : (cfg.offlineName.isBlank() ? "Player" : cfg.offlineName);
            int w = getWidth(), h = getHeight();
            RoundRectangle2D shape = new RoundRectangle2D.Double(0.5, 0.5, w - 1, h - 1, 20, 20);
            g.setPaint(new GradientPaint(0, 0, new Color(255, 255, 255, 34), 0, h, new Color(170, 130, 255, 14)));
            g.fill(shape);
            g.setColor(new Color(200, 180, 255, 80));
            g.draw(shape);
            java.awt.geom.Ellipse2D disc = new java.awt.geom.Ellipse2D.Float(10, h / 2f - 18, 36, 36);
            g.setPaint(new GradientPaint(0, h / 2f - 18, new Color(236, 110, 200), 0, h / 2f + 18, new Color(109, 63, 216)));
            g.fill(disc);
            g.setColor(Color.WHITE);
            g.setFont(Theme.font(16f));
            FontMetrics fm = g.getFontMetrics();
            String initial = name.substring(0, 1).toUpperCase();
            g.drawString(initial, 28 - fm.stringWidth(initial) / 2, h / 2f + (fm.getAscent() - fm.getDescent()) / 2f);
            g.setColor(Theme.TEXT);
            g.setFont(Theme.font(13f));
            fm = g.getFontMetrics();
            String shown = name;
            while (shown.length() > 3 && fm.stringWidth(shown) > w - 66) shown = shown.substring(0, shown.length() - 2) + "..";
            g.drawString(shown, 56, h / 2f - 2);
            Color dot = ms ? new Color(0x4ADE80) : new Color(0xFBBF24);
            g.setColor(Fx.alpha(dot, 60 + (int) (40 * Math.sin(Fx.time() * 3))));
            g.fillOval(55, (int) (h / 2f + 6), 10, 10);
            g.setColor(dot);
            g.fillOval(57, (int) (h / 2f + 8), 6, 6);
            g.setColor(Theme.DIM);
            g.setFont(Theme.font(10.5f));
            g.drawString(ms ? "Microsoft account" : "Offline mode", 70, h / 2f + 15);
            g.dispose();
        }
    }
}
