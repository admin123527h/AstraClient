package client.astra.launcher;

import javax.swing.JComponent;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;
import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Cursor;
import java.awt.Dimension;
import java.awt.FontMetrics;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.GradientPaint;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.geom.RoundRectangle2D;
import java.util.function.DoubleConsumer;

final class Widgets {
    private Widgets() {}

    static final class Glass extends JPanel {
        private final int radius;

        Glass(int radius) {
            this.radius = radius;
            setOpaque(false);
        }

        @Override
        protected void paintComponent(Graphics g0) {
            Graphics2D g = (Graphics2D) g0.create();
            Theme.quality(g);
            int w = getWidth(), h = getHeight();
            RoundRectangle2D shape = new RoundRectangle2D.Double(0.5, 0.5, w - 1, h - 1, radius, radius);
            g.setColor(new Color(13, 7, 32, 168));
            g.fill(shape);
            g.setPaint(new GradientPaint(0, 0, Theme.GLASS_TOP, 0, h, Theme.GLASS_BOTTOM));
            g.fill(shape);
            // soft light from the top edge
            g.setPaint(new GradientPaint(0, 0, new Color(255, 255, 255, 38), 0, Math.min(h, 90), new Color(255, 255, 255, 0)));
            g.fill(shape);
            g.setStroke(new BasicStroke(1f));
            g.setPaint(new GradientPaint(0, 0, new Color(255, 255, 255, 135), 0, h, new Color(150, 110, 255, 70)));
            g.draw(shape);
            g.setColor(new Color(255, 255, 255, 40));
            g.drawLine((int) (radius * 0.6), 1, (int) (w - radius * 0.6), 1);
            g.dispose();
        }
    }

    static final class Button extends JComponent {
        private final boolean primary;
        private final Runnable action;
        private boolean hover, down, enabled = true;
        private String label;
        private float hoverT;

        Button(String text, boolean primary, Runnable action) {
            this.label = text;
            this.primary = primary;
            this.action = action;
            setPreferredSize(new Dimension(140, 36));
            setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
            addMouseListener(new MouseAdapter() {
                @Override public void mouseEntered(MouseEvent e) { hover = true; repaint(); }
                @Override public void mouseExited(MouseEvent e) { hover = false; down = false; repaint(); }
                @Override public void mousePressed(MouseEvent e) { down = true; repaint(); }
                @Override public void mouseReleased(MouseEvent e) {
                    boolean fire = down && hover && enabled;
                    down = false;
                    repaint();
                    if (fire) action.run();
                }
            });
        }

        void setLabel(String s) { label = s; repaint(); }

        void setActive(boolean on) {
            enabled = on;
            setCursor(Cursor.getPredefinedCursor(on ? Cursor.HAND_CURSOR : Cursor.DEFAULT_CURSOR));
            repaint();
        }

        @Override
        protected void paintComponent(Graphics g0) {
            Graphics2D g = (Graphics2D) g0.create();
            Theme.quality(g);
            hoverT = Fx.approach(hoverT, hover && enabled ? 1f : 0f, 0.25f);
            float t = Fx.time();
            int w = getWidth(), h = getHeight(), arc = primary ? h : 18;
            int inset = primary ? 6 : 0;
            RoundRectangle2D shape = new RoundRectangle2D.Double(inset + 0.5, inset + 0.5, w - 1 - inset * 2, h - 1 - inset * 2, arc - inset, arc - inset);
            float press = down ? 1.5f : 0f;
            if (primary) {
                float pulse = 0.5f + 0.5f * (float) Math.sin(t * 2.2f);
                int glowA = enabled ? (int) (70 + 60 * hoverT + 40 * pulse) : 18;
                Color glowColor = enabled ? new Color(190, 120, 255) : Theme.DIM;
                Fx.glow(g, shape, glowColor, 7, 2.4f, glowA);
                if (enabled) {
                    float x0 = -((t * 90f) % w);
                    g.setPaint(new java.awt.LinearGradientPaint(x0, 0, x0 + w, 0, new float[] {0f, 0.25f, 0.5f, 0.75f, 1f},
                            new Color[] {new Color(109, 63, 216), new Color(167, 139, 250), new Color(236, 110, 200), new Color(167, 139, 250), new Color(109, 63, 216)},
                            java.awt.MultipleGradientPaint.CycleMethod.REPEAT));
                } else {
                    g.setPaint(new Color(80, 66, 120));
                }
                g.fill(shape);
                g.setPaint(new GradientPaint(0, 0, new Color(255, 255, 255, 80), 0, h * 0.55f, new Color(255, 255, 255, 0)));
                g.fill(shape);
                g.setPaint(new GradientPaint(0, h * 0.5f, new Color(0, 0, 0, 0), 0, h, new Color(20, 0, 60, 90)));
                g.fill(shape);
                if (enabled && hoverT > 0.05f) {
                    java.awt.Shape old = g.getClip();
                    g.setClip(shape);
                    float sx = (t * 260f) % (w + 160f) - 80f;
                    java.awt.geom.Path2D.Float band = new java.awt.geom.Path2D.Float();
                    band.moveTo(sx, h);
                    band.lineTo(sx + 36, h);
                    band.lineTo(sx + 66, 0);
                    band.lineTo(sx + 30, 0);
                    band.closePath();
                    g.setColor(new Color(255, 255, 255, (int) (70 * hoverT)));
                    g.fill(band);
                    g.setClip(old);
                }
                g.setStroke(new BasicStroke(1.2f));
                g.setColor(new Color(255, 255, 255, 150));
                g.draw(shape);
            } else {
                g.setPaint(new GradientPaint(0, 0, new Color(255, 255, 255, (int) (30 + 36 * hoverT)), 0, h, new Color(190, 170, 255, (int) (14 + 26 * hoverT))));
                g.fill(shape);
                g.setStroke(new BasicStroke(1f));
                g.setPaint(Fx.mix(Theme.BORDER, new Color(216, 190, 255, 230), hoverT));
                g.draw(shape);
                if (hoverT > 0.05f) Fx.glow(g, shape, Theme.ACCENT, 3, 1.6f, (int) (60 * hoverT));
            }
            g.setFont(Theme.font(primary ? 19f : 13f));
            FontMetrics fm = g.getFontMetrics();
            int ty = (h + fm.getAscent() - fm.getDescent()) / 2 + (int) press;
            if (primary) {
                g.setColor(new Color(40, 10, 90, 120));
                g.drawString(label, (w - fm.stringWidth(label)) / 2 + 1, ty + 2);
            }
            g.setColor(enabled ? Color.WHITE : new Color(255, 255, 255, 150));
            g.drawString(label, (w - fm.stringWidth(label)) / 2, ty);
            g.dispose();
        }
    }

    static final class Bar extends JComponent {
        private double value;
        private float shown;

        void set(double v) { value = Math.max(0, Math.min(1, v)); repaint(); }

        @Override
        protected void paintComponent(Graphics g0) {
            Graphics2D g = (Graphics2D) g0.create();
            Theme.quality(g);
            int w = getWidth(), h = getHeight();
            shown = Fx.approach(shown, (float) value, 0.2f);
            g.setColor(new Color(255, 255, 255, 26));
            g.fill(new RoundRectangle2D.Double(0, 0, w, h, h, h));
            g.setColor(new Color(255, 255, 255, 30));
            g.draw(new RoundRectangle2D.Double(0.5, 0.5, w - 1, h - 1, h, h));
            int fill = Math.round(w * shown);
            if (fill > 0) {
                float t = Fx.time();
                RoundRectangle2D bar = new RoundRectangle2D.Double(0, 0, Math.max(fill, h), h, h, h);
                Fx.glow(g, bar, new Color(200, 130, 255), 4, 2f, 80);
                float x0 = -((t * 120f) % 200f);
                g.setPaint(new java.awt.LinearGradientPaint(x0, 0, x0 + 200, 0, new float[] {0f, 0.5f, 1f},
                        new Color[] {new Color(167, 139, 250), new Color(244, 170, 252), new Color(167, 139, 250)}, java.awt.MultipleGradientPaint.CycleMethod.REPEAT));
                g.fill(bar);
                g.setColor(new Color(255, 255, 255, 200));
                g.fillOval(Math.max(fill, h) - h + 1, 1, h - 2, h - 2);
            }
            g.dispose();
        }

        @Override public Dimension getPreferredSize() { return new Dimension(200, 8); }
    }

    static final class Slider extends JComponent {
        private final double min, max;
        private double value;
        private final DoubleConsumer onChange;

        Slider(double min, double max, double value, DoubleConsumer onChange) {
            this.min = min;
            this.max = max;
            this.value = value;
            this.onChange = onChange;
            setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
            MouseAdapter m = new MouseAdapter() {
                @Override public void mousePressed(MouseEvent e) { move(e.getX()); }
                @Override public void mouseDragged(MouseEvent e) { move(e.getX()); }
            };
            addMouseListener(m);
            addMouseMotionListener(m);
        }

        double value() { return value; }

        private void move(int x) {
            double t = Math.max(0, Math.min(1, (x - 8.0) / Math.max(1, getWidth() - 16)));
            value = min + (max - min) * t;
            onChange.accept(value);
            repaint();
        }

        @Override
        protected void paintComponent(Graphics g0) {
            Graphics2D g = (Graphics2D) g0.create();
            Theme.quality(g);
            int w = getWidth(), cy = getHeight() / 2;
            g.setColor(new Color(255, 255, 255, 32));
            g.fill(new RoundRectangle2D.Double(8, cy - 2, w - 16, 4, 4, 4));
            int x = 8 + (int) ((w - 16) * (value - min) / (max - min));
            g.setColor(Theme.ACCENT);
            g.fill(new RoundRectangle2D.Double(8, cy - 2, x - 8, 4, 4, 4));
            g.setColor(Color.WHITE);
            g.fillOval(x - 7, cy - 7, 14, 14);
            g.dispose();
        }

        @Override public Dimension getPreferredSize() { return new Dimension(220, 24); }
    }

    static final class Field extends JTextField {
        Field(String text) {
            super(text);
            setOpaque(false);
            setForeground(Theme.TEXT);
            setCaretColor(Theme.TEXT);
            setFont(Theme.font(13f));
            setBorder(new EmptyBorder(8, 12, 8, 12));
        }

        @Override
        protected void paintComponent(Graphics g0) {
            Graphics2D g = (Graphics2D) g0.create();
            Theme.quality(g);
            RoundRectangle2D shape = new RoundRectangle2D.Double(0.5, 0.5, getWidth() - 1, getHeight() - 1, 14, 14);
            g.setColor(new Color(10, 6, 24, 130));
            g.fill(shape);
            g.setColor(hasFocus() ? new Color(196, 181, 253, 200) : Theme.BORDER);
            g.draw(shape);
            g.dispose();
            super.paintComponent(g0);
        }
    }

    /** Glass drop-down: shows the current choice and opens a list when clicked. */
    static final class Picker extends JComponent {
        private final java.util.function.Consumer<String> onSelect;
        private final java.util.function.Function<String, String> label;
        private java.util.List<String> items = new java.util.ArrayList<>();
        private String selected = "";
        private boolean hover;
        private float hoverT;

        Picker(java.util.function.Function<String, String> label, java.util.function.Consumer<String> onSelect) {
            this.label = label;
            this.onSelect = onSelect;
            setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
            addMouseListener(new MouseAdapter() {
                @Override public void mouseEntered(MouseEvent e) { hover = true; repaint(); }
                @Override public void mouseExited(MouseEvent e) { hover = false; repaint(); }
                @Override public void mouseReleased(MouseEvent e) { openMenu(); }
            });
        }

        void setItems(java.util.List<String> items, String selected) {
            this.items = new java.util.ArrayList<>(items);
            this.selected = selected;
            repaint();
        }

        String selected() { return selected; }

        private void openMenu() {
            javax.swing.JPopupMenu menu = new javax.swing.JPopupMenu();
            menu.setBackground(new Color(24, 16, 48));
            menu.setBorder(javax.swing.BorderFactory.createLineBorder(Theme.BORDER));
            for (String item : items) {
                javax.swing.JMenuItem mi = new javax.swing.JMenuItem(label.apply(item));
                mi.setFont(Theme.font(13f));
                mi.setBackground(new Color(24, 16, 48));
                mi.setForeground(item.equals(selected) ? Theme.ACCENT : Theme.TEXT);
                mi.addActionListener(ev -> { selected = item; repaint(); onSelect.accept(item); });
                menu.add(mi);
            }
            menu.show(this, 0, getHeight() + 4);
        }

        @Override
        protected void paintComponent(Graphics g0) {
            Graphics2D g = (Graphics2D) g0.create();
            Theme.quality(g);
            int w = getWidth(), h = getHeight();
            RoundRectangle2D shape = new RoundRectangle2D.Double(0.5, 0.5, w - 1, h - 1, h, h);
            hoverT = Fx.approach(hoverT, hover ? 1f : 0f, 0.25f);
            g.setPaint(new GradientPaint(0, 0, new Color(255, 255, 255, (int) (34 + 30 * hoverT)), 0, h, new Color(190, 170, 255, (int) (16 + 24 * hoverT))));
            g.fill(shape);
            g.setPaint(Fx.mix(Theme.BORDER, new Color(216, 190, 255, 230), hoverT));
            g.draw(shape);
            if (hoverT > 0.05f) Fx.glow(g, shape, Theme.ACCENT, 3, 1.6f, (int) (50 * hoverT));
            Icons.draw(g, Icons.CUBE, 24, h / 2f, 16, Theme.ACCENT);
            g.setFont(Theme.font(13f));
            FontMetrics fm = g.getFontMetrics();
            String text = label.apply(selected);
            g.setColor(Theme.TEXT);
            g.drawString(text, 42, (h + fm.getAscent() - fm.getDescent()) / 2);
            g.setColor(Theme.DIM);
            int cx = w - 20, cy = h / 2;
            g.setStroke(new BasicStroke(1.8f, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND));
            g.drawLine(cx - 4, cy - 2, cx, cy + 2);
            g.drawLine(cx, cy + 2, cx + 4, cy - 2);
            g.dispose();
        }

        @Override public Dimension getPreferredSize() { return new Dimension(230, 34); }
    }
}
