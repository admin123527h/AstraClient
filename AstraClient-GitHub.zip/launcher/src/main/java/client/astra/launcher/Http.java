package client.astra.launcher;

import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import java.io.IOException;
import java.io.InputStream;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.security.MessageDigest;
import java.time.Duration;
import java.util.HexFormat;

public final class Http {
    private static final HttpClient CLIENT = HttpClient.newBuilder()
            .followRedirects(HttpClient.Redirect.ALWAYS)
            .connectTimeout(Duration.ofSeconds(20))
            .build();

    private Http() {}

    public static String get(String url) throws IOException {
        HttpResponse<String> res = send(HttpRequest.newBuilder(URI.create(url)).header("User-Agent", "AstraLauncher/0.1").GET().build(),
                HttpResponse.BodyHandlers.ofString());
        if (res.statusCode() / 100 != 2) throw new IOException("HTTP " + res.statusCode() + " for " + url);
        return res.body();
    }

    public static com.google.gson.JsonArray getArray(String url) throws IOException {
        return JsonParser.parseString(get(url)).getAsJsonArray();
    }

    public static JsonObject json(String url) throws IOException {
        return JsonParser.parseString(get(url)).getAsJsonObject();
    }

    public static HttpResponse<String> postForm(String url, String form) throws IOException {
        return send(HttpRequest.newBuilder(URI.create(url)).header("Content-Type", "application/x-www-form-urlencoded")
                .header("Accept", "application/json").POST(HttpRequest.BodyPublishers.ofString(form)).build(), HttpResponse.BodyHandlers.ofString());
    }

    public static HttpResponse<String> postJson(String url, String json, String... headers) throws IOException {
        HttpRequest.Builder b = HttpRequest.newBuilder(URI.create(url)).header("Content-Type", "application/json")
                .header("Accept", "application/json").POST(HttpRequest.BodyPublishers.ofString(json));
        for (int i = 0; i + 1 < headers.length; i += 2) b.header(headers[i], headers[i + 1]);
        return send(b.build(), HttpResponse.BodyHandlers.ofString());
    }

    public static HttpResponse<String> getWith(String url, String... headers) throws IOException {
        HttpRequest.Builder b = HttpRequest.newBuilder(URI.create(url)).GET();
        for (int i = 0; i + 1 < headers.length; i += 2) b.header(headers[i], headers[i + 1]);
        return send(b.build(), HttpResponse.BodyHandlers.ofString());
    }

    private static <T> HttpResponse<T> send(HttpRequest req, HttpResponse.BodyHandler<T> handler) throws IOException {
        try {
            return CLIENT.send(req, handler);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            throw new IOException("interrupted", e);
        }
    }

    /** Downloads to target unless it already exists and matches the expected SHA-1 (or exists, when none is given). */
    public static void download(String url, Path target, String sha1) throws IOException {
        if (Files.exists(target) && (sha1 == null || sha1.equalsIgnoreCase(sha1(target)))) return;
        Files.createDirectories(target.getParent());
        IOException last = null;
        for (int attempt = 0; attempt < 3; attempt++) {
            Path tmp = target.resolveSibling(target.getFileName() + ".part");
            try {
                HttpResponse<InputStream> res = send(HttpRequest.newBuilder(URI.create(url)).header("User-Agent", "AstraLauncher/0.1").GET().build(),
                        HttpResponse.BodyHandlers.ofInputStream());
                if (res.statusCode() / 100 != 2) throw new IOException("HTTP " + res.statusCode() + " for " + url);
                try (InputStream in = res.body()) {
                    Files.copy(in, tmp, StandardCopyOption.REPLACE_EXISTING);
                }
                if (sha1 != null && !sha1.equalsIgnoreCase(sha1(tmp))) throw new IOException("checksum mismatch for " + url);
                Files.move(tmp, target, StandardCopyOption.REPLACE_EXISTING);
                return;
            } catch (IOException e) {
                last = e;
                Files.deleteIfExists(tmp);
            }
        }
        throw last;
    }

    public static String sha1(Path file) throws IOException {
        try (InputStream in = Files.newInputStream(file)) {
            MessageDigest md = MessageDigest.getInstance("SHA-1");
            byte[] buf = new byte[65536];
            int n;
            while ((n = in.read(buf)) > 0) md.update(buf, 0, n);
            return HexFormat.of().formatHex(md.digest());
        } catch (java.security.NoSuchAlgorithmException e) {
            throw new IOException(e);
        }
    }
}
