package client.astra.launcher;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;

import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.function.Consumer;
import java.util.stream.Collectors;

public final class GameLauncher {
    private GameLauncher() {}

    public static Process launch(Install.Result r, Account account, Config cfg, Path java, Consumer<String> log) throws IOException {
        Path natives = Dirs.VERSIONS.resolve(r.mc()).resolve("natives");
        Files.createDirectories(natives);
        Files.createDirectories(r.gameDir());

        Map<String, String> vars = new HashMap<>();
        vars.put("natives_directory", natives.toString());
        vars.put("launcher_name", "Astra");
        vars.put("launcher_version", "0.1.0");
        vars.put("classpath", r.classpath().stream().map(Path::toString).collect(Collectors.joining(File.pathSeparator)));
        vars.put("version_name", r.mc());
        vars.put("version_type", "Astra");
        vars.put("game_directory", r.gameDir().toString());
        vars.put("assets_root", Dirs.ASSETS.toString());
        vars.put("assets_index_name", r.assetsIndexId());
        vars.put("auth_player_name", account.name());
        vars.put("auth_uuid", account.uuid());
        vars.put("auth_access_token", account.accessToken());
        vars.put("auth_xuid", "0");
        vars.put("clientid", "astra");
        vars.put("user_type", account.microsoft() ? "msa" : "legacy");

        List<String> cmd = new ArrayList<>();
        cmd.add(java.toString());
        cmd.add("-Xmx" + cfg.ramMb + "M");
        cmd.add("-Xms512M");
        cmd.addAll(expand(r.jvmArgs(), vars));
        String spotifyId = Updates.defaultId("spotifyClientId");
        if (!spotifyId.isEmpty()) cmd.add("-Dastra.spotifyClientId=" + spotifyId);
        cmd.add(r.mainClass());
        cmd.addAll(expand(r.gameArgs(), vars));
        String extra = System.getProperty("astra.gameArgs");
        if (extra != null && !extra.isBlank()) cmd.addAll(List.of(extra.split("\\|")));

        log.accept("Starting Minecraft " + r.mc() + " as " + account.name() + (account.microsoft() ? "" : " (offline)"));
        Process process = new ProcessBuilder(cmd).directory(r.gameDir().toFile()).redirectErrorStream(true).start();
        Thread reader = new Thread(() -> {
            try (BufferedReader in = new BufferedReader(new InputStreamReader(process.getInputStream(), StandardCharsets.UTF_8))) {
                for (String line; (line = in.readLine()) != null; ) log.accept(line);
            } catch (IOException ignored) {
            }
        }, "astra-game-output");
        reader.setDaemon(true);
        reader.start();
        return process;
    }

    private static List<String> expand(JsonArray args, Map<String, String> vars) {
        List<String> out = new ArrayList<>();
        for (JsonElement e : args) {
            if (e.isJsonPrimitive()) {
                out.add(replace(e.getAsString(), vars));
            } else {
                JsonObject o = e.getAsJsonObject();
                if (o.has("rules") && !Install.Rules.allowed(o.getAsJsonArray("rules"))) continue;
                JsonElement value = o.get("value");
                if (value.isJsonArray()) for (JsonElement v : value.getAsJsonArray()) out.add(replace(v.getAsString(), vars));
                else out.add(replace(value.getAsString(), vars));
            }
        }
        return out;
    }

    private static String replace(String s, Map<String, String> vars) {
        for (Map.Entry<String, String> e : vars.entrySet()) s = s.replace("${" + e.getKey() + "}", e.getValue());
        return s;
    }
}
