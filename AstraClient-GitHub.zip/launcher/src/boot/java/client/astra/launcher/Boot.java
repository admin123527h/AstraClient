package client.astra.launcher;

import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JProgressBar;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.SwingUtilities;
import java.awt.BorderLayout;
import java.awt.Dimension;
import java.io.File;
import java.io.InputStream;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.lang.reflect.InvocationTargetException;
import java.net.URL;
import java.net.URLConnection;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Stream;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

/**
 * Entry point that runs on any Java 8+: starts the launcher when Java is new enough,
 * otherwise offers a private Java 21 download. Compiled for Java 8 on purpose.
 */
public final class Boot {
    private static final int REQUIRED = 17;

    private Boot() {}

    public static void main(String[] args) {
        try {
            if (javaFeature() >= REQUIRED) {
                run(args);
                return;
            }
            int answer = JOptionPane.showConfirmDialog(null,
                    "Astra needs Java 17 or newer, but this computer runs Java " + System.getProperty("java.version") + ".\n\n"
                            + "Download a private copy of Java 21 for Astra? (about 50 MB, nothing else on your PC changes)",
                    "Astra Launcher", JOptionPane.OK_CANCEL_OPTION, JOptionPane.QUESTION_MESSAGE);
            if (answer != JOptionPane.OK_OPTION) return;
            relaunch(ensureJava(), args);
        } catch (Throwable t) {
            showError(t);
        }
    }

    private static void run(String[] args) throws Throwable {
        ClassLoader core = coreLoader();
        if (core != null) {
            try {
                launch(core, args);
                return;
            } catch (ClassNotFoundException | LinkageError broken) {
                // A damaged or incompatible update must never lock the user out: forget it and use the bundled launcher.
                try {
                    Files.deleteIfExists(root().resolve("updates").resolve("core.jar"));
                    Files.deleteIfExists(root().resolve("updates").resolve("core.build"));
                } catch (Exception ignored) {
                }
            }
        }
        launch(Boot.class.getClassLoader(), args);
    }

    private static void launch(ClassLoader loader, String[] args) throws Throwable {
        Thread.currentThread().setContextClassLoader(loader);
        try {
            Class.forName("client.astra.launcher.Main", true, loader).getMethod("main", String[].class).invoke(null, (Object) args);
        } catch (InvocationTargetException e) {
            throw e.getCause() == null ? e : e.getCause();
        }
    }

    /** The downloaded launcher update when it is newer than the one this jar was built with, else null. */
    private static ClassLoader coreLoader() {
        try {
            Path jar = root().resolve("updates").resolve("core.jar");
            Path build = root().resolve("updates").resolve("core.build");
            if (!Files.isRegularFile(jar) || !Files.isRegularFile(build)) return null;
            long downloaded = Long.parseLong(new String(Files.readAllBytes(build), "UTF-8").trim());
            long bundled = 0;
            try (InputStream in = Boot.class.getResourceAsStream("/launcher.build")) {
                if (in != null) {
                    java.io.ByteArrayOutputStream out = new java.io.ByteArrayOutputStream();
                    byte[] buf = new byte[64];
                    for (int n; (n = in.read(buf)) > 0; ) out.write(buf, 0, n);
                    bundled = Long.parseLong(new String(out.toByteArray(), "UTF-8").trim());
                }
            }
            if (downloaded <= bundled) return null;
            return new ChildFirst(new URL[] {jar.toUri().toURL()}, Boot.class.getClassLoader());
        } catch (Exception e) {
            return null;
        }
    }

    /** Loads the launcher classes from the update first, so they win over the ones inside the running jar. */
    private static final class ChildFirst extends java.net.URLClassLoader {
        ChildFirst(URL[] urls, ClassLoader parent) {
            super(urls, parent);
        }

        @Override
        protected Class<?> loadClass(String name, boolean resolve) throws ClassNotFoundException {
            synchronized (getClassLoadingLock(name)) {
                Class<?> c = findLoadedClass(name);
                boolean mine = (name.startsWith("client.astra.launcher.") && !name.equals("client.astra.launcher.Boot")
                        && !name.startsWith("client.astra.launcher.Boot$")) || name.startsWith("com.google.gson.");
                if (c == null && mine) {
                    try {
                        c = findClass(name);
                    } catch (ClassNotFoundException ignored) {
                    }
                }
                if (c == null) return super.loadClass(name, resolve);
                if (resolve) resolveClass(c);
                return c;
            }
        }

        @Override
        public URL getResource(String name) {
            URL own = findResource(name);
            return own != null ? own : super.getResource(name);
        }

        @Override
        public InputStream getResourceAsStream(String name) {
            try {
                URL url = getResource(name);
                return url == null ? null : url.openStream();
            } catch (java.io.IOException e) {
                return null;
            }
        }
    }

    static int javaFeature() {
        String fake = System.getProperty("astra.fakeJavaVersion");
        String v = fake != null ? fake : System.getProperty("java.specification.version", "8");
        if (v.startsWith("1.")) v = v.substring(2);
        int dot = v.indexOf('.');
        if (dot > 0) v = v.substring(0, dot);
        try {
            return Integer.parseInt(v);
        } catch (NumberFormatException e) {
            return 8;
        }
    }

    // ---- private Java download ----

    private static boolean windows() {
        return System.getProperty("os.name", "").toLowerCase().contains("win");
    }

    private static Path root() {
        String override = System.getProperty("astra.home");
        if (override != null && !override.trim().isEmpty()) return Paths.get(override);
        String os = System.getProperty("os.name", "").toLowerCase();
        String home = System.getProperty("user.home");
        if (os.contains("win")) {
            String appData = System.getenv("APPDATA");
            return Paths.get(appData != null ? appData : home, ".astra");
        }
        if (os.contains("mac")) return Paths.get(home, "Library", "Application Support", "astra");
        return Paths.get(home, ".astra");
    }

    private static Path ensureJava() throws Exception {
        Path dir = root().resolve("runtime").resolve("launcher-java");
        Path existing = Files.isDirectory(dir) ? locate(dir) : null;
        if (existing != null) return existing;

        Files.createDirectories(dir);
        String url = System.getProperty("astra.javaUrl");
        if (url == null) {
            String os = windows() ? "windows" : System.getProperty("os.name", "").toLowerCase().contains("mac") ? "mac" : "linux";
            String arch = System.getProperty("os.arch", "").matches(".*(aarch64|arm64).*") ? "aarch64" : "x64";
            url = "https://api.adoptium.net/v3/binary/latest/21/ga/" + os + "/" + arch + "/jre/hotspot/normal/eclipse";
        }
        final boolean zip = windows() || url.endsWith(".zip");
        Path archive = dir.resolveSibling("launcher-java." + (zip ? "zip" : "tar.gz"));

        final JDialog[] box = new JDialog[1];
        SwingUtilities.invokeAndWait(() -> {
            box[0] = new JDialog((java.awt.Frame) null, "Astra Launcher", false);
            JProgressBar bar = new JProgressBar();
            bar.setIndeterminate(true);
            box[0].add(new JLabel("  Downloading Java 21 for Astra, please wait...  ", JLabel.CENTER), BorderLayout.NORTH);
            box[0].add(bar, BorderLayout.CENTER);
            box[0].setPreferredSize(new Dimension(380, 90));
            box[0].pack();
            box[0].setLocationRelativeTo(null);
            box[0].setVisible(true);
        });
        try {
            URLConnection conn = new URL(url).openConnection();
            conn.setRequestProperty("User-Agent", "AstraLauncher/0.1");
            conn.setConnectTimeout(20000);
            conn.setReadTimeout(60000);
            try (InputStream in = conn.getInputStream()) {
                Files.copy(in, archive, StandardCopyOption.REPLACE_EXISTING);
            }
            if (zip) unzip(archive, dir);
            else {
                Process p = new ProcessBuilder("tar", "-xzf", archive.toString(), "-C", dir.toString()).inheritIO().start();
                if (p.waitFor() != 0) throw new IllegalStateException("tar failed");
                new ProcessBuilder("chmod", "-R", "u+x", dir.toString()).start().waitFor();
            }
            Files.deleteIfExists(archive);
        } finally {
            SwingUtilities.invokeLater(() -> box[0].dispose());
        }
        Path found = locate(dir);
        if (found == null) throw new IllegalStateException("Java was downloaded but no java executable was found in " + dir);
        return found;
    }

    private static Path locate(Path root) throws Exception {
        List<Path> hits = new ArrayList<>();
        try (Stream<Path> walk = Files.walk(root, 6)) {
            walk.filter(f -> f.getParent() != null && f.getParent().getFileName().toString().equals("bin")).forEach(hits::add);
        }
        for (String name : new String[] {"javaw.exe", "java.exe", "java"}) {
            for (Path p : hits) if (p.getFileName().toString().equals(name)) return p;
        }
        return null;
    }

    private static void unzip(Path zip, Path dest) throws Exception {
        try (ZipInputStream in = new ZipInputStream(Files.newInputStream(zip))) {
            for (ZipEntry e; (e = in.getNextEntry()) != null; ) {
                Path out = dest.resolve(e.getName()).normalize();
                if (!out.startsWith(dest)) throw new IllegalStateException("bad zip entry " + e.getName());
                if (e.isDirectory()) {
                    Files.createDirectories(out);
                    continue;
                }
                Files.createDirectories(out.getParent());
                Files.copy(in, out, StandardCopyOption.REPLACE_EXISTING);
            }
        }
        if (!windows()) new ProcessBuilder("chmod", "-R", "u+x", dest.toString()).start().waitFor();
    }

    private static void relaunch(Path java, String[] args) throws Exception {
        Path jar = Paths.get(Boot.class.getProtectionDomain().getCodeSource().getLocation().toURI());
        List<String> cmd = new ArrayList<>();
        cmd.add(java.toString());
        String home = System.getProperty("astra.home");
        if (home != null) cmd.add("-Dastra.home=" + home);
        cmd.add("-jar");
        cmd.add(jar.toString());
        for (String a : args) cmd.add(a);
        new ProcessBuilder(cmd).directory(new File(jar.getParent().toString())).start();
    }

    private static void showError(Throwable t) {
        StringWriter text = new StringWriter();
        t.printStackTrace(new PrintWriter(text));
        JTextArea area = new JTextArea("Astra could not start (Java " + System.getProperty("java.version") + ").\n\n" + text);
        area.setEditable(false);
        JScrollPane scroll = new JScrollPane(area);
        scroll.setPreferredSize(new Dimension(640, 320));
        JOptionPane.showMessageDialog(null, scroll, "Astra Launcher", JOptionPane.ERROR_MESSAGE);
    }
}
