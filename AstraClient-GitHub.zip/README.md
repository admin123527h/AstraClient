# AstraClient

AstraClient is a personal Minecraft: Java Edition launcher and Fabric mod for Minecraft 26.3, 26.2, 26.1.x and 1.21.11.

- **Launcher**: installs Fabric, Fabric API and the Astra mod, then starts the game.
  Sign-in uses the player's own Microsoft account (device code flow).
- **Mod**: glass-style menu, HUD, 16 animated shader skies, and 3D song lyrics for the player's own Spotify account.
  - Lyrics stay where they appear in the world and show word by word, with looks, fonts, colours and glow.
  - Skies are drawn on the GPU in a single draw call (aurora, nebula, galaxy, planets, eclipse, storms and more).
  - A small Spotify browser (playlists, liked songs, search) and play / pause / skip controls live in the menu.

This is a private, non-commercial hobby project. It does not redistribute any Minecraft files:
the game, libraries and assets are downloaded from Mojang's servers on the player's machine.
It is not affiliated with Mojang Studios or Microsoft.

## Versions

| Minecraft | Folder | Notes |
| --- | --- | --- |
| 26.3 and newer 26.x | `mod26/` | everything, including the shader skies (needs Java 25, the launcher downloads it) |
| 26.2 | `mod262/` | menu, HUD, lyrics, Spotify; vanilla sky |
| 26.1, 26.1.1, 26.1.2 | `mod261/` | menu, HUD, lyrics, Spotify; vanilla sky |
| 1.21.11 | `mod/` | everything, including the shader skies |

`mod262/` and `mod261/` compile the sources of `mod26/` with a few text replacements (see `copyPort` in their
`build.gradle`), so a fix in `mod26/` reaches all three.

## Add-ons

Astra manages some third-party mods and one resource pack (Xaero's Minimap and World Map, Freecam, Tree and Ore Vein
Miner, Mouse Tweaks, Shulker Box Tooltip, uku's Armor HUD, Essential, New Glowing Ores). None of them is shipped here:
the launcher downloads them from Modrinth to the player's computer before the game starts, checks their SHA-512 and
installs the mods they need. The in-game **Mods** tab turns them on and off. The list is in
`core/src/main/java/client/astra/addons/Addons.java`. Each mod keeps its own licence and terms.

## Updates

The launcher reads `update/manifest.json` from this repository on every start. Newer mod jars are downloaded
before the game starts; a newer launcher is downloaded once and used the next time the launcher starts.
To publish a change: build all parts, then run `java tools/MakeUpdate.java` in the project root and upload the
`update/` folder to the repository root (next to `README.md`).

## Install (Windows)

Download `Astra Client` (installer) or `AstraClient-portable.zip` from the latest release or from the
**Actions** tab, run it, and start **Astra Client** from the desktop or the Start menu.

## Build

| Part | Folder | Command |
| --- | --- | --- |
| Mod 1.21.11 (Fabric, Java 21) | `mod/` | `gradle build` (Gradle 9.2.1) |
| Mods 26.x (Fabric, Java 25) | `mod26/`, `mod262/`, `mod261/` | `gradle build` (Gradle 9.8.2) |
| Launcher (Java 17+) | `launcher/` | `gradle build` after all mods are built |

The Windows installer is built by `.github/workflows/windows-installer.yml` with `jpackage`.
Run it from the **Actions** tab, or push a tag such as `v0.1.0`.

## Credits

Poppins, Pacifico, Abril Fatface, Bangers, Lilita One, PT Serif (SIL Open Font License)
and Luckiest Guy, Yellowtail (Apache License 2.0). Licences are in `mod/src/main/resources/licenses/`.
